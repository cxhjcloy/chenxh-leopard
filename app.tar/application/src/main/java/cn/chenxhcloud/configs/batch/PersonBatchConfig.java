package cn.chenxhcloud.configs.batch;

import org.springframework.context.annotation.Configuration;

/**
 * 
*   
* 项目名称：chenxh-app  
* 类名称：cn.chenxhcloud.batch.BatchConfig  
* @author：chenxh  
* 创建时间：2017年12月13日 下午5:31:07
* 描述：Person batch 批处理配置
*
 */
@Configuration
public class PersonBatchConfig {

   
}