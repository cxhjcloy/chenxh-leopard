package cn.chenxhcloud.lambda;

/**
 * 
*   
* 项目名称：chenxh-leopard  
* 类名称：.Demo1  
* @author：chenxh  
* 创建时间：2018年1月9日 下午6:02:28
* 描述：
*
 */
public class Demo1 {
	public static void main(String[] args) {
		
		
		System.out.println("111");
	}
}

