package cn.chenxhcloud.beans;


/**
 * 
*   
* 项目名称：chenxh-app  
* 类名称：cn.chenxhcloud.beans.SubMyLeopardBean1  
* @author：chenxh  
* 创建时间：2018年1月11日 上午10:01:57
* 描述：
*
 */
public class SubMyLeopardBean1 {
	private Integer id;
	private String name;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "SubMyLeopardBean1 [id=" + id + ", name=" + name + "]";
	}
}
