#supervisorctl
自动监控进程和服务

##安装
sudo apt install supervisor