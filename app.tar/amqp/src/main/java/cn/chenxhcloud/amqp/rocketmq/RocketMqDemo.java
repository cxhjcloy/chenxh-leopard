package cn.chenxhcloud.amqp.rocketmq;

/**
 * 
*   
* 项目名称：chenxh-amqp  
* 类名称：cn.chenxhcloud.amqp.rocketmq.RocketMqDemo  
* @author：chenxh  
* 创建时间：2018年1月5日 上午10:10:34
* 描述：
*
 */
public class RocketMqDemo {

}
