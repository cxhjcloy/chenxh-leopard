package com.cjhsc.util;

import com.alibaba.fastjson.JSONArray;
import com.cjhsc.constant.HttpRequestMethodEnum;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

/**
 * RestHttpUtil请求工具类
 *
 * @author 杨英杰
 * @create 2017-04-06 下午 18:50
 **/
@Service
@SuppressWarnings("all")
public class RestUtil {
	
	
	private static final Logger log = LoggerFactory.getLogger(RestUtil.class);
	
	private static final String XCJAS = "QD517Y21H28PC4B43DT51K4";
	/**
	 * 模板类
	 */
	private RestTemplate rest;

	/**
	 * http头对象
	 */
	private HttpHeaders headers;

	/**
	 * http状态码信息
	 */
	private HttpStatus status;

	public RestUtil() {		
		rest = new RestTemplate();
		this.headers = new HttpHeaders();
		headers.add("Content-Type", "application/json;charset=UTF-8");
		headers.add("Accept", "*/*");
		headers.add("X-CJ-AS", "cjhsc:"+EncodeUtils.getMD5(XCJAS));
	}

	/*public RestTemplate getRest() {
		return rest;
	}

	public void setRest(RestTemplate rest) {
		this.rest = rest;
	}*/

	public HttpHeaders getHeaders() {		
		return headers;
	}

	public void setHeaders(HttpHeaders headers) {
		this.headers = headers;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	private String get(String uri) {
		HttpHeaders headers = this.getHeaders() ; 
		if(!headers.containsKey("X-CJ-AS")) {
			headers.add("Content-Type", "application/json;charset=UTF-8");
			headers.add("Accept", "*/*");
			headers.add("X-CJ-AS", "cjhsc:"+EncodeUtils.getMD5(XCJAS));
		}
		HttpEntity<String> requestEntity = new HttpEntity<String>("", headers);
		log.debug("※※※requestEntity:{}",requestEntity);
		ResponseEntity<String> responseEntity = rest.exchange(uri, HttpMethod.GET, requestEntity, String.class);
		this.setStatus(responseEntity.getStatusCode());
		return responseEntity.getBody();
	}

	private String post(String uri, String json) {
		HttpHeaders headers = this.getHeaders() ; 
		if(!headers.containsKey("X-CJ-AS")) {
			headers.add("Content-Type", "application/json;charset=UTF-8");
			headers.add("Accept", "*/*");
			headers.add("X-CJ-AS", "cjhsc:"+EncodeUtils.getMD5(XCJAS));
		}
		HttpEntity<String> requestEntity = new HttpEntity<String>(json, headers);
		log.debug("※※※requestEntity:{}",requestEntity);
		ResponseEntity<String> responseEntity = rest.exchange(uri, HttpMethod.POST, requestEntity, String.class);
		this.setStatus(responseEntity.getStatusCode());
		return responseEntity.getBody();
	}

	private String put(String uri, String json) {
		HttpHeaders headers = this.getHeaders() ; 
		if(!headers.containsKey("X-CJ-AS")) {
			headers.add("Content-Type", "application/json;charset=UTF-8");
			headers.add("Accept", "*/*");
			headers.add("X-CJ-AS", "cjhsc:"+EncodeUtils.getMD5(XCJAS));
		}
		HttpEntity<String> requestEntity = new HttpEntity<String>(json, headers);
		log.debug("※※※requestEntity:{}",requestEntity);
		ResponseEntity<String> responseEntity = rest.exchange(uri, HttpMethod.PUT, requestEntity, String.class);
		this.setStatus(responseEntity.getStatusCode());
		return responseEntity.getBody();
	}

	private String delete(String uri) {
		HttpHeaders headers = this.getHeaders() ; 
		if(!headers.containsKey("X-CJ-AS")) {
			headers.add("Content-Type", "application/json;charset=UTF-8");
			headers.add("Accept", "*/*");
			headers.add("X-CJ-AS", "cjhsc:"+EncodeUtils.getMD5(XCJAS));
		}
		HttpEntity<String> requestEntity = new HttpEntity<String>("", headers);
		log.debug("※※※requestEntity:{}",requestEntity);
		ResponseEntity<String> responseEntity = rest.exchange(uri, HttpMethod.DELETE, requestEntity, String.class);
		this.setStatus(responseEntity.getStatusCode());
		return responseEntity.getBody();
	}

	/**
	 * url添加参数
	 *
	 * @param url
	 *            String url
	 * @param parameters
	 *            Map 参数map
	 * @return String 附加参数的url
	 * @throws UnsupportedEncodingException
	 */
	public static String addQueryStringToUrlString(String url, final Map<Object, Object> parameters)
			throws UnsupportedEncodingException {
		if (parameters == null) {
			return url;
		}
		for (Map.Entry<Object, Object> parameter : parameters.entrySet()) {
			final String encodedKey;
			encodedKey = parameter.getKey().toString();
			if(parameter.getValue()==null) {
				continue;
			}
			final String encodedValue = parameter.getValue().toString();
			if (!url.contains("?")) {
				url += "?" + encodedKey + "=" + encodedValue;
			} else {
				url += "&" + encodedKey + "=" + encodedValue;
			}
		}
		return url;
	}

	/**
	 * 查询参数
	 *
	 * @param serverHost
	 *            String
	 * @param requestPath
	 *            String
	 * @param headParamMap
	 *            headParamMap
	 * @param requestParamMap
	 *            requestParamMap
	 * @param method
	 *            HttpRequestMethodEnum
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("all")
	public String fetchData(String serverHost, String requestPath, Map<String, String> headParamMap,
			Map requestParamMap, HttpRequestMethodEnum method) throws Exception {
		String responseContent = "";
		String requestUrl = serverHost + requestPath;
		if (null != headParamMap) {
			synchronized (headers) {
				getHeaders().remove("token");
				headParamMap.forEach((k, v) -> {
					if ("token".equals(k)) {
						getHeaders().add(k, v);
						getHeaders().remove("Cookie");
						getHeaders().add("Cookie", "token=" + v);
					}
				});
			}
		}else {
			//setHeaders(null);
		}
		System.out.println("RequestUrl: " + requestUrl);
		System.out.println("requestPath: " + requestPath);
		System.out.println("headParamMap: " + headParamMap);
		System.out.println("requestParamMap: " + requestParamMap);
		System.out.println("method: " + method);
		if (method == HttpRequestMethodEnum.GET || method == HttpRequestMethodEnum.DELETE) {
			requestUrl = addQueryStringToUrlString(requestUrl, requestParamMap);
			if (method == HttpRequestMethodEnum.GET) {
				responseContent = this.get(requestUrl);
			} else {
				responseContent = this.delete(requestUrl);
			}
		} else if (method == HttpRequestMethodEnum.POST) {
			responseContent = this.post(requestUrl, JsonUtil.beanToJson(requestParamMap));
		} else if (method == HttpRequestMethodEnum.PUT) {
			responseContent = this.put(requestUrl, JsonUtil.beanToJson(requestParamMap));
		}
		log.debug("return:{} ", responseContent);
		return responseContent;
	}

	
	@SuppressWarnings("all")
	public String fetchDataUri(String serverHost, String requestPath, Map<String, String> headParamMap,
			Map requestParamMap, HttpRequestMethodEnum method) throws Exception {
		String responseContent = "";
		String requestUrl = serverHost + requestPath;
		if (null != headParamMap) {
			synchronized (headers) {
				getHeaders().remove("token");
				headParamMap.forEach((k, v) -> {
					if ("token".equals(k)) {
						getHeaders().add(k, v);
						getHeaders().remove("Cookie");
						getHeaders().add("Cookie", "token=" + v);
					}
				});
			}
		}
		System.out.println("RequestUrl: " + requestUrl);
		System.out.println("requestPath: " + requestPath);
		System.out.println("headParamMap: " + headParamMap);
		System.out.println("requestParamMap: " + requestParamMap);
		System.out.println("method: " + method);
		if (method == HttpRequestMethodEnum.GET || method == HttpRequestMethodEnum.DELETE) {
			requestUrl = addQueryStringToUrlString(requestUrl, requestParamMap);
			if (method == HttpRequestMethodEnum.GET) {
				responseContent = this.get(requestUrl);
			} else {
				responseContent = this.delete(requestUrl);
			}
		} else if (method == HttpRequestMethodEnum.POST) {
			responseContent = this.post(addQueryStringToUrlString(requestUrl, requestParamMap), JsonUtil.beanToJson(requestParamMap));
		} else if (method == HttpRequestMethodEnum.PUT) {
			responseContent = this.put(requestUrl, JsonUtil.beanToJson(requestParamMap));
		}
		log.debug("return:{} ", responseContent);
		return responseContent;
	}
	@SuppressWarnings("all")
	public String fetchData4Array(String serverHost, String requestPath, Map<String, String> headParamMap,
			List requestParamMap, HttpRequestMethodEnum method) throws Exception {
		String responseContent = "";
		String requestUrl = serverHost + requestPath;
		if (null != headParamMap) {
			synchronized (headers) {
				getHeaders().remove("token");
				headParamMap.forEach((k, v) -> {
					if ("token".equals(k)) {
						getHeaders().add(k, v);
						getHeaders().remove("Cookie");
						getHeaders().add("Cookie", "token=" + v);
					}
				});
			}
		}
		System.out.println("RequestUrl: " + requestUrl);
		System.out.println("requestPath: " + requestPath);
		System.out.println("headParamMap: " + headParamMap);
		System.out.println("requestParamMap: " + JsonUtil.beanToJson(requestParamMap));
		System.out.println("method: " + method);
		if (method == HttpRequestMethodEnum.GET || method == HttpRequestMethodEnum.DELETE) {
			if (method == HttpRequestMethodEnum.GET) {
				responseContent = this.get(requestUrl);
			} else {
				responseContent = this.delete(requestUrl);
			}
		} else if (method == HttpRequestMethodEnum.POST) {
			responseContent = this.post4Array(requestUrl,
					(JSONArray) JSONArray.parse(JsonUtil.beanToJson(requestParamMap)));
		} else if (method == HttpRequestMethodEnum.PUT) {
			responseContent = this.put(requestUrl, JsonUtil.beanToJson(requestParamMap));
		}
		log.debug("return:{} ", responseContent);
		return responseContent;
	}

	private String post4Array(String requestUrl, JSONArray jsonArray) {
		HttpHeaders headers = this.getHeaders() ; 
		if(!headers.containsKey("X-CJ-AS")) {
			headers.add("Content-Type", "application/json;charset=UTF-8");
			headers.add("Accept", "*/*");
			headers.add("X-CJ-AS", "cjhsc:"+EncodeUtils.getMD5(XCJAS));
		}
		HttpEntity<JSONArray> entity = new HttpEntity<JSONArray>(jsonArray, headers);
		log.debug("※※※requestEntity:{}",entity);
		ResponseEntity<String> responseEntity = rest.exchange(requestUrl, HttpMethod.POST, entity, String.class);
		this.setStatus(responseEntity.getStatusCode());
		return responseEntity.getBody();
	}

	public String postUri(String serverHost, String requestPath, Map<String, String> headParamMap, Map requestParamMap)
			throws Exception {
		String responseContent = "";
		String requestUrl = serverHost + requestPath;
		if (null != headParamMap) {
			synchronized (headers) {
				getHeaders().remove("token");
				headParamMap.forEach((k, v) -> {
					if ("token".equals(k)) {
						getHeaders().add(k, v);
						getHeaders().remove("Cookie");
						getHeaders().add("Cookie", "token=" + v);
					}
				});
			}		
		}
		System.out.println("RequestUrl: " + requestUrl);
		System.out.println("requestPath: " + requestPath);
		System.out.println("headParamMap: " + headParamMap);
		System.out.println("requestParamMap: " + requestParamMap);
		responseContent = this.postUriRequst(requestUrl, requestParamMap);
		log.debug("return:{} ", responseContent);
		return responseContent;
	}

	private String postUriRequst(String requestUrl, Map requestParamMap) throws Exception {
		HttpHeaders headers = this.getHeaders() ; 
		if(!headers.containsKey("X-CJ-AS")) {
			headers.add("Content-Type", "application/json;charset=UTF-8");
			headers.add("Accept", "*/*");
			headers.add("X-CJ-AS", "cjhsc:"+EncodeUtils.getMD5(XCJAS));
		}
		requestUrl = addQueryStringToUrlString(requestUrl, requestParamMap);
		HttpEntity<String> requestEntity = new HttpEntity<String>("", this.getHeaders());
		log.debug("※※※requestEntity:{}",requestEntity);
		ResponseEntity<String> responseEntity = rest.exchange(requestUrl, HttpMethod.POST, requestEntity, String.class);
		this.setStatus(responseEntity.getStatusCode());
		return responseEntity.getBody();
	}
}
