package com.cjhsc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;


import weixin.popular.api.MenuAPI;
import weixin.popular.api.TokenAPI;
import weixin.popular.bean.BaseResult;
import weixin.popular.bean.menu.Button;
import weixin.popular.bean.menu.MenuButtons;
import weixin.popular.bean.token.Token;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.service.WxService  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:38:49
* 描述：
*
 */
@Service
public class WxService {
	private static Logger log = LoggerFactory.getLogger(WxService.class);
	private static final String ACCESSTOKENKEY="CJHSC_WX_ACCESSTOKEN";
	private static final long CACHETIME = 118;
	@Value("${wechat.appid}")
	private String appid;
	@Value("${wechat.appsecret}")
	private String appsecret;
	@Value("${webhost}")
	private  String webhost;
	@Autowired
	private RedisTemplate<String, String> redisTemplate;
	public BaseResult createMenu(String url) {
		MenuButtons menuButtons = new MenuButtons();
		List<Button> bts = new ArrayList<>();
		
		Button guardianButton = new Button();
		guardianButton.setKey("iamguardian");
		guardianButton.setName("我是家长");
		List<Button> guardianSubButtons = new ArrayList<>();
		Button guardianSubButton2 = new Button();
		guardianSubButton2.setKey("studyreport");
		guardianSubButton2.setName("学情报告");
		guardianSubButton2.setType("view");
		guardianSubButton2.setUrl(webhost+"weixin/user/index/parentsIndex/learnReport");
		guardianSubButtons.add(guardianSubButton2);
		
		Button guardianSubButton3 = new Button();
		guardianSubButton3.setKey("studyanalysis");
		guardianSubButton3.setName("学情分析");
		guardianSubButton3.setType("view");
		guardianSubButton3.setUrl(webhost+"weixin/user/index/parentsIndex/parentsAnalysis");
		guardianSubButtons.add(guardianSubButton3);
		
		Button guardianSubButton1 = new Button();
		guardianSubButton1.setKey("mychildren");
		guardianSubButton1.setName("我的孩子");
		guardianSubButton1.setType("view");
		guardianSubButton1.setUrl(webhost+"weixin/user/index/myChildren");
		guardianSubButtons.add(guardianSubButton1);
		
		guardianButton.setSub_button(guardianSubButtons);		
		bts.add(guardianButton);	
		
		Button teacherButton = new Button();
		teacherButton.setKey("iamteacher");
		teacherButton.setName("我是教师");
		List<Button> teacherSubButtons = new ArrayList<>();
		Button teacherSubButton1 = new Button();
		teacherSubButton1.setKey("classoverview");
		teacherSubButton1.setName("课堂观察");
		teacherSubButton1.setType("view");
		teacherSubButton1.setUrl(webhost+"weixin/user/index/teacher/teacherIndex/wisdom");
		teacherSubButtons.add(teacherSubButton1);
		
		Button teacherSubButton2 = new Button();
		teacherSubButton2.setKey("gradeanalysis");
		teacherSubButton2.setName("班级分析");
		teacherSubButton2.setType("view");
		teacherSubButton2.setUrl(webhost+"weixin/user/index/teacher/teacherIndex/teacherAnalysis");
		teacherSubButtons.add(teacherSubButton2);
		
		teacherButton.setSub_button(teacherSubButtons);		
		bts.add(teacherButton);
		
		/*Button helpCenterButton = new Button();
		helpCenterButton.setKey("helpcenter");
		helpCenterButton.setName("帮助中心");	
		
		List<Button> helpCenterSubButtons = new ArrayList<>();
		Button commonQuestionsSubButton = new Button();
		commonQuestionsSubButton.setKey("common_problems");
		commonQuestionsSubButton.setName("常见问题");
		commonQuestionsSubButton.setType("view");
		commonQuestionsSubButton.setUrl(webhost+"weixin/user/index/notice/commonQues");
		helpCenterSubButtons.add(commonQuestionsSubButton);*/
		
		Button aboutUsSubButton = new Button();
		aboutUsSubButton.setKey("aboutCaiji");
		aboutUsSubButton.setName("关于我们");
		aboutUsSubButton.setSub_button(null);
		aboutUsSubButton.setType("view");
		aboutUsSubButton.setUrl(webhost+"weixin/user/index/notice/aboutUs");
		//helpCenterSubButtons.add(aboutUsSubButton);
		
		/*Button quitSubButton = new Button();
		quitSubButton.setKey("quitCaiJi");
		quitSubButton.setName("退出登录");
		quitSubButton.setType("view");
		quitSubButton.setUrl(webhost+"/Weixin/exit0");
		helpCenterSubButtons.add(quitSubButton);*/
		
		//helpCenterButton.setSub_button(helpCenterSubButtons);	
		
		bts.add(aboutUsSubButton);
		
		Button[] buttons = (Button[])bts.toArray(new Button[bts.size()]); 
	    for (int i = 0; i < bts.size(); i++) {
	    	buttons[i] = bts.get(i);
		} 		
		menuButtons.setButton(buttons);
		BaseResult ret = MenuAPI.menuCreate(getAccessToken(), menuButtons);
		return ret;
	}

	public BaseResult getMenus() {
		return MenuAPI.menuGet(getAccessToken());
	}
	
	public String getAccessToken() {
		String accessToken = redisTemplate.opsForValue().get(ACCESSTOKENKEY);
		if(StringUtils.isEmpty(accessToken)) {
			/*accessToken = TokenManager.getToken(appid);
			if(StringUtils.isEmpty(accessToken)) {
				TokenManager.init(appid,appsecret);
				accessToken = TokenManager.getToken(appid);
				log.error("微信accessToken重置：{}",accessToken);
				redisTemplate.opsForValue().set(ACCESSTOKENKEY, accessToken, CACHETIME, TimeUnit.SECONDS);//数据缓存7000秒
			}*/	
			Token token = TokenAPI.token(appid,appsecret);
    		if(token.isSuccess()) {
    			accessToken = token.getAccess_token();
    			log.error("微信accessToken重置：{}",accessToken);
    			redisTemplate.opsForValue().set(ACCESSTOKENKEY, accessToken, CACHETIME, TimeUnit.MINUTES);
    		}else {
    			log.error("无法获取微信accessToken");
    			throw new RuntimeException("无法获取微信accessToken");
    		}
    	}/*else {
    		String wxAccessToken = TokenManager.getToken(appid);
    		if(StringUtils.isEmpty(wxAccessToken)) {
    			TokenManager.init(appid,appsecret);
    			wxAccessToken = TokenManager.getToken(appid);
    		}
    		if(!wxAccessToken.equals(accessToken)) {
    			TokenManager.init(appid,appsecret);
				accessToken = TokenManager.getToken(appid);
				log.error("微信accessToken重置：{}",accessToken);
				redisTemplate.opsForValue().set(ACCESSTOKENKEY, accessToken, CACHETIME, TimeUnit.SECONDS);//数据缓存7000秒
    		}
    	}*/
		return accessToken;
	}
}
