package com.cjhsc.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.cjhsc.domodal.SendWeixinUserMqDO;

import java.util.List;
import java.util.Map;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.mapper.FamilyMapper  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:35:44
* 描述：
*
 */
@Repository
@Mapper
public interface FamilyMapper {
    
	@Select("<script>" +
            "SELECT " +
            "  distinct a.studentId AS studentId," +
            "  a.studentName AS studentName " +
            " FROM" +
            "  (" +
            "    (" +
            "      SELECT" +
            "        tbss.ui_student_id AS studentId," +
            "        tbss.v_student_name AS studentName " +
            "      FROM db_teaching_pad_result.tb_basic_student_stat tbss" +
            "      LEFT JOIN db_teaching_pad_result.tb_basic_course_stat tbcs" +
            "      ON tbss.v_tid = tbcs.v_tid" +
            "      WHERE tbss.ui_student_id IN " +
            "      <foreach item=\"item\" index=\"index\" collection=\"studentIds\" open=\"(\" separator=\",\" close=\")\">" +
            "      #{item}" +
            "      </foreach>" +
            "      AND date(tbss.dt_event_time) = #{pageDate}" +
            "      AND tbcs.ui_interaction_sum > 0" +
            "    )" +
            "    UNION ALL" +
            "    (" +
            "      SELECT" +
            "        ui_student_id AS studentId," +
            "        v_student_name AS studentName" +
            "      FROM" +
            "        db_cjhms_result.tb_student_homework_result" +
            "      WHERE ui_student_id IN " +
            "      <foreach item=\"item\" index=\"index\" collection=\"studentIds\" open=\"(\" separator=\",\" close=\")\">" +
            "      #{item}" +
            "      </foreach>" +
            "   AND date(dt_publish_time) = #{pageDate}" +
            "    )" +
            "    UNION ALL" +
            "    (" +
            "    SELECT" +
            "      x.ui_student_id AS studentId," +
            "      x.v_student_name AS studentName" +
            "    FROM" +
            "        db_cjhms_log.tb_student_homework_log x" +
            "    INNER JOIN" +
            "    (" +
            "      SELECT" +
            "        ui_homework_id," +
            "        dt_marked_last" +
            "      FROM db_cjhms_result.tb_teacher_homework_result" +
            "      WHERE ui_class_id IN" +
            "      (" +
            "        SELECT" +
            "          aa.ui_class_id" +
            "        FROM db_cjhms_log.tb_student_homework_log aa" +
            "        WHERE ui_student_id in " +
            "       <foreach item=\"item\" index=\"index\" collection=\"studentIds\" open=\"(\" separator=\",\" close=\")\">" +
            "           #{item}" +
            "       </foreach>" +
            "       AND ui_status in (4,5)" +
            "        GROUP BY aa.ui_class_id" +
            "      )" +
            "      AND ui_is_marked = 1 AND date(dt_marked_last) = #{pageDate}" +
            "    ) y" +
            "    ON x.ui_homework_id = y.ui_homework_id" +
            "    WHERE x.ui_student_id in " +
            "    <foreach item=\"item\" index=\"index\" collection=\"studentIds\" open=\"(\" separator=\",\" close=\")\">" +
            "    #{item}" +
            "    </foreach>" +
            "    AND ui_status in (4,5)" +
            "    GROUP BY x.ui_student_id" +
            "    )" +
            "  ) a" +
            "</script>")
    List<Map<String, String>> getStudentList(Map<String, Object> paramMap);

    
    
    
    @Select("<script>" +
            "select distinct tbss.v_teacher_name as studentName,tbss.ui_teacher_id as studentId,DATE(dt_event_time) as reportDate" +
            " from" +
            " db_teaching_pad_result.tb_basic_course_stat tbss" +
            " where date(tbss.dt_event_time) = #{pageDate}" +
            " and tbss.ui_teacher_id in " +
            "<foreach item=\"item\" index=\"index\" collection=\"teacherInfoList\" open=\"(\" separator=\",\" close=\")\">" +
            "#{item.studentId}" +
            "</foreach>" +
            "</script>")
	List<SendWeixinUserMqDO> getTeaching4SendWx(@Param("teacherInfoList") List<SendWeixinUserMqDO> teacherInfoList,@Param("pageDate") String pageDate);



    /**
     * 根据学生Id获取家长绑定的微信OPENID
     * @param guardianId
     * @return
     */
    @Select("select DISTINCT b.open_id from cjyun.student_guardian s LEFT JOIN cjyun.bind_open_id b on s.family_guardian_id=b.user_id where s.student_id=#{studentId}")
	List<String> getGuardianOpenId(@Param("studentId")String studentId);
}
