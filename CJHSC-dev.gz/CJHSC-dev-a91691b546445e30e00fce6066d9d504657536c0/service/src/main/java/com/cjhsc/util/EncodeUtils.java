package com.cjhsc.util;

import java.math.BigInteger;
import java.security.MessageDigest;

import org.apache.commons.lang3.StringUtils;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.util.EncodeUtils  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:39:46
* 描述：
*
 */
public class EncodeUtils {
	private static final String KEY_MD5 = "MD5";
	private static final String KEY_SHA = "SHA";
	
    private final static String[] HEX_DIGITS = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

    public static String md5Encode(String source,boolean uppercase) {
        String result = null;
        try {
            result = source;
            MessageDigest messageDigest = MessageDigest.getInstance(KEY_MD5);
            messageDigest.update(source.getBytes());
            result = byteArrayToHexString(messageDigest.digest());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return uppercase ? result.toUpperCase() : result;
    }

    private static String byteArrayToHexString(byte[] bytes) {
        StringBuilder stringBuilder = new StringBuilder();
        for (byte tem : bytes) {
            stringBuilder.append(byteToHexString(tem));
        }
        return stringBuilder.toString();
    }

    private static String byteToHexString(byte b) {
        int n = b;
        if (n < 0) {
            n = 256 + n;
        }
        int d1 = n / 16;
        int d2 = n % 16;
        return HEX_DIGITS[d1] + HEX_DIGITS[d2];
    }
	
	
	public static  String  shaEncode(String inputStr)
    {
		if(StringUtils.isBlank(inputStr)) {
			throw new RuntimeException("加密字符串不能为空");
		}
        BigInteger sha =null;
        byte[] inputData = inputStr.getBytes();   
        try {
             MessageDigest messageDigest = MessageDigest.getInstance(KEY_SHA);  
             messageDigest.update(inputData);
             sha = new BigInteger(messageDigest.digest());   
        } catch (Exception e) {e.printStackTrace();}
        return sha.toString(32);
    }
	
	
	 public static String getMD5(String data) {
		 	if(StringUtils.isBlank(data)) {
		 		return null;
		 	}
		 	byte[] source = data.getBytes();
	        String s = null;
	        char hexDigits[] = {
	                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	        try {
	            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
	            md.update(source);
	            byte tmp[] = md.digest(); 
	            char str[] = new char[16 * 2];
	            int k = 0;                       
	            for (int i = 0; i < 16; i++) {
	                byte byte0 = tmp[i];  
	                str[k++] = hexDigits[byte0 >>> 4 & 0xf];  
	                str[k++] = hexDigits[byte0 & 0xf];
	            }
	            s = new String(str);

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return s;
	    }
}
