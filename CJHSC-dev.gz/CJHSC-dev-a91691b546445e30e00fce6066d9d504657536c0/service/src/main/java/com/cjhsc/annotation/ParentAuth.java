package com.cjhsc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.annotation.ParentAuth  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:33:21
* 描述：
*
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface ParentAuth {
	/**
	 * 是否启用
	 * @return
	 */
	boolean enable() default true;
	/**
	 * 是否需要登录
	 * @return
	 */
	boolean isLogin() default true;
	/**
	 * 是否需要获取shoolIds
	 * @return
	 */
	boolean needSchoolIds() default false;
}
