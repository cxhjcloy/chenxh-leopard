package com.cjhsc.mapper;

import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;


/**
 * 
*   
* 项目名称：CJHSC  
* 类名称：.CjtlisDateLogResultRecordMapper  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:12:36
* 描述：
*
 */
@Repository
@Mapper
public interface CjtlisDateLogResultRecordMapper {

    /**
     * 查询未统计课堂总数
     *
     * @param selectDate 查询日期
     * @return int 未统计课堂总数
     */
    @ResultType(value = Integer.class)
    @Select("<script>" +
            "select count(result.v_tid)  counts from ( " +
            "    select v_tid from db_teaching_pad_log.tb_teaching_record  where date(dt_event_time) ='${selectDate}' " +
            " ) log left join ( " +
            "   select v_tid from db_teaching_pad_result.tb_course_index_anlz  where date(dt_event_time) ='${selectDate}' " +
            "  ) result  on log.v_tid = result.v_tid where result.v_tid is null " +
            "</script>")
    int findUnStaticLessonCount(@Param("selectDate") String selectDate);
}
