package com.cjhsc.exception;

/**
 * 异常信息
 * Created by xuke on 2017/3/31 0031.
 * @author shangzhi
 */
public enum ErrorInfoEnum {
	/**
	 * 
	 */
    USER_IS_NULL(703, "您尚未登录，或者Session超时", "\\u60a8\\u5c1a\\u672a\\u767b\\u9646\\uff0c\\u6216\\u8005\\u0053\\u0065\\u0073\\u0073\\u0069\\u006f\\u006e\\u8d85\\u65f6"),
    ERROR_DATA(500, "接口返回状态码错误", "\\u60a8\\u5c1a\\u672a\\u767b\\u9646\\uff0c\\u6216\\u8005\\u0053\\u0065\\u0073\\u0073\\u0069\\u006f\\u006e\\u8d85\\u65f6"),
    ARGUMENT_NOT_VALID(80001, "参数不合法", ""),
    RUNTIME_EXCEPTIOON(80002, "RuntimeException系统异常", ""),
    UNKNOW_EXCEPTION(80004, "未知系统异常", ""),
    INVALID_PARAMETER(80005, "参数无效", ""),
    UNAUTHORIZED(400, "'无权限数据操作权限", ""),
    SQL_EXCEPTION(80006, "数据查询错误", "");

    /**
     * 异常码
     */
    public int code;
    /**
     * 异常描述
     */
    public String desc;
    /**
     * 异常描述  unicode编码
     */
    public String unicode;

    private ErrorInfoEnum(int code, String desc, String unicode) {
        this.code = code;
        this.desc = desc;
        this.unicode = unicode;
    }
}
