package com.cjhsc.util;


/**
 * 
*   
* 项目名称：CJHSC  
* 类名称：.ApiError  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:46:33
* 描述：
*
 */
public enum ApiError {
	/**
	 * 
	 */
	OK(0, "成功"),
	WX_OPENID_NOTFOUND(5000, "获取不到用户openid"),
	PARAS_INCOMPLETE(5001, "请求参数缺失"),
	NO_LOGIN(5002, "用户没有登录"),
	NO_TOKEN(5003, "获取不到用户token"),
	BIND_ERROR(5004, "绑定用户openid失败"),
	NOT_TEACHER(5006, "非教师账号"),
	NOT_TEACHERID(5007, "获取不到教师ID"),
	JWT_NOTFOUND(5008, "获取不到JWT"),
	BIND_OTHER(5009, "已绑定其他用户"),
	NOT_GUARDIAN(5010, "非家长账号"),
	NO_SCHOOLID(5011, "获取不到学校id"),
	NO_STUDENTS(5012, "查询不到绑定的学生"),
	UNKNOWN_ERROR(5555,"未知错误");
	private String message;
	private int code;
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
	
	private ApiError(int code, String message) {
		this.code = code;
		this.message = message;
	}
}
