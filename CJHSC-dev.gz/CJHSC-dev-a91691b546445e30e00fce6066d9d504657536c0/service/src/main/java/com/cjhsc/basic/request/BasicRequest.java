package com.cjhsc.basic.request;

import com.cjhsc.constant.HttpRequestMethodEnum;
import com.cjhsc.dtomodal.PageDTO;
import com.cjhsc.exception.BusinessException;
import com.cjhsc.exception.ErrorInfoEnum;
import com.cjhsc.util.RestUtil;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;
import java.util.Map;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.basic.request.BasicRequest  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:34:16
* 描述：
*
 */
@SuppressWarnings("all")
public class BasicRequest {
    /**
     * cbp接口url信息
     */
    @Value("${cbp.host}")
    protected String serverHost;
    @Value("${cjtlis}")
    protected String cjtlisHost;
    
    /**
     * 接口返回数据内容
     */
    private String responseContent;
    /**
     * 用户token
     */
    private String userToken;

    /**
     * 返回json对象
     */
    private JSONObject responseObj;

    @Autowired
    private RestUtil restUtil;

    /**
     * 返回数据对象
     */
    private PageDTO pageDTO;


    public PageDTO getPageDTO() {
        return pageDTO;
    }

    public void setPageDTO(PageDTO pageDTO) {
        this.pageDTO = pageDTO;
    }

    public RestUtil getRestUtil() {
        return restUtil;
    }

    public void setRestUtil(RestUtil restUtil) {
        this.restUtil = restUtil;
    }

    public JSONObject getResponseObj() {
        return responseObj;
    }

    public void setResponseObj(JSONObject responseObj) {
        this.responseObj = responseObj;
    }

    public String getResponseContent() {
        return responseContent;
    }

    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent;
    }

    public String getUserToken() {
        return userToken;
    }

    /*
    public String getCurrentUserToken() {
        if (null != this.userToken) {
            return this.userToken;
        }
        return UserSessionUtil.getUserDo().getToken();
    }
    */


    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }

    public String getServerHost() {
        return serverHost;
    }

    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    public String getApiData(String requestPath, Map<String, String> headParamMap, HttpRequestMethodEnum method) throws Exception {
        return this.getApiData(requestPath,null, headParamMap,  method);
    }

    public String postUri(String requestPath, Map<String, String> headParamMap, Map requestParamMap) throws Exception {
    	return restUtil.postUri(this.serverHost, requestPath, headParamMap, requestParamMap);
    	/*responseContent = restUtil.postUri(this.serverHost, requestPath, headParamMap, requestParamMap);
        setResponseContent(responseContent);
        JSONObject responseObj = JSONObject.fromObject(this.getResponseContent());
        //判断接口状态
        try {
	        if (responseObj.containsKey("code") && responseObj.getInt("code") == 703) {
	            throw new BusinessException(ErrorInfoEnum.USER_IS_NULL);
	        } else if (responseObj.containsKey("code") &&responseObj.getInt("code") == 100) {
	            throw new BusinessException(ErrorInfoEnum.UNAUTHORIZED);
	        } else if (responseObj.containsKey("code") &&responseObj.getInt("code") != 0) {
	            throw new BusinessException(ErrorInfoEnum.ERROR_DATA);
	        }
        }catch (Exception e) {
        	e.printStackTrace();
        	throw new RuntimeException(e.getMessage());
		}
        setResponseObj(responseObj);
        return responseContent;*/
	}
    //调用基础平台接口
    public String getApiData(String requestPath, Map<String, String> headParamMap, Map requestParamMap, HttpRequestMethodEnum method) throws Exception {
    	return restUtil.fetchDataUri(this.serverHost, requestPath, headParamMap, requestParamMap, method);
        //responseContent = restUtil.fetchData(this.serverHost, requestPath, headParamMap, requestParamMap, method);
        //this.setResponseContent(responseContent);
        //JSONObject responseObj = JSONObject.fromObject(this.getResponseContent());
        //判断接口状态
        /*try {
	        if (responseObj.containsKey("code") && responseObj.getInt("code") == 703) {
	            throw new BusinessException(ErrorInfoEnum.USER_IS_NULL);
	        } else if (responseObj.containsKey("code") &&responseObj.getInt("code") == 100) {
	            throw new BusinessException(ErrorInfoEnum.UNAUTHORIZED);
	        } else if (responseObj.containsKey("code") &&responseObj.getInt("code") != 0) {
	            throw new BusinessException(ErrorInfoEnum.ERROR_DATA);
	        }
        }catch (Exception e) {
        	e.printStackTrace();
        	throw new RuntimeException(e.getMessage());
		}*/
        //this.setResponseObj(responseObj);
        //return responseContent;
    }
  //调用基础平台接口
   public String getApiDataUri(String requestPath, Map<String, String> headParamMap, Map requestParamMap, HttpRequestMethodEnum method) throws Exception {
    	return restUtil.fetchDataUri(this.serverHost, requestPath, headParamMap, requestParamMap, method);
        //responseContent = restUtil.fetchData(this.serverHost, requestPath, headParamMap, requestParamMap, method);
        //this.setResponseContent(responseContent);
        //JSONObject responseObj = JSONObject.fromObject(this.getResponseContent());
        //判断接口状态
        /*try {
	        if (responseObj.containsKey("code") && responseObj.getInt("code") == 703) {
	            throw new BusinessException(ErrorInfoEnum.USER_IS_NULL);
	        } else if (responseObj.containsKey("code") &&responseObj.getInt("code") == 100) {
	            throw new BusinessException(ErrorInfoEnum.UNAUTHORIZED);
	        } else if (responseObj.containsKey("code") &&responseObj.getInt("code") != 0) {
	            throw new BusinessException(ErrorInfoEnum.ERROR_DATA);
	        }
        }catch (Exception e) {
        	e.printStackTrace();
        	throw new RuntimeException(e.getMessage());
		}*/
        //this.setResponseObj(responseObj);
        //return responseContent;
    }
    //调用学情接口
    public String getApiData4Cjtlis(String requestPath, Map<String, String> headParamMap, Map requestParamMap, HttpRequestMethodEnum method) throws Exception {
    	return restUtil.fetchData(this.cjtlisHost, requestPath, headParamMap, requestParamMap, method);
        //responseContent = restUtil.fetchData(this.cjtlisHost, requestPath, headParamMap, requestParamMap, method);
        //this.setResponseContent(responseContent);
        //JSONObject responseObj = JSONObject.fromObject(this.getResponseContent());
        //判断接口状态
        /*try {
	        if (responseObj.containsKey("code") && responseObj.getInt("code") == 703) {
	            throw new BusinessException(ErrorInfoEnum.USER_IS_NULL);
	        } else if (responseObj.containsKey("code") &&responseObj.getInt("code") == 100) {
	            throw new BusinessException(ErrorInfoEnum.UNAUTHORIZED);
	        } else if (responseObj.containsKey("code") &&responseObj.getInt("code") != 0) {
	            throw new BusinessException(ErrorInfoEnum.ERROR_DATA);
	        }
        }catch (Exception e) {
        	e.printStackTrace();
        	throw new RuntimeException(e.getMessage());
		}*/
        //this.setResponseObj(responseObj);
        //return responseContent;
    }
    
    public String getApiData4Array(String requestPath, Map<String, String> headParamMap, List requestParamMap, HttpRequestMethodEnum method) throws Exception {
    	return restUtil.fetchData4Array(this.serverHost, requestPath, headParamMap, requestParamMap, method);
        /*responseContent = restUtil.fetchData4Array(this.serverHost, requestPath, headParamMap, requestParamMap, method);
        this.setResponseContent(responseContent);
        JSONObject responseObj = JSONObject.fromObject(this.getResponseContent());
        //判断接口状态
        try {
	        if (responseObj.getInt("code") == 703) {
	            throw new BusinessException(ErrorInfoEnum.USER_IS_NULL);
	        } else if (responseObj.getInt("code") == 100) {
	            throw new BusinessException(ErrorInfoEnum.UNAUTHORIZED);
	        } else if (responseObj.getInt("code") != 0) {
	            throw new BusinessException(ErrorInfoEnum.ERROR_DATA);
	        }
        }catch (Exception e) {
			e.printStackTrace();
		}
        this.setResponseObj(responseObj);
        return responseContent;*/
    }
}
