package com.cjhsc.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.cjhsc.dbmodel.DbModel;
/**
 * 
*   
* 项目名称：CJHSC  
* 类名称：.DbDao  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:13:01
* 描述：
*
 */
@Repository
@Mapper
public interface DbDao {
	@Select("select v_tid as studentName,v_tid as studentId,v_tid from tb_ask_teaching_evaluation_stat limit 0,10")
	List<DbModel> getList();

	@Select("select ui_student_id as studentName,ui_student_id as studentId,ui_student_id from tb_student_last_teachingday_status")
	List<DbModel> getList1();

	@Select("<script> select * from tb_helpcenter_qa t <if test=\"question != null and question!=''\"> where t.question like CONCAT('%', #{question}, '%') </if> </script>")
	List<Map<Object,Object>> getCommonQaList(@Param("question") String question);
	
	
	//@Select("select open_id  from tb_user_bind where phone= #{phone}")
	//String getOpenIdByPhone(@Param("phone") String phone );
	
	//@Select("select open_id  from tb_user_bind where user_id= #{userId}")
	//String getOpenIdByUserId(@Param("userId") Integer userId );
	
	//@Insert("replace into tb_user_bind(user_id,open_id,phone) values(#{userId},#{openId},#{phone})")
    //void saveBindInfo(@Param("userId") Integer userId,@Param("openId") String openId,@Param("phone") String phone);

	@Select("select date_format(dt_last_teaching_date,'%Y-%m-%d') as lastReportDate ,ui_read_status as reprotReadStatus  from tb_student_last_teachingday_status where v_open_id =#{guardianOpenId}and ui_student_id= #{studentId} order by dt_last_teaching_date desc limit 0,1")
	Map<String, Object> getStudentLastReportDate(@Param("guardianOpenId") String guardianOpenId, @Param("studentId") String studentId);

	@Select("select t.ui_read_status from tb_student_last_teachingday_status t where t.ui_student_id=#{studentId} and t.dt_last_teaching_date=#{teachingDate} and t.v_open_id=#{guardianOpenId}")
	Integer getStudentReadStatus(@Param("studentId") Integer studentId, @Param("teachingDate") String teachingDate,@Param("guardianOpenId") String guardianOpenId);

	@Select("select t.ui_read_status from tb_teacher_read_status t where t.ui_teacher_id=#{teacherId} and t.d_teaching_date=#{teachingDate}")
	Integer getTeacherReadStatus(@Param("teacherId") String teacherId, @Param("teachingDate") String teachingDate);

	//@Update("update tb_student_last_teachingday_status  set ui_read_status=1  where ui_student_id=#{studentId} and dt_last_teaching_date=#{teachingDate} and v_open_id=#{guardianOpenId}")
	@Insert("replace into tb_student_last_teachingday_status(v_open_id,ui_student_id, dt_last_teaching_date,ui_read_status,dt_read_time) values(#{guardianOpenId},#{studentId}, #{teachingDate},1,now())")
	Integer updateStudentReadStatus(@Param("studentId") String studentId, @Param("teachingDate") String teachingDate, @Param("guardianOpenId") String guardianOpenId);
	
	//@Update("update tb_teacher_read_status set ui_read_status=1 where ui_teacher_id=#{teacherId} and d_teaching_date=#{teachingDate}")
	@Insert("replace into tb_teacher_read_status(ui_teacher_id,d_teaching_date, ui_read_status,ui_push_status,dt_read_time) values(#{teacherId},#{teachingDate}, 1,1,now())")
	Integer updateTeacherReadStatus(@Param("teacherId") String teacherId, @Param("teachingDate") String teachingDate);
}
