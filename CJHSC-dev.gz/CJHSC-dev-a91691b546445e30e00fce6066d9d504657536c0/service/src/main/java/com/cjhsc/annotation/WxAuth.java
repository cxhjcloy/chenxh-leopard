package com.cjhsc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.annotation.WxAuth  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:33:58
* 描述：
*
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface WxAuth {
	/**
	 * 是否启用
	 * @return
	 */
	boolean enable() default true;
	/**
	 * 是否需要登录
	 * @return
	 */
	boolean isLogin() default false;
	/**
	 * 是否需要重定向
	 * @return
	 */
	boolean isRedirect() default false;
	/**
	 * 若需要重定向时 ，重定向url地址
	 * @return
	 */
	String  redirectUrl() default "";
}
