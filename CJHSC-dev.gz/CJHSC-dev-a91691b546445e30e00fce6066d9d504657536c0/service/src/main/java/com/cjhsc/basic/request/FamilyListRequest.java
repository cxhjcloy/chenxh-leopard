package com.cjhsc.basic.request;

import com.cjhsc.constant.HttpRequestMethodEnum;
import com.cjhsc.domodal.SendWeixinUserMqDO;
import com.cjhsc.mapper.FamilyMapper;
import net.sf.json.JSONArray;
import net.sf.json.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.basic.request.FamilyListRequest  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:34:40
* 描述：
*
 */
@Service
@Scope("prototype")
@SuppressWarnings("all")
public class FamilyListRequest extends BasicRequest {

    /**
     * 绑定微信家长数据
     */
    @Value("${cbp.resource.weixinUser}")
    protected String familyListUrl;
    /**
     * 分页获取数据大小
     */
    @Value("${cbp.resource.pageSize}")
    protected String pageSize;

    @Autowired
    private FamilyMapper familyMapper;

    /**
     * 页数
     */
    private int pageCount;

    public String getFamilyListUrl() {
        return familyListUrl;
    }

    public void setFamilyListUrl(String familyListUrl) {
        this.familyListUrl = familyListUrl;
    }

    public String getPageSize() {
        return pageSize;
    }

    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }

    public FamilyMapper getFamilyMapper() {
        return familyMapper;
    }

    public void setFamilyMapper(FamilyMapper familyMapper) {
        this.familyMapper = familyMapper;
    }


    public int getPageCount() {
        return pageCount;
    }

    private void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    /**
     * 获取绑定教师List列表<分页查询>
     *
     * @param page
     * @return
     * @throws Exception
     */
    public List<SendWeixinUserMqDO> getTeachersAndOpenIdMap(long page) throws Exception {
        // 教师ID和opendID集合
        List<SendWeixinUserMqDO> teacherInfoList = new ArrayList<SendWeixinUserMqDO>();
        // 查询条件
        Map headParams = new HashMap();
        headParams.put("pageSize", pageSize);
        headParams.put("page", String.valueOf(page));
        //headParams.put("bindStudent", "YES");
        //type  type = 2  代表家长  type=1 代表教师
        headParams.put("type", "1");
        String requestContent = this.getApiData(this.familyListUrl, headParams, HttpRequestMethodEnum.GET);
        JSONObject returnObj = JSONObject.fromObject(requestContent);
        JSONObject dataJSONObject = returnObj.getJSONObject("data");
        this.setPageCountWiehTotal(dataJSONObject.getDouble("total"));
        JSONArray jsonArray = dataJSONObject.getJSONArray("rows");
        if (null != jsonArray) {
            jsonArray.forEach(
                    row -> {
                        JSONObject jsonObject = ((JSONObject) row);
                        String teacherOpenId = jsonObject.getString("guardianOpenId");
                        int loginStatus = jsonObject.getInt("loginStatus");
                        if (teacherOpenId.length() == 28 && loginStatus == 1) {
                            String teacherUserId = jsonObject.getString("familyGuardianId");
                            String teacherUserName = jsonObject.getString("realName");
                            SendWeixinUserMqDO sendWeixinUserMqDO = new SendWeixinUserMqDO();
                            sendWeixinUserMqDO.setStudentName(teacherUserName);
                            sendWeixinUserMqDO.setParentOpenId(teacherOpenId);
                            sendWeixinUserMqDO.setStudentId(teacherUserId);
                            teacherInfoList.add(sendWeixinUserMqDO);
                        }
                    }
            );
        }
        return teacherInfoList;
    }

    /*
    * 获取绑定学生的Id与微信OpenId关联Map对象
    *
    * @param page
    * @return
    * @throws Exception
    */
    public Map<String, List<String>> getStudentAndOpenIdMap(int page) throws Exception {
        // 学生ID和opendID集合
        Map<String, List<String>> studentIdAndOpenIdMap = new HashMap();
        // 查询条件
        Map headParams = new HashMap();
        headParams.put("pageSize", pageSize);
        headParams.put("page", String.valueOf(page));
        headParams.put("bindStudent", "YES");
        headParams.put("type", "2");
        String requestContent = this.getApiData(this.familyListUrl, headParams, HttpRequestMethodEnum.GET);
        JSONObject returnObj = JSONObject.fromObject(requestContent);
        JSONObject dataJSONObject = returnObj.getJSONObject("data");
        this.setPageCountWiehTotal(dataJSONObject.getDouble("total"));
        JSONArray jsonArray = dataJSONObject.getJSONArray("rows");
        if (null != jsonArray) {
            jsonArray.forEach(
                    row -> {
                        JSONObject jsonObject = ((JSONObject) row);
                        String openId = jsonObject.getString("guardianOpenId");
                        int loginStatus = jsonObject.getInt("loginStatus");
                        if (openId.length() == 28 && loginStatus == 1) {
                            List studentIds = new ArrayList();
                            jsonObject.getJSONArray("studentDtoList").forEach(
                                    student -> studentIds.add(((JSONObject) student).getString("userId"))
                            );
                            studentIdAndOpenIdMap.put(openId, studentIds);
                        }
                    }
            );
        }
        return studentIdAndOpenIdMap;
    }

    public void setPageCountWiehTotal(double total) {
        this.setPageCount((int) Math.ceil(total / Double.parseDouble(pageSize)));
    }
}
