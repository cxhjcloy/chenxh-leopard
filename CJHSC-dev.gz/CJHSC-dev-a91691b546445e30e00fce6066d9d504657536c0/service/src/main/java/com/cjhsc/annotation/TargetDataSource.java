package com.cjhsc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.RetentionPolicy;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.annotation.TargetDataSource  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:33:44
* 描述：
*
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface TargetDataSource {
	/**
	 * 数据源id
	 * @return
	 */
    String value() default "defaultDataSource";
}
