/**
 * Copyright (C) 2010-2016 Alibaba Group Holding Limited
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.cjhsc.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.aliyun.openservices.ons.api.Action;
import com.aliyun.openservices.ons.api.ConsumeContext;
import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.MessageListener;
import com.cjhsc.domodal.SendWeixinUserHotReportMqDo;
import com.cjhsc.domodal.SendWeixinUserMqDO;

import net.sf.json.JSONObject;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.service.MessageListenerImpl  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:36:38
* 描述：
*
 */
public class MessageListenerImpl implements MessageListener {

    public static final Logger log = LoggerFactory.getLogger(MessageListenerImpl.class);
    @Value("${webhost}")
    private String webhost;

    @Value("${mq.parenttag}")
    private String parentMqTag;
    @Value("${mq.teachertag}")
    private String teacherMqTag;    
    @Value("${mq.hotreport}")
    private String hotReportTag;
    @Autowired
    private ReceiveWeixinUserMqService receiveWeixinUserMqService;

    @Override
    public Action consume(Message message, ConsumeContext consumeContext) {
        boolean result = false;
        log.debug("{} 获取消息, Topic is:{}, getReconsumeTimes: {}, 接收内容为：{}, MsgId is:{}, Tag is: {}", new Date(), message.getTopic(), message.getReconsumeTimes(), new String(message.getBody()), message.getMsgID(), message.getTag());
        if (parentMqTag.equals(message.getTag())) {
            try {
                JSONObject returnObj = JSONObject.fromObject(new String(message.getBody()));
                SendWeixinUserMqDO sendDO = (SendWeixinUserMqDO) JSONObject.toBean(returnObj, SendWeixinUserMqDO.class);
                log.debug("解析对象...................................................................");
                String link = this.webhost + "weixin/user/index/dailyLearning?&studentId=" + sendDO.getStudentId() + "&date=" + sendDO.getReportDate() + "&teachingDate=" + sendDO.getReportDate();
                sendDO.setLink(link);
                log.debug(JSONObject.fromObject(sendDO).toString());
                result = receiveWeixinUserMqService.sendWeixinMessage(sendDO);
            } catch (Exception e) {
                e.printStackTrace();
                log.error(e.getMessage());
            }
            if (result) {
                return Action.CommitMessage;
            } else {
                return Action.ReconsumeLater;
            }
        } else if (teacherMqTag.equals(message.getTag())) {
            try {
                JSONObject returnObj = JSONObject.fromObject(new String(message.getBody()));
                SendWeixinUserMqDO sendDO = (SendWeixinUserMqDO) JSONObject.toBean(returnObj, SendWeixinUserMqDO.class);
                log.debug("解析对象...................................................................");
                String link = this.webhost + "weixin/user/index/teacher/teaching?date=" + sendDO.getReportDate();
                sendDO.setLink(link);
                log.debug(JSONObject.fromObject(sendDO).toString());
                result = receiveWeixinUserMqService.sendWeixinMessageToTeacher(sendDO);
            } catch (Exception e) {
                e.printStackTrace();
                log.error(e.getMessage());
            }
            if (result) {
                return Action.CommitMessage;
            } else {
                return Action.ReconsumeLater;
            }

        }else if (hotReportTag.equals(message.getTag())) {
            try {
            	JSONObject returnObj = JSONObject.fromObject(new String(message.getBody()));
            	SendWeixinUserHotReportMqDo sendDO = (SendWeixinUserHotReportMqDo) JSONObject.toBean(returnObj, SendWeixinUserHotReportMqDo.class);
            	sendDO.setLink(this.webhost + "weixin/user/index/hotReports");
                log.debug("解析对象...................................................................");
                log.debug(JSONObject.fromObject(sendDO).toString());
                result = receiveWeixinUserMqService.sendHotReport(sendDO);
            } catch (Exception e) {
                e.printStackTrace();
                log.error(e.getMessage());
            }
            if (result) {
                return Action.CommitMessage;
            } else {
                return Action.ReconsumeLater;
            }

        } else {
            return Action.ReconsumeLater;
        }
    }
}
