package com.cjhsc.service;

import java.util.LinkedHashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cjhsc.annotation.TargetDataSource;
import com.cjhsc.domodal.SendWeixinUserHotReportMqDo;
import com.cjhsc.domodal.SendWeixinUserMqDO;
import com.cjhsc.mapper.FamilyMapper;

import net.sf.json.JSONObject;
import weixin.popular.api.MessageAPI;
import weixin.popular.bean.message.templatemessage.TemplateMessage;
import weixin.popular.bean.message.templatemessage.TemplateMessageItem;
import weixin.popular.bean.message.templatemessage.TemplateMessageResult;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.service.ReceiveWeixinUserMqService  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:37:01
* 描述：
*
 */
@Service
public class ReceiveWeixinUserMqService {
	public static final Logger log = LoggerFactory.getLogger(ReceiveWeixinUserMqService.class);
	@Autowired
	private WxService wxService;
	@Value("${wechat.appid}")
	private String appid;

	@Value("${wechat.appsecret}")
	private String appsecret;

	@Value("${wechat.encodingaeskey}")
	private String encodingaeskey;

	@Value("${wechat.key}")
	private String key;

	/**
	 * 家长-孩子学习日报模板
	 */
	@Value("${wechat.guardiandaytemplateid}")
	private String guardianDayTemplateId;
	
	/**
	 * 教师-授课日报模板
	 */
	@Value("${wechat.teacherdaytemplateid}")
	private String teacherDayTemplateId;
	
	/**
	 * 家长-学生热报模板
	 */
	@Value("${wechat.hotreporttemplateid}")
	private String hotReportTemplateId;
	
	@Autowired
    private FamilyMapper familyMapper;

	/**
	 * 微信推送家长-学生学习日报
	 * @param sendDO
	 * @return
	 */
	public boolean sendWeixinMessage(SendWeixinUserMqDO sendDO) {
		String accessToken = wxService.getAccessToken();
		// 编辑模块消息
		TemplateMessage templateMessage = new TemplateMessage();
		templateMessage.setTemplate_id(guardianDayTemplateId);
		templateMessage.setTouser(sendDO.getStudengtOpenId());
		templateMessage.setUrl(sendDO.getLink());

		LinkedHashMap<String, TemplateMessageItem> linkedHashMap = new LinkedHashMap<String, TemplateMessageItem>();
		//报告名称
		TemplateMessageItem item1 = new TemplateMessageItem("每日学情报告", "#173177");
		//学生姓名
		TemplateMessageItem item2 = new TemplateMessageItem(sendDO.getStudentName(), "#173177");
		//日期
		TemplateMessageItem item3 = new TemplateMessageItem(sendDO.getReportDate(), "#173177");
		TemplateMessageItem item4 = new TemplateMessageItem("谢谢您的使用", "#173177");
		linkedHashMap.put("first",new TemplateMessageItem("您有一份" + sendDO.getStudentName() + "同学的学情日报，已经更新，请及时查看", "#173177"));
		linkedHashMap.put("keyword1", item1);
		linkedHashMap.put("keyword2", item2);
		linkedHashMap.put("keyword3", item3);
		linkedHashMap.put("remark", item4);
		templateMessage.setData(linkedHashMap);
		TemplateMessageResult templateMessageResult = MessageAPI.messageTemplateSend(accessToken, templateMessage);
		if(log.isInfoEnabled()) {
			log.debug("*****每日学情 微信推送结果：{}",JSONObject.fromObject(templateMessageResult).toString());
		}
		return templateMessageResult.isSuccess();
	}

	/**
	 * 微信推送教师-授课日报
	 * @param sendDO
	 * @return
	 */
	public boolean sendWeixinMessageToTeacher(SendWeixinUserMqDO sendDO) {
		String accessToken = wxService.getAccessToken();
		if(log.isInfoEnabled()) {
			log.debug("微信公众号AccessToken：{}",accessToken);
		}
		// 编辑模块消息
		TemplateMessage templateMessage = new TemplateMessage();
		templateMessage.setTemplate_id(teacherDayTemplateId);
		templateMessage.setTouser(sendDO.getStudengtOpenId());
		templateMessage.setUrl(sendDO.getLink());

		LinkedHashMap<String, TemplateMessageItem> linkedHashMap = new LinkedHashMap<String, TemplateMessageItem>();
		//报告名称
		TemplateMessageItem item1 = new TemplateMessageItem("智慧课堂授课日报", "#173177");
		//教师姓名
		TemplateMessageItem item2 = new TemplateMessageItem(sendDO.getStudentName(), "#173177");
		//报告日期
		TemplateMessageItem item3 = new TemplateMessageItem(sendDO.getReportDate(), "#173177");
		TemplateMessageItem remark = new TemplateMessageItem("谢谢您的使用", "#173177");
		//结尾remark
		linkedHashMap.put("first",new TemplateMessageItem("您的数据报告已经更新，请及时查看", "#173177"));
		linkedHashMap.put("keyword1", item1);
		linkedHashMap.put("keyword2", item2);
		linkedHashMap.put("keyword3", item3);
		linkedHashMap.put("remark", remark);
		templateMessage.setData(linkedHashMap);
		TemplateMessageResult templateMessageResult = MessageAPI.messageTemplateSend(accessToken, templateMessage);
		if(log.isInfoEnabled()) {
			log.debug("*****智慧课堂课堂授课日报 微信推送结果：{}",JSONObject.fromObject(templateMessageResult).toString());
		}
		return templateMessageResult.isSuccess();
	}
	
	/**
	 * 微信推送家长-学生热报
	 * @param data
	 * @return
	 */
	@TargetDataSource("ds1")
	public boolean sendHotReport(SendWeixinUserHotReportMqDo data) {
		try {
			String accessToken = wxService.getAccessToken();
			if (log.isInfoEnabled()) {
				log.debug("微信公众号AccessToken：{}", accessToken);
			}
			List<String> guardianOpenIds = null;
			if (data != null) {
				//获取发送目标用户的openId
				guardianOpenIds = familyMapper.getGuardianOpenId(data.getStudentId());
			}
			if (log.isInfoEnabled()) {
				log.debug("家长guardianOpenId：{}", guardianOpenIds);
			}
			if (guardianOpenIds == null) {
				return true;
			}
			StringBuffer sb = new StringBuffer("\n");
			List<String> listData = data.getContents();
			listData.iterator().forEachRemaining(item -> sb.append(item).append("\n"));
			// 编辑模块消息
			for (String guardianOpenId : guardianOpenIds) {
				TemplateMessage templateMessage = new TemplateMessage();
				templateMessage.setTemplate_id(hotReportTemplateId);
				templateMessage.setTouser(guardianOpenId);
				templateMessage.setUrl(data.getLink());

				LinkedHashMap<String, TemplateMessageItem> linkedHashMap = new LinkedHashMap<String, TemplateMessageItem>();
				// 学生姓名
				TemplateMessageItem item1 = new TemplateMessageItem(data.getStudentName(), "#173177");
				// 上课教师
				TemplateMessageItem item2 = new TemplateMessageItem(data.getTeacherName(), "#173177");
				// 上课科目
				TemplateMessageItem item3 = new TemplateMessageItem(data.getLessonName(), "#173177");
				// 上课时间
				TemplateMessageItem item4 = new TemplateMessageItem(data.getLessonTime(), "#173177");
				// remark
				TemplateMessageItem remark = new TemplateMessageItem("您可以进入e家e校内查看历史热报!", "#173177");
				linkedHashMap.put("first", new TemplateMessageItem(sb.toString(), "#173177"));
				linkedHashMap.put("keyword1", item1);
				linkedHashMap.put("keyword2", item2);
				linkedHashMap.put("keyword3", item3);
				linkedHashMap.put("keyword4", item4);
				linkedHashMap.put("remark", remark);
				templateMessage.setData(linkedHashMap);
				TemplateMessageResult templateMessageResult = MessageAPI.messageTemplateSend(accessToken,templateMessage);
				if (log.isInfoEnabled()) {
					log.debug("*****课堂热报 微信推送结果：{}", JSONObject.fromObject(templateMessageResult).toString());
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("*****课堂热报发送失败：{}", e.getMessage());
			return false;
		}
	}
}
