package com.cjhsc.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjhsc.annotation.TargetDataSource;
import com.cjhsc.basic.request.BasicRequest;
import com.cjhsc.constant.HttpRequestMethodEnum;
import com.cjhsc.mapper.DbDao;
import com.cjhsc.util.EncodeUtils;

/**
 * 
*   
* 项目名称：CJHSC  
* 类名称：.CJYunApiService  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:12:55
* 描述：
*
 */
@Service
public class CJYunApiService extends BasicRequest {
	@Autowired
	private DbDao dbDao;
	/**
	 * 通过手机获取注册验证码
	 * @param mobile
	 * @return
	 * @throws Exception
	 */	
	public String sendPhoneCode(String mobile) throws Exception {
		Map<String,String> requesetParams = new HashMap<>();
		//手机号码
		requesetParams.put("mobile", mobile);
		//是否重置验证码(true or false)
		requesetParams.put("reset", "true");
		//验证码有效时长(毫秒)
		requesetParams.put("lifeTime", "72000000");
		//来源系统标识(e家e校: CJHSC e采与平台: CJYUN)
		requesetParams.put("flag", "CJHSC");
		return getApiData("unlogin/VerificationCode", null,requesetParams, HttpRequestMethodEnum.GET);
	}

	/**
	 * 验证手机验证码
	 * @param mobile
	 * @param verifyCode
	 * @return
	 * @throws Exception
	 */
	public String checkPhoneCode(String mobile, String verifyCode) throws Exception {
		Map<String,String> requesetParams = new HashMap<>();
		//手机号码
		requesetParams.put("mobile", mobile);
		//手机验证码
		requesetParams.put("verifyCode", verifyCode);
		return getApiData("unlogin/verCodeValidity", null,requesetParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 家长注册
	 * @param phone 手机号码/用户名
	 * @param phonecode 手机验证码
	 * @param password 密码
	 * @param realName 姓名
	 * @param guardianOpenId
	 * @return
	 * @throws Exception
	 */
	public String guardianRegister(String phone, String phonecode, String password, String realName,String guardianOpenId) throws Exception {
		Map<String,String> requesetParams = new HashMap<>();
		requesetParams.put("userName", phone);
		requesetParams.put("password", password);
		requesetParams.put("realName", realName);
		requesetParams.put("mobile", phone);
		requesetParams.put("verifyCode", phonecode);
		requesetParams.put("type", "GUARDIAN");
		requesetParams.put("guardianOpenId", guardianOpenId);
		return postUri("unlogin/register", null,requesetParams);
	}

	/**
	 * 教师登录
	 * @param userName
	 * @param passWord
	 * @return
	 * @throws Exception
	 */
	public String teacherLogin(String userName, String passWord) throws Exception {
		Map<String,String> requesetParams = new HashMap<>();
		//手机号码/用户名
		requesetParams.put("userName", userName);
		//密码
		requesetParams.put("password", EncodeUtils.md5Encode(passWord, true));
		return getApiData("unlogin/login?userName="+userName+"&password="+EncodeUtils.md5Encode(passWord, true), null,requesetParams, HttpRequestMethodEnum.POST);
	}
	/**
	 * 检测手机关联账号并进行微信绑定
	 * @param mobile
	 * @param openId
	 * @return
	 * @throws Exception
	 */
	public String detectBindWeChatUser(String mobile, String openId)throws Exception {
		Map<String,String> requesetParams = new HashMap<>();
		requesetParams.put("mobile", mobile);
		requesetParams.put("openId", openId);
		return getApiData("unlogin/detectMobileAndBindWeChat", null,requesetParams, HttpRequestMethodEnum.GET);
	}

	/**
	 * 绑定学生
	 * @param studentName
	 * @param verificationCode
	 * @param familyRelationCode
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String bindStudent(String studentName, String verificationCode, String familyRelationCode,String token)throws Exception  {
		List<Map<String,Object>> students = new ArrayList<>();
		Map<String,Object> student = new HashMap<String,Object>();
		student.put("studentName", studentName);
		student.put("verificationCode", verificationCode);
		student.put("familyRelationCode", familyRelationCode);
		students.add(student);
		Map<String,String> headerParams = new HashMap<>();
		headerParams.put("token", token);
		return getApiData4Array("guardian/bindChildren", headerParams,students, HttpRequestMethodEnum.POST);
	}
	/**
	 * 查询绑定学生列表
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String getbindStudentList(String token) throws Exception  {
		Map<String,String> headerParams = new HashMap<>();
		headerParams.put("token", token);
		return getApiData("guardian/children", headerParams,null, HttpRequestMethodEnum.GET);
	}
	/**
	 * 查询学生关系
	 * @return
	 * @throws Exception
	 */
	public String getFamilyRelactiont() throws Exception{
		return getApiData("guardian/familyRelation", null,null, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 微信教师主页 - 学期统计指标(我的智慧课堂-顶部)
	 * @param teacherId
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String teacherStatis(String teacherId,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/statis", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 教师主页 - 日授课总数统计(我的智慧课堂-授课日报) 旧接口
	 * @param teacherId
	 * @param page
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String teacherDayLessonCount(String teacherId,String page,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("page", page);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/dayLessonCount", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 教师主页 - 课堂观察报告列表（日统计）
	 * @param teacherId
	 * @param page
	 * @param pageSize
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String teacherDayLessonCountNew(String teacherId,String page,String pageSize,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("page", page);
		requestParams.put("pageSize", pageSize);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/dayStatic", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 教师日授课统计 旧接口
	 * @param teacherId
	 * @param teachingDate
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String teacherDayLesson(String teacherId, String teachingDate,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/dayLesson", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 查询老师所教的班级
	 * @param teacherId
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String teacherClass(String teacherId,String token) throws Exception{
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData("guardian/teacherDetails", headParamMap,null, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 微信教师授课日报 - 课堂统计
	 * @param teacherId
	 * @param teachingDate
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String teacherDayLessonNew(String teacherId, String teachingDate,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/lessonStatic", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 微信教师授课日报 - 获取正确率，关注度和活跃度
	 * @param teacherId
	 * @param teachingDate
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String lessonEntiretyTarget(String teacherId, String teachingDate,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/lessonEntiretyTarget", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 微信教师授课日报 - 教师课堂授课详情(授课日报-课堂详情)旧接口
	 * @param teacherId
	 * @param teachingDate
	 * @param lessonId
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String teacherLesson(String teacherId, String teachingDate, String lessonId,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("teachingDate", teachingDate);
		requestParams.put("lessonId", lessonId);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/specificLesson", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 微信教师授课日报 - 教师课堂授课详情(授课日报-课堂详情)
	 */
	public String teacherLessonNew(String teacherId, String teachingDate, String lessonId,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("teachingDate", teachingDate);
		requestParams.put("lessonId", lessonId);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/lessonTotalStatic", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 学生授课日课堂统计
	 * @param studentId
	 * @param teachingDate
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentLesson(String studentId, String teachingDate,String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/dayLesson", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 学生授课日总统计 
	 * @param studentId
	 * @param teachingDate
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentDayStatis(String studentId, String teachingDate, String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/dayLessonStatis", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}

	/**
	 * 
	 * @param guardianOpenId
	 * @return
	 * @throws Exception
	 */
	public String loginByOpenId(String guardianOpenId) throws Exception {
		Map<String,String> requesetParams = new HashMap<>();
		requesetParams.put("openId", guardianOpenId);
		return postUri("unlogin/homeSchoolLogin", null,requesetParams);
	}
	
	/**
	 * 
	 * @param question
	 * @return
	 */
	@TargetDataSource("ds1")
	public List<Map<Object,Object>> getCommonQa(String question) {
		return dbDao.getCommonQaList(question);
	}

	//@TargetDataSource("ds1")
	//public String getOpenIdByPhone(String phone) {
	//	return dbDao.getOpenIdByPhone(phone);
	//}
	
	//@TargetDataSource("ds1")
	//public String getOpenIdByUserId(Integer userId) {
	//	return dbDao.getOpenIdByUserId(userId);
	//}
	//@TargetDataSource("ds1")
	//public void saveBindInfo(Integer userId,String openId,String phone) {
		//dbDao.saveBindInfo(userId,openId,phone);
	//}
	//@TargetDataSource("ds1")
	//public String getOpenIdByUserId(Integer userId) {
	//	return dbDao.getOpenIdByUserId(userId);
	//}
	//@TargetDataSource("ds1")
	//public void saveBindInfo(Integer userId,String openId,String phone) {
	//	dbDao.saveBindInfo(userId,openId,phone);
	//}
	/**
	 * 变更密码
	 * @param oldPassword
	 * @param newPassword
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String updatePassword(String oldPassword, String newPassword, String token) throws Exception{
		Map<String,Object> requestParams = new HashMap<String,Object>();
		requestParams.put("oldPassword", oldPassword);
		requestParams.put("newPassword", newPassword);
		Map<String,String> headerParams = new HashMap<>();
		headerParams.put("token", token);
		return getApiDataUri("unverify/updatePassword", headerParams,requestParams, HttpRequestMethodEnum.POST);
	}

	/**
	 * @param guardianOpenId
	 * @param studentId
	 * @return
	 * @throws Exception
	 */
	public String getStudentJwtByOpeId(String guardianOpenId, String studentId)  throws Exception {
		Map<String,Object> requestParams = new HashMap<String,Object>();
		requestParams.put("openId", guardianOpenId);
		requestParams.put("studentId", studentId);
		return getApiData("guardian/getStudentJwt", null,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 
	 * @param openId
	 * @return
	 * @throws Exception
	 */
	public String getTeacherInfo(String openId) throws Exception {
		Map<String,String> requesetParams = new HashMap<>();
		requesetParams.put("openId", openId);
		return getApiData("unlogin/homeSchoolLogin", null,requesetParams, HttpRequestMethodEnum.POST);
	}
	
	/**
	 * 
	 * @param userId
	 * @param openId
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public String bindUserByOpenId(String userId,String openId,String type)throws Exception {
		Map<String,String> requesetParams = new HashMap<>();
		requesetParams.put("openId", openId);
		requesetParams.put("userId", userId);
		requesetParams.put("type", type);
		return getApiData("guardian/bindOpenId", null,requesetParams, HttpRequestMethodEnum.POST);
	}
	/**
	 * 退出登录
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String logout(String token) throws Exception{
		Map<String,String> headerParams = new HashMap<>();
		headerParams.put("token", token);
		return getApiData("/unlogin/logout", headerParams,null, HttpRequestMethodEnum.POST);
	}
	/**
	 * 
	 * @param guardianOpenId
	 * @param studentId
	 * @return
	 */
	@TargetDataSource("ds1")
	public Map<String, Object> getStudentLastReportDate(String guardianOpenId, String studentId) {
		return dbDao.getStudentLastReportDate(guardianOpenId,studentId);
	}

		
	/**
	 * 学情报告主页-顶部统计
	 * @param schoolIds
	 * @param studentIds
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentStatis(String schoolIds,String studentIds,String token) throws Exception{
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("schoolIds", schoolIds);
		requestParams.put("studentIds", studentIds);
		return getApiData4Cjtlis("analysis/weixin/student/static", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 学情报告主页-学生学情日报列表
	 * @param page
	 * @param pageSize
	 * @param studentIds
	 * @param schoolIds
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentDayStatisNew(String page,String pageSize,String studentIds,String schoolIds,String token) throws Exception{
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("page", page);
		requestParams.put("pageSize", pageSize);
		requestParams.put("schoolIds", schoolIds);
		requestParams.put("studentIds", studentIds);
		return getApiData4Cjtlis("analysis/weixin/student/dayRecords", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 学生学习日报-课堂报告
	 * @param studentId
	 * @param teachingDate
	 * @param schoolIds
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentLessonStatis(String studentId, String teachingDate,String schoolIds, String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("schoolIds", schoolIds);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/lessonTotalStatic", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 学生学习日报-课堂报告（科目列表）
	 * @param studentId
	 * @param teachingDate
	 * @param schoolIds
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentLessonStatisList(String studentId, String teachingDate,String schoolIds, String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("schoolIds", schoolIds);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/lessonStatic", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 学习日报顶部当天 表扬 批评 最佳次数
	 * @param studentId
	 * @param teachingDate
	 * @param schoolIds
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentLessonStatisData(String studentId, String teachingDate,String schoolIds, String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("schoolIds", schoolIds);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/dayStatic", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 学生学习日报-作业报告-今日作业概览
	 * @param studentId
	 * @param teachingDate
	 * @param schoolIds
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentTodayHomeworkStatis(String studentId, String teachingDate,String schoolIds, String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("schoolIds", schoolIds);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/assignDayHomeWorkStatis", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 学生学习日报-作业报告-上次作业情况
	 * @param studentId
	 * @param teachingDate
	 * @param schoolIds
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studentYesterdayHomeworkStatis(String studentId, String teachingDate,String schoolIds, String token) throws Exception {
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("schoolIds", schoolIds);
		requestParams.put("teachingDate", teachingDate);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/correctionDayHomeWorkStatis", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 学生记录阅读状态
	 * @param studentId
	 * @param teachingDate
	 * @param guardianOpenId
	 * @return
	 */
	@TargetDataSource("ds1")
	public Integer getStudentReadStatus(Integer studentId, String teachingDate,String guardianOpenId) {
		return dbDao.getStudentReadStatus(studentId,teachingDate,guardianOpenId);
	}
	/**
	 * 教师记录阅读状态
	 * @param teacherId
	 * @param teachingDate
	 * @return
	 */
	@TargetDataSource("ds1")
	public Integer getTeacherReadStatus(String teacherId, String teachingDate) {
		return dbDao.getTeacherReadStatus(teacherId,teachingDate);
	}
	/**
	 * 修改学生记录阅读状态
	 * @param studentId
	 * @param teachingDate
	 * @param guardianOpenId
	 */
	@TargetDataSource("ds1")
	public void updateStudentReadStatus(String studentId, String teachingDate, String guardianOpenId) {
		dbDao.updateStudentReadStatus(studentId,teachingDate,guardianOpenId);		
	}
	/**
	 * 修改教师记录阅读状态
	 * @param teacherId
	 * @param teachingDate
	 */
	@TargetDataSource("ds1")
	public void updateTeacherReadStatus(String teacherId, String teachingDate) {
		dbDao.updateTeacherReadStatus(teacherId,teachingDate);	
	}
	/**
	 * 孩子学习方法分析
	 * @param studentId
	 * @param period
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String studyPortrait(String studentId, String period, String token)throws Exception {
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("recentDays", period);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/student/method", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 教师学情分析-班级整体表现
	 * @param teacherId 教师Id
	 * @param classId	班级ID
	 * @param subjectId 科目ID
	 * @param period 最近几天,最近7天提交7,最近30天提交30,本学期提交semester
	 * @param token
	 * @return
	 * @throws Exception 
	 */
	public String classPerformance(String teacherId,String classId,String subjectId, String period, String token) throws Exception {
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("recentDays", period);
		requestParams.put("classId", classId);
		requestParams.put("subjectId", subjectId);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/class/meanScore", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	/**
	 * 孩子最近表现趋势(图表数据)
	 * @param studentId
	 * @param period
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String performanceTrendListData(String studentId, String period, String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		requestParams.put("dimension", period);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/manifestationTendency", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 孩子最近表现趋势
	 * @param studentId
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String performanceTrend(String studentId, String token) throws Exception{
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("studentId", studentId);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/student/manifestation", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}

	/**
	 * 班级最近表现趋势(图表数据)
	 * @param teacherId
	 * @param period
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String classPerformanceTrendChartData(String teacherId,String classId,String subjectId, String period, String token) throws Exception {
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("dimension", period);
		requestParams.put("classId", classId);
		requestParams.put("subjectId", subjectId);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/manifestationTendency", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}
	
	/**
	 * 班级最近表现趋势
	 * @param teacherId
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public String classPerformanceTrend(String teacherId,String classId,String subjectId,String token) throws Exception {
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("teacherId", teacherId);
		requestParams.put("classId", classId);
		requestParams.put("subjectId", subjectId);
		Map<String, String> headParamMap = new HashMap<>();
		headParamMap.put("token", token);
		return getApiData4Cjtlis("analysis/weixin/teacher/manifestation", headParamMap,requestParams, HttpRequestMethodEnum.GET);
	}

	/**
	 * 解除微信账号的绑定
	 * @param token
	 */
	public void deleteWeChatBind(String token)  throws Exception{
		Map<String,String> headerParams = new HashMap<>();
		headerParams.put("token", token);
		getApiData("guardian/deleteWeChatBinding", headerParams,null, HttpRequestMethodEnum.DELETE);
	}

	/**
	 * 学生课堂热报
	 * @param token
	 * @return
	 */
	public String hotreports(String token,String pageNo,String pageSize) throws Exception {
		Map<String,String> headerParams = new HashMap<>();
		headerParams.put("token", token);
		Map<String,String> requestParams = new HashMap<>();
		requestParams.put("page", pageNo);
		requestParams.put("pageSize", pageSize);
		return getApiData4Cjtlis("analysis/weixin/student/hotreports", headerParams,requestParams, HttpRequestMethodEnum.GET);
	}
}
