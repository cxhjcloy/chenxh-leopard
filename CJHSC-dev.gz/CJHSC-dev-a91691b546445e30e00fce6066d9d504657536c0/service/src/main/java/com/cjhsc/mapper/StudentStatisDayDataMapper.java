package com.cjhsc.mapper;

import com.cjhsc.domodal.SendWeixinUserMqDO;
import com.cjhsc.domodal.StudentStatDateDo;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.mapper.StudentStatisDayDataMapper  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:35:56
* 描述：
*
 */
@Repository
@Mapper
public interface StudentStatisDayDataMapper {

    @Select({"<script>" +
            "select v_open_id as openId,  ui_student_id as studentId from tb_student_last_teachingday_status where" +
            " date(dt_last_teaching_date) = #{pageDate} and ui_read_status = 0 and  ui_student_id  in " +
            "<foreach item=\"item\" index=\"index\" collection=\"studentIds\" open=\"(\" separator=\",\" close=\")\">" +
            "#{item}" +
            "</foreach>" +
            "</script>"})
    List<Map<String, String>> getStudentList(Map<String, Object> paramMap);


    @Insert("replace into tb_student_last_teachingday_status(v_open_id,ui_student_id, dt_last_teaching_date,ui_read_status) values(#{openId},#{studentId}, #{statDate},0)")
    void updateUserStudentStatDay(StudentStatDateDo studentStatDateDo);


    @Select({"<script>" +
            "select  ui_teacher_id as studentId from tb_teacher_read_status where ui_push_status = 1 and ui_read_status = 0 and" +
            " date(d_teaching_date) = #{pageDate} and  ui_teacher_id  in " +
            "<foreach item=\"item\" index=\"index\" collection=\"teacherInfoList\" open=\"(\" separator=\",\" close=\")\">" +
            "#{item.studentId}" +
            "</foreach>" +
            "</script>"})
	List<SendWeixinUserMqDO> getSendedTeacherList(@Param("teacherInfoList")List<SendWeixinUserMqDO> teacherInfoList, @Param("pageDate")String pageDate);

    @Insert("replace into tb_teacher_read_status(ui_teacher_id,d_teaching_date, ui_read_status,ui_push_status) values(#{sendWeixinUserMqDO.studentId},#{pageDate}, 0,1)")
	int saveTeacherSendData(@Param("sendWeixinUserMqDO")SendWeixinUserMqDO sendWeixinUserMqDO, @Param("pageDate")String pageDate);

}
