package com.cjhsc.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjhsc.annotation.TargetDataSource;
import com.cjhsc.dbmodel.DbModel;
import com.cjhsc.mapper.DbDao;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.service.DbService  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:36:25
* 描述：
*
 */
@Service
public class DbService {
	
	private static final Logger log = LoggerFactory.getLogger(DbService.class);
	@Autowired
    private DbDao dbDao;
	@TargetDataSource("defaultDataSource")
	public  List<DbModel> getList(){
		log.debug("--");
		return dbDao.getList();
	}
	
	public List<DbModel> getList11(){
		return ((DbService)AopContext.currentProxy()).getList1();
	}
	
	@TargetDataSource("ds1")
	public  List<DbModel> getList1(){
		return dbDao.getList1();
	}
}
