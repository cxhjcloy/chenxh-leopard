package com.cjhsc.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.DataType;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.SendResult;
import com.aliyun.openservices.ons.api.bean.ProducerBean;
import com.cjhsc.annotation.TargetDataSource;
import com.cjhsc.basic.request.FamilyListRequest;
import com.cjhsc.domodal.SendWeixinUserMqDO;
import com.cjhsc.domodal.StudentStatDateDo;
import com.cjhsc.mapper.CjtlisDateLogResultRecordMapper;
import com.cjhsc.mapper.FamilyMapper;
import com.cjhsc.mapper.StudentStatisDayDataMapper;

import net.sf.json.JSONObject;

/**
 * 
*   
* 项目名称：cjhsc-service  
* 类名称：com.cjhsc.service.SendWeixinUserMqService  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:37:15
* 描述：
*
 */
@Service
@SuppressWarnings({"unchecked", "rawtypes"})
public class SendWeixinUserMqService {
    private static final Logger log = LoggerFactory.getLogger(SendWeixinUserMqService.class);
    @Autowired
    private FamilyMapper familyMapper;

    @Autowired
    private FamilyListRequest familyListRequest;
    @Autowired
    private StudentStatisDayDataMapper studentStatisDayDataMapper;

    @Autowired
    private CjtlisDateLogResultRecordMapper cjtlisDateLogResultRecordMapper;

    @Autowired
    ProducerBean producer;
    @Autowired
	private RedisTemplate redisTemplate;
    
    /**
     * mq topic
     */
    @Value("${mq.topic}")
    private String mqTopic;
    @Value("${mq.parenttag}")
    private String parentMqTag;
    @Value("${mq.teachertag}")
    private String teacherMqTag;
    @Value("${mq.hotreport}")
    private String hotReportTag;
    @Value("${mq.rediskey}")
    private String rediskey;
    private static final long CACHETIME = 20L;
    /**
     * 发送微信消息<家长>
     *
     * @param selectDate
     * @throws Exception
     */
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public void process(String selectDate) throws Exception {
    	try {
    		long sleepTime = RandomUtils.nextLong(1500L, 5000L);
    		/**
    		 * 线程sleep一个随机时间，防止分页计数器cjhsc_guardian_page_counter被并发多线程多次初始化。
    		 */
    		Thread.sleep(sleepTime);
    	}catch (Exception e) {
			//..
		}
    	if(redisTemplate.opsForValue().get("cjhsc_guardian_page_counter") == null) {
    		redisTemplate.opsForValue().set("cjhsc_guardian_page_counter", 1, CACHETIME, TimeUnit.MINUTES);
    	}else {
    		//...
    	}
        if (this.checkStaticTaskStatus(selectDate)) {
        	/**
        	 * 并发时，每个线程获取自己的分页数据
        	 */
        	int currentPage = (int) redisTemplate.opsForValue().get("cjhsc_guardian_page_counter");
        	Map<String, List<String>> studentIdAndOpenIdMap = familyListRequest.getStudentAndOpenIdMap(currentPage);
            int pageCount = familyListRequest.getPageCount();
            if (pageCount != 0) {
                bitchSendMq(studentIdAndOpenIdMap, selectDate);
                while (currentPage != pageCount) {
                	/**
                	 * 计数器先自增。
                	 */
                	redisTemplate.opsForValue().increment("cjhsc_guardian_page_counter", 1);//自增1
                	currentPage = (int) redisTemplate.opsForValue().get("cjhsc_guardian_page_counter");
                    studentIdAndOpenIdMap = familyListRequest.getStudentAndOpenIdMap(currentPage);
                    bitchSendMq(studentIdAndOpenIdMap, selectDate);
                }
            }
        }
    }

    /**
     * 检查学情统计任务状态
     *
     * @param selectDate String 查询日期
     * @return boolean 完成返回true,未完成返回false
     */
    private boolean checkStaticTaskStatus(String selectDate) {
        int unStaticLessonCount = cjtlisDateLogResultRecordMapper.findUnStaticLessonCount(selectDate);
        log.debug("未统计课堂记录数{}",unStaticLessonCount);
        return unStaticLessonCount == 0 ? true : false;
    }


    /**
     * 处理发送mq消息<家长>
     *
     * @param studentIdAndOpenIdMap
     * @param pageDate
     */
    private void bitchSendMq(Map<String, List<String>> studentIdAndOpenIdMap, String pageDate) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("pageDate", pageDate);
        Set allStudentIds = new HashSet();
        studentIdAndOpenIdMap.entrySet().forEach(x -> allStudentIds.addAll(x.getValue()));
        if (allStudentIds.size() == 0) {
        	log.debug("若查不到绑定学生信息 不进行后续处理");
            return;
        }
        paramMap.put("studentIds", allStudentIds.toArray());
        List<Map<String, String>> studentList = ((SendWeixinUserMqService) AopContext.currentProxy()).fetchTeachingStudent(paramMap);
        List<Map<String, String>> sendStudentList = ((SendWeixinUserMqService) AopContext.currentProxy()).checkSendStudent(paramMap);
        Map<String, String> studentIdAndNameMap = new HashMap();
        studentList.forEach(map -> studentIdAndNameMap.put(String.valueOf(map.get("studentId")), map.get("studentName")));
        Map<String, String> userStatStudentIdMap = new HashMap();
        sendStudentList.forEach(map -> userStatStudentIdMap.put(String.valueOf(map.get("openId")), String.valueOf(map.get("studentId"))));

        log.debug("关联微信账号绑定学生数据" + studentIdAndOpenIdMap);
        log.debug("有学情日报数据学生" + userStatStudentIdMap);


        List<SendWeixinUserMqDO> sendWeixinUserMqDOList = new ArrayList<>();
        if (!studentList.isEmpty()) {
            studentIdAndOpenIdMap
                    .entrySet()
                    .stream()
                    .filter(entry -> !(Collections.disjoint(studentIdAndNameMap.keySet(), entry.getValue())))
                    .forEach(
                            (Map.Entry<String, List<String>> entry) ->
                                    entry.getValue().forEach(
                                            studentId -> {
                                                {
                                                    if (studentIdAndNameMap.keySet().contains(studentId)) {
                                                        log.debug("推送数据学生ID:" + studentId);
                                                        String openId = entry.getKey();
                                                        if (!userStatStudentIdMap.containsKey(openId) &&(null == userStatStudentIdMap.get(openId) ||!userStatStudentIdMap.get(openId).equals(studentId))) {  //不存在  openId  studentId
                                                            log.debug(openId + "-------" + studentId);
                                                            try {
                                                                this.sendMqMessage(new SendWeixinUserMqDO(studentIdAndNameMap.get(studentId), studentId, openId, pageDate), parentMqTag);
                                                                sendWeixinUserMqDOList.add(new SendWeixinUserMqDO(openId, studentId));
                                                            } catch (Exception e) {
                                                                log.error("学生推送消息发送失败，原因：{}", e.getMessage());
                                                                e.getMessage();
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                    )
                    );
            log.debug("更新家长openId与学生推送日期列表" + sendWeixinUserMqDOList);
            ((SendWeixinUserMqService) AopContext.currentProxy()).updateBindStudentStatData(sendWeixinUserMqDOList, pageDate);
        }
    }


    /**
     * 更新学生最新日报日期
     *
     * @param map      Map
     * @param pageDate String
     */
    @TargetDataSource("ds1")
    @Transactional
    public void updateBindStudentStatData(List<SendWeixinUserMqDO> map, String pageDate) {
        map.forEach(
                (sendWeixinUserMqDO) -> {
                    studentStatisDayDataMapper.updateUserStudentStatDay(
                            new StudentStatDateDo(sendWeixinUserMqDO.getParentOpenId(), sendWeixinUserMqDO.getStudentId(), pageDate)
                    );
                }
        );
    }

    /**
     * 发送消息
     *
     * @param sendDO SendWeixinUserMqDO
     */

    private void sendMqMessage(SendWeixinUserMqDO sendDO, String tag) {
        log.debug(sendDO.toString());
        Message message = new Message(this.mqTopic, tag, JSONObject.fromObject(sendDO).toString().getBytes());
        SendResult sendResult = producer.send(message);
        if (sendResult != null) {
            log.debug(new Date() + " 发送消息成功");
        } else {
            log.error("发送失败");
            throw new RuntimeException("发送失败");
        }
    }

    @TargetDataSource("ds2")
    @Transactional(readOnly = true)
    public List fetchTeachingStudent(Map paramMap) {
        return familyMapper.getStudentList(paramMap);
    }

    /**
     * 查询
     *
     * @param paramMap
     * @return
     */
    @TargetDataSource("ds1")
    @Transactional(readOnly = true)
    public List checkSendStudent(Map paramMap) {
        return studentStatisDayDataMapper.getStudentList(paramMap);
    }

    /**
     * 发送微信消息<教师>
     *
     * @param selectDate
     * @throws Exception
     * 描述 处理方式同家长
     */
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public void process4Teachers(String selectDate) throws Exception {
    	try {
    		long sleepTime = RandomUtils.nextLong(1500L, 5000L);
    		Thread.sleep(sleepTime);
    	}catch (Exception e) {
			//..
		}
    	if(redisTemplate.opsForValue().get("cjhsc_teacher_page_counter") == null) {
    		redisTemplate.opsForValue().set("cjhsc_teacher_page_counter", 1, CACHETIME, TimeUnit.MINUTES);
    	}else {
    		//...
    	}
        if (this.checkStaticTaskStatus(selectDate)) {
        	int currentPage = (int) redisTemplate.opsForValue().get("cjhsc_teacher_page_counter");
            List<SendWeixinUserMqDO> teacherInfoList = familyListRequest.getTeachersAndOpenIdMap(currentPage);
            int pageCount = familyListRequest.getPageCount();
            if (pageCount != 0) {
                if (teacherInfoList != null && teacherInfoList.size() > 0) {
                    batchSendMqToTeacher(teacherInfoList, selectDate);
                }
                while (currentPage != pageCount) {
                	redisTemplate.opsForValue().increment("cjhsc_teacher_page_counter", 1);
                	currentPage = (int) redisTemplate.opsForValue().get("cjhsc_teacher_page_counter");
                    teacherInfoList = familyListRequest.getTeachersAndOpenIdMap(currentPage);
                    if (teacherInfoList != null && teacherInfoList.size() > 0) {
                        batchSendMqToTeacher(teacherInfoList, selectDate);
                    }
                }
            }
        }
    }


    /**
     * 处理发送mq消息<教师>
     *
     * @param teacherInfoList
     * @param pageDate
     */
    private void batchSendMqToTeacher(List<SendWeixinUserMqDO> teacherInfoList, String pageDate) {
        List<SendWeixinUserMqDO> teacherList4SendWx = ((SendWeixinUserMqService) AopContext.currentProxy()).getTeaching4SendWx(teacherInfoList, pageDate);
        List<SendWeixinUserMqDO> sendedTeacherList = ((SendWeixinUserMqService) AopContext.currentProxy()).getSendedTeacherList(teacherInfoList, pageDate);
        teacherList4SendWx.removeAll(sendedTeacherList);
        if (teacherList4SendWx.isEmpty()) {
            if (log.isInfoEnabled()) {
                log.debug("此次查询不到需要发送的目标教师信息");
            }
            return;
        }
        for (SendWeixinUserMqDO needSend : teacherList4SendWx) {
            for (SendWeixinUserMqDO teach : teacherInfoList) {
                if (teach.getStudentId().equals(needSend.getStudentId())) {
                    needSend.setParentOpenId(teach.getParentOpenId());
                }
            }
            try {
            	needSend.setReportDate(pageDate);
                sendMqMessage(needSend, teacherMqTag);
                ((SendWeixinUserMqService) AopContext.currentProxy()).saveTeacherSendData(needSend, pageDate);
            } catch (Exception e) {
                log.error("教师推送消息发送失败，原因：{}", e.getMessage());
                e.getMessage();
            }
        }
    }

    /**
     * 得到已经发送过的老师信息
     *
     * @param teacherInfoList
     * @param pageDate
     * @return
     */
    @TargetDataSource("ds1")
    @Transactional(readOnly = true)
    public List<SendWeixinUserMqDO> getSendedTeacherList(List<SendWeixinUserMqDO> teacherInfoList, String pageDate) {
        return studentStatisDayDataMapper.getSendedTeacherList(teacherInfoList, pageDate);
    }

    /**
     * 获取需发送的老师信息
     *
     * @param teacherInfoList
     * @param pageDate
     * @return
     */
    @TargetDataSource("ds2")
    @Transactional(readOnly = true)
    public List<SendWeixinUserMqDO> getTeaching4SendWx(List<SendWeixinUserMqDO> teacherInfoList, String pageDate) {
        return familyMapper.getTeaching4SendWx(teacherInfoList, pageDate);
    }

    /**
     * 记录老师的发送记录
     *
     * @param sendWeixinUserMqDO
     * @param pageDate
     * @return
     */
    @TargetDataSource("ds1")
    @Transactional
    public int saveTeacherSendData(SendWeixinUserMqDO sendWeixinUserMqDO, String pageDate) {
        return studentStatisDayDataMapper.saveTeacherSendData(sendWeixinUserMqDO, pageDate);
    }
    
    
    
    /**
     * 发送mq热报消息
     * @throws Exception
     */
    public void setHostReportMq() throws Exception {
    	 if(redisTemplate.hasKey(rediskey) && redisTemplate.type(rediskey) == DataType.LIST ) {
    		 ListOperations<String, String> list = redisTemplate.opsForList();
    		 while(list.size(rediskey)>0) {
    			 String data = list.leftPop(rediskey);
		    	 Message message = new Message(mqTopic, hotReportTag, data.getBytes());
		         SendResult sendResult = producer.send(message);
		         if (sendResult != null) {
		             log.debug(new Date() + " 发送消息成功:"+data);
		         } else {
		             log.error("发送失败");
		             throw new RuntimeException("发送失败");
		         }
    		 }
    	 }
    }
}
