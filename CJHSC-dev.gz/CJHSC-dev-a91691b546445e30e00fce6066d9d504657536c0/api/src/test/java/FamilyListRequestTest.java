import com.cjhsc.BootApplication;
import com.cjhsc.basic.request.FamilyListRequest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

/**
 * Created by 龚举 on 2017/8/7.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = BootApplication.class)
@WebAppConfiguration
public class FamilyListRequestTest {

    @Test
    public void getFamilyListTest() throws Exception {
        //FamilyListRequest request = new FamilyListRequest();
        //request.getFamilyList("1", "2017-07-21");
    }
}
