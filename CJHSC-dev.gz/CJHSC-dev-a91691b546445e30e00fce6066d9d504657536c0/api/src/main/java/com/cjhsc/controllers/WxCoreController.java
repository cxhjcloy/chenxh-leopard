package com.cjhsc.controllers;

import weixin.popular.bean.BaseResult;
import weixin.popular.bean.message.EventMessage;
import weixin.popular.bean.xmlmessage.XMLImageMessage;
import weixin.popular.bean.xmlmessage.XMLMessage;
import weixin.popular.bean.xmlmessage.XMLNewsMessage;
import weixin.popular.bean.xmlmessage.XMLTextMessage;
import weixin.popular.bean.xmlmessage.XMLVideoMessage;
import weixin.popular.bean.xmlmessage.XMLVoiceMessage;
import weixin.popular.bean.xmlmessage.XMLNewsMessage.Article;
import weixin.popular.util.XMLConverUtil;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.cjhsc.service.WxService;
import com.cjhsc.util.EncodeUtils;
import com.cjhsc.util.WxUtils;

/**
 * 
*   
* 项目名称：cjhsc-api  
* 类名称：com.cjhsc.controllers.WxCoreController  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:26:16
* 描述：
*
 */
@RestController
public class WxCoreController {
	private static Logger log = LoggerFactory.getLogger(WxCoreController.class);

	@Value("${wechat.key}")
	private String token;

	@Value("${wechat.appid}")
	private String appid;

	@Value("${wechat.appsecret}")
	private String appsecret;
	@Value("${cbp.host}")
	private String cbphost;

	private final static String SCOPE = "snsapi_base";
	@Value("${webhost}")
	private String webhost;

	@Autowired
	private WxService wxService;

	@Autowired
	private RedisTemplate<String,String> redisTemplate;
	
	@RequestMapping(value = "wx/createMenu", method = RequestMethod.POST)
	public BaseResult createMenu()  throws Exception{
		return wxService.createMenu(getCode());
	}

	@RequestMapping(value = "wx/getMenus", method = RequestMethod.GET)
	public BaseResult getMenus() {
		return wxService.getMenus();
	}

	@RequestMapping(value = "/wx/code", method = RequestMethod.GET)
	public String getWxCode()  throws Exception{
		return getCode();
	}

	@SuppressWarnings("all")
	private String getCode() throws Exception {
		return String.format(
				"https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=%s&state=STAT#wechat_redirect",
				appid, URLEncoder.encode(webhost + "/wx/userinfo","UTF-8"), SCOPE);
	}

	@RequestMapping(value = "/weixin/index", method = RequestMethod.GET)
	public String checkSignature(@RequestParam(name = "signature", required = false) String signature,
			@RequestParam(name = "nonce", required = false) String nonce,
			@RequestParam(name = "timestamp", required = false) String timestamp,
			@RequestParam(name = "echostr", required = false) String echostr) throws Exception {
		if (WxUtils.checkSignature(token, signature, timestamp, nonce)) {
			log.debug("接入成功");
			wxService.createMenu(getCode());
			return echostr;
		}
		log.error("接入失败");
		return "";
	}

	@RequestMapping(value = "/weixin/index", method = RequestMethod.POST)
	public void index(HttpServletRequest request, HttpServletResponse response) {
		try {
			String nonce = request.getParameter("nonce");
			String signature = request.getParameter("signature");
			String timestamp = request.getParameter("timestamp");
			if (WxUtils.checkSignature(token, signature, timestamp, nonce)) {
				ServletInputStream inputStream = request.getInputStream();
				ServletOutputStream outputStream = response.getOutputStream();
				if (inputStream != null) {
					EventMessage eventMessage = XMLConverUtil.convertToObject(EventMessage.class, inputStream);
					String key = eventMessage.getFromUserName() + "_" + eventMessage.getToUserName() + "_" + eventMessage.getMsgId() + "_" + eventMessage.getCreateTime();
					String redisKey = "CJHSC_"+EncodeUtils.md5Encode(key, true);
					if (redisTemplate.opsForValue().getOperations().hasKey(redisKey)) {
						return;
					} else {
						redisTemplate.opsForValue().set(redisKey, key, 30, TimeUnit.SECONDS);
					}
					/***************************消息交互处理**************************************/
					String messageType = eventMessage.getMsgType();
					log.debug("------messageType:{}",messageType);
					switch (messageType) {
						case "text":
							String text = eventMessage.getContent();
							if(text != null && "关于采集".equals(text)) {
								List<Article> articles = new ArrayList<Article>();
								Article article = new Article();
								article.setDescription("深圳市采集科技有限公司成立于2007年9月，以清华大学研究院国家级科研项目为起源，是一家专注于教育信息化的高新技术企业。");
								article.setPicurl(webhost+"welcome.jpg");
								article.setUrl("http://mp.weixin.qq.com/s/XO9sr-5CLhLgGsfAe9cTlA");
								article.setTitle("深圳市采集科技有限公司");
								articles.add(article);
								XMLMessage subscribeMessage = new XMLNewsMessage(eventMessage.getFromUserName(), eventMessage.getToUserName(), articles);
								subscribeMessage.outputStreamWrite(outputStream);
							}else {
								log.debug("用户{}发送的内容是:{}",eventMessage.getFromUserName(),text);
								XMLMessage xmlTextMessage = new XMLTextMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), "您好,感谢使用e家e校,回复功能暂未实现。");
								xmlTextMessage.outputStreamWrite(outputStream);
							}
							break;
						case "image":
							String iamgeMediaId = eventMessage.getMediaId();
							XMLMessage xmlImageMessage = new XMLImageMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), iamgeMediaId);
							xmlImageMessage.outputStreamWrite(outputStream);
							break;
						case "voice":
							String voiceMediaId = eventMessage.getMediaId();
							XMLMessage xmlVoiceMessage = new XMLVoiceMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), voiceMediaId);
							xmlVoiceMessage.outputStreamWrite(outputStream);
							break;
						case "video":
							String videoMediaId = eventMessage.getMediaId();
							String title="title";
							String description="description";
							XMLMessage xmlVideoMessage = new XMLVideoMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), videoMediaId,title,description);
							xmlVideoMessage.outputStreamWrite(outputStream);
							break;
						case "shortvideo":
							String shortvideoMediaId = eventMessage.getMediaId();
							String shortvideoTitle="shortvideoTitle";
							String shortvideoDescription="shortvideoDescription";
							XMLMessage xmlShortvideoMessage = new XMLVideoMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), shortvideoMediaId,shortvideoTitle,shortvideoDescription);
							xmlShortvideoMessage.outputStreamWrite(outputStream);
							break;
						case "location":
							String locationText = "您好,地理位置<"+eventMessage.getLocation_X()+","+eventMessage.getLocation_Y()+">";
							XMLMessage locationTextMessage = new XMLTextMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), locationText);
							locationTextMessage.outputStreamWrite(outputStream);
							break;
						case "link":
							String linkText = "您好,暂时不支持链接信息处理";
							XMLMessage linkTextMessage = new XMLTextMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), linkText);
							linkTextMessage.outputStreamWrite(outputStream);
							break;
						case "event":
							/*********************************交互事件处理*******************************************/
							String event = eventMessage.getEvent();
							log.debug("-----------event:{}",event);
							if(StringUtils.isNotBlank(event)) {
								switch (event) {
									case "unsubscribe":
										cleanLoginData(request,response);
										break;
									case "subscribe":
										List<Article> articles = new ArrayList<Article>();
										Article article = new Article();
										article.setDescription("深圳市采集科技有限公司成立于2007年9月，以清华大学研究院国家级科研项目为起源，是一家专注于教育信息化的高新技术企业。");
										article.setPicurl(webhost+"welcome.jpg");
										article.setUrl("http://mp.weixin.qq.com/s/XO9sr-5CLhLgGsfAe9cTlA");
										article.setTitle("深圳市采集科技有限公司");
										articles.add(article);
										XMLMessage subscribeMessage = new XMLNewsMessage(eventMessage.getFromUserName(), eventMessage.getToUserName(), articles);
										subscribeMessage.outputStreamWrite(outputStream);
										break;
									case "SCAN":
										String backText = "您好,欢迎再次回到e家e校!";
										XMLMessage backTextMessage = new XMLTextMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), backText);
										backTextMessage.outputStreamWrite(outputStream);
										break;
									case "LOCATION":
										String locationEventText = "您好,地理位置<"+eventMessage.getLatitude()+","+eventMessage.getLatitude()+">";
										XMLMessage locationEventTextMessage = new XMLTextMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), locationEventText);
										locationEventTextMessage.outputStreamWrite(outputStream);
										break;
									case "CLICK":
										log.debug("点击了菜单：{}",eventMessage.getEventKey());
										if("quitCaiJi".equals(eventMessage.getEventKey())) {
											cleanLoginData(request,response);
											response.sendRedirect("/Weixin/User/index");
											return;	
										}else {
											String clickText = "该功能未实现";
											XMLMessage clickMessage = new XMLTextMessage(eventMessage.getFromUserName(),eventMessage.getToUserName(), clickText);
											clickMessage.outputStreamWrite(outputStream);
										}
										break;
									case "VIEW":
										log.debug("点击了菜单,跳转到：{}",eventMessage.getEventKey());
										break;
									default:
										log.debug("未知事件。。。。");
										break;
								}
							}
							break;
						default:
							outputStream.write("success".getBytes());
							break;
					}
					String userOpenId =  eventMessage.getFromUserName();
					log.debug("微信公众号{}与{}进行了一次交互",eventMessage.getToUserName(),userOpenId);
				}
			} else {
				log.debug("校验失败");
				throw new RuntimeException("请通过微信平台访问");
			}
		} catch (Exception e) {
			log.error("系统异常:{}", e.getMessage());
			throw new RuntimeException("请通过微信平台访问:" + e.getMessage());
		}
	}

	@RequestMapping(value = "/wx/userinfo", method = RequestMethod.GET)
	public void getUserInfo(@RequestParam(name = "code", required = false) String code,@RequestParam(name = "state") String state, HttpServletRequest request, HttpServletResponse response) {
		try {
			HttpSession session = request.getSession();
			if (session.getAttribute("userSession") == null) {
				cleanLoginData(request,response);
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/Weixin/login");
				requestDispatcher.forward(request, response);
				return;
			}
			String userSessionInfo = (String) session.getAttribute("userSession");
			JSONObject jsonData = JSONObject.parseObject(userSessionInfo);
			if (jsonData != null && jsonData.containsKey("userSession")) {
				Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType",jsonData.getJSONObject("userSession").getString("type"));
				cookieBindUserRoleType.setPath("/");
				cookieBindUserRoleType.setDomain(".ecaicn.com");
				response.addCookie(cookieBindUserRoleType);
				Cookie cookieBinduser = new Cookie("binduser", "true");
				cookieBinduser.setDomain(".ecaicn.com");
				cookieBinduser.setPath("/");
				response.addCookie(cookieBinduser);
				
				String token  = jsonData.getString("token");
				Cookie cookieToken = new Cookie("token",token);
				cookieToken.setPath("/");
				cookieToken.setDomain(".ecaicn.com");
		        response.addCookie(cookieToken);
				
				response.sendRedirect("/Weixin/User/index");
				return;
			}else if(jsonData != null && jsonData.containsKey("userInfo")) {
				if(jsonData.getJSONObject("userInfo").containsKey("currentSchoolRole") && "TEACHER".equals(jsonData.getJSONObject("userInfo").getString("currentSchoolRole"))) {
					Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType","1");
					cookieBindUserRoleType.setPath("/");
					cookieBindUserRoleType.setDomain(".ecaicn.com");
					response.addCookie(cookieBindUserRoleType);
				}else {
					Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType","2");
					cookieBindUserRoleType.setPath("/");
					cookieBindUserRoleType.setDomain(".ecaicn.com");
					response.addCookie(cookieBindUserRoleType);
				}
				String token  = jsonData.getString("token");
				Cookie cookieToken = new Cookie("token",token);
				cookieToken.setPath("/");
				cookieToken.setDomain(".ecaicn.com");
		        response.addCookie(cookieToken);
				Cookie cookieBinduser = new Cookie("binduser", "true");
				cookieBinduser.setPath("/");
				cookieBinduser.setDomain(".ecaicn.com");
				response.addCookie(cookieBinduser);
				response.sendRedirect("/Weixin/User/index");
			}else {
				throw new RuntimeException();
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取用户信息失败!");
			throw new RuntimeException("获取用户信息失败");
		}
	}
	
	private void cleanLoginData(HttpServletRequest request,HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String openId="";
		if (cookies != null && cookies.length > 0) {
			for (Cookie cookie : cookies) {
				if("wxOpenId".equals(cookie.getName())) {
					openId = cookie.getValue();
					continue;
				}
				cookie.setMaxAge(0);
				cookie.setPath("/");
				cookie.setDomain(".ecaicn.com");
				response.addCookie(cookie);
			}
		}
		HttpSession session = request.getSession();
		List<String> attributes = new ArrayList<String>();
		Enumeration<String> names = session.getAttributeNames();
		while (names.hasMoreElements()) {
			attributes.add(names.nextElement());
		}
		for (String attribute : attributes) {
			session.removeAttribute(attribute);
		}
		
		if(StringUtils.isNotBlank(openId)) {
			Cookie cookieOpenId = new Cookie("wxOpenId",openId);
			cookieOpenId.setPath("/");
			cookieOpenId.setDomain(".ecaicn.com");
	        response.addCookie(cookieOpenId);
			session.setAttribute("wxOpenId",openId);
		}
	}	
}
