package com.cjhsc.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.SendResult;
import com.aliyun.openservices.ons.api.bean.ProducerBean;
import com.cjhsc.dbmodel.DbModel;
import com.cjhsc.domodal.SendWeixinUserMqDO;
import com.cjhsc.service.SendWeixinUserMqService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import net.sf.json.JSONObject;

/**
 * 
*   
* 项目名称：cjhsc-api  
* 类名称：com.cjhsc.controllers.TestDbController  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:25:58
* 描述：
*
 */
@Api(value = "微信消息推送接口", tags = "信息推送", produces =MediaType.APPLICATION_JSON_UTF8_VALUE )
@RestController
public class TestDbController {

    private static final Logger log = LoggerFactory.getLogger(TestDbController.class);
    @Value("${mq.topic}")
    private String mqTopic;
    @Value("${mq.parenttag}")
    private String parentMqTag;
    @Value("${mq.teachertag}")
    private String teacherMqTag;
    @Value("${mq.hotreport}")
    private String hotReportTag;
    
    @Value("${mq.rediskey}")
    private String rediskey;
    
    @Autowired
    ProducerBean producer;
    
    @Autowired
   	private RedisTemplate<String,String> redisTemplate;
    
    @Autowired
    private SendWeixinUserMqService sendWeixinUserMqService;

    // @RequestMapping(value = "/getlist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    // public List<DbModel> getList() {
    //     return dbService.getList();
    // }

    //  @RequestMapping(value = "/getlist1", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    // public List<DbModel> getList1() {
    //   return dbService.getList1();
    //   }
    @ApiOperation(value = "教师消息推送接口", httpMethod = "GET", notes = "参数数据列表"/*, authorizations = @Authorization(value = "token")*/)
    @RequestMapping(value = "/run/{date}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public List<DbModel> run( @PathVariable String date) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        log.debug("发送通知" + sdf.format(sdf.parse(date))); 
        sendWeixinUserMqService.process4Teachers(sdf.format(sdf.parse(date)));
        return null;
    }
    
    @ApiOperation(value = "家长消息推送接口", httpMethod = "GET", notes = "参数数据列表"/*, authorizations = @Authorization(value = "token")*/)
    @RequestMapping(value = "/runparent/{date}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public List<DbModel> run2( @PathVariable String date) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        log.debug("发送通知" + sdf.format(sdf.parse(date))); 
        sendWeixinUserMqService.process(sdf.format(sdf.parse(date)));
        return null;
    }
    
    @SuppressWarnings("all")
    @ApiOperation(value = "热报推送", httpMethod = "GET", notes = "参数数据列表"/*, authorizations = @Authorization(value = "token")*/)
    @RequestMapping(value = "/push/hostreport", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public void pushData(@ApiParam(value = "学生Id", name = "studentId", required = true, example = "123") @RequestParam(name = "studentId", required = true) String studentId) throws Exception {//
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Map map = new HashMap();
        map.put("reportDate", "2018-02-28");
        map.put("guardianId", "398171629030473728");
        map.put("studentId", studentId);
        map.put("studentName", "吴佳炜");
        map.put("lessonId", "2017122910032017");
        map.put("lessonName", "数学");
        map.put("lessonTime", sdf.format(new Date()));
        map.put("teacherName", "陈秋琳");
        List list = new ArrayList();
        list.add("1.教师同时兼任同班级多门课程和班主任时，切换班级出现多选");
        list.add("2.教师班级整体表现，切换两次周期后无法切换回其他周期");
        list.add("3.退出家长账号后，登录教师账号显示已绑定其他用户");
        map.put("contents", list);
        redisTemplate.opsForList().rightPush(rediskey,JSONObject.fromObject(map).toString());
    }
    
    
    @SuppressWarnings("all")
    @ApiOperation(value = "推送家长单条", httpMethod = "GET", notes = "参数数据列表"/*, authorizations = @Authorization(value = "token")*/)
    @RequestMapping(value = "/push/parent/wxmg", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public void pushParentData(@ApiParam(value = "家长OPEIND", name = "openId", required = true, example = "1111111111111") @RequestParam(name = "openId", required = true) String openId) throws Exception {
    	 SendWeixinUserMqDO sendDO = new SendWeixinUserMqDO("罗子涵", "222", openId, "2018-01-18");
    	 Message message = new Message(this.mqTopic, parentMqTag, JSONObject.fromObject(sendDO).toString().getBytes());
         SendResult sendResult = producer.send(message);
         if (sendResult != null) {
             log.debug(new Date() + " 发送消息成功");
         } else {
             log.error("发送失败");
             throw new RuntimeException("发送失败");
         }
    }
    
    @SuppressWarnings("all")
    @ApiOperation(value = "推送教师单条", httpMethod = "GET", notes = "参数数据列表"/*, authorizations = @Authorization(value = "token")*/)
    @RequestMapping(value = "/push/teacher/wxmg", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public void pushTeacherData(@ApiParam(value = "教师OPEIND", name = "openId", required = true, example = "1111111111111") @RequestParam(name = "openId", required = true) String openId) throws Exception {
    	SendWeixinUserMqDO sendDO = new SendWeixinUserMqDO("陈秋琳", "164", openId, "2018-01-18");
   	 	Message message = new Message(this.mqTopic, teacherMqTag, JSONObject.fromObject(sendDO).toString().getBytes());
        SendResult sendResult = producer.send(message);
        if (sendResult != null) {
            log.debug(new Date() + " 发送消息成功");
        } else {
            log.error("发送失败");
            throw new RuntimeException("发送失败");
        }
    }
}
