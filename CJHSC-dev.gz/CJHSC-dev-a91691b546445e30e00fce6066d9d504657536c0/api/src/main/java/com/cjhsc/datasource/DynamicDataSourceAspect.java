package com.cjhsc.datasource;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cjhsc.annotation.TargetDataSource;

import org.springframework.core.annotation.Order;


/**
 * 
*   
* 项目名称：cjhsc-api  
* 类名称：com.cjhsc.datasource.DynamicDataSourceAspect  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:31:12
* 描述：
*
 */
@Aspect
@Order(-10)
@Component
public class DynamicDataSourceAspect {
	private static final Logger log = LoggerFactory.getLogger(DynamicDataSourceAspect.class);
	@Before("@annotation(targetDataSource)")
	public void changeDataSource(JoinPoint point, TargetDataSource targetDataSource) throws Throwable {
		String dsId = targetDataSource.value();
		if (!DynamicDataSourceContextHolder.containsDataSource(dsId)) {
			log.debug("数据源[{}]不存在，使用默认数据源 > {}" , targetDataSource.value(), point.getSignature());
		} else {
			DynamicDataSourceContextHolder.setDataSourceType(targetDataSource.value());
		}
	}

	@After("@annotation(targetDataSource)")
	public void restoreDataSource(JoinPoint point, TargetDataSource targetDataSource) {
		DynamicDataSourceContextHolder.clearDataSourceType();
	}

}
