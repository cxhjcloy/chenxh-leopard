	package com.cjhsc.config;

import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import weixin.popular.api.TokenAPI;
import weixin.popular.bean.token.Token;


/**
 * 
*   
* 项目名称：cjhsc-api  
* 类名称：com.cjhsc.config.TokenManagerListener  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:47:56
* 描述：
*
 */
@Component
public class TokenManagerListener implements ServletContextListener{
	
	private static final long CACHETIME = 118;
	private static final String ACCESSTOKENKEY="CJHSC_WX_ACCESSTOKEN";
	@Autowired
	private RedisTemplate<String, String> redisTemplate;
	
	@Value("${wechat.appid}")
	private String appid;

	@Value("${wechat.appsecret}")
	private String appsecret;
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		//多实例状态下 重复获取accessToken问题	
    	if(StringUtils.isBlank(redisTemplate.opsForValue().get(ACCESSTOKENKEY))) {
			//TokenManager.setDaemon(false);
			//TokenManager.init(appid,appsecret);
    		Token token = TokenAPI.token(appid,appsecret);
    		if(token.isSuccess()) {
    			redisTemplate.opsForValue().set(ACCESSTOKENKEY, token.getAccess_token(), CACHETIME, TimeUnit.MINUTES);
    		}else {
    			throw new RuntimeException("无法获取微信accessToken");
    		}
    	}else {
    		
    	}
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		//WEB容器  关闭时调用
	}
}