package com.cjhsc.config;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.cjhsc.annotation.WxAuth;


@Aspect
@Component
/**
 * 微信拦截器 获取用户openId
 * @author chenxh
 *
 */
public class WeixinInterceptor {
	private static final Logger log = LoggerFactory.getLogger(WeixinInterceptor.class);

	@Value("${wechat.appid}")
	private String appid;
	@Value("${wechat.appsecret}")
	private String appsecret;
	private final static String SCOPE = "snsapi_base";
	@Value("${cbp.host}")
	private String cbphost;
	@SuppressWarnings("all")
	private String getCode(String forwordUrl) throws Exception {
		return String.format(
				"https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=%s&state=STAT#wechat_redirect",
				appid, URLEncoder.encode(forwordUrl,"UTF-8"), SCOPE);
	}
	
	@Before("@annotation(wxAuth)")
	public void getWxOpenIdInfo(JoinPoint point, WxAuth wxAuth) throws Throwable {
		if(wxAuth.enable()){
			HttpServletRequest request = null;
			HttpServletResponse response = null;
			HttpSession session = null;
			Object[] args = point.getArgs();
			if(args !=null && args.length>0) {
				for (Object arg : args) {
					if(arg instanceof  HttpServletRequest) {
						request = (HttpServletRequest) arg;
						session = request.getSession();					
						log.debug("get HttpServletRequest ...{}",request.getRequestURI());
					}
					if(arg instanceof  HttpServletResponse) {
						response = (HttpServletResponse) arg;
					}
				}
			}
			if(request == null || response == null ||session == null) {
				return;
			}
			String requestURI = request.getRequestURI();
			log.debug("requestURI:{}",requestURI);
	        if (requestURI.contains(".") || requestURI.contains("notice/aboutUs") || requestURI.contains("notice/commonQues") ) {
	            return;
	        }
			String code = request.getParameter("code");
			if(StringUtils.isNotBlank(code)) {
				RestTemplate restTemplate = new RestTemplate();
				Map<String, Object> urlVariables = new HashMap<String, Object>();
				urlVariables.put("appid", appid);
				urlVariables.put("secret", appsecret);
				urlVariables.put("code", code);
				urlVariables.put("grant_type", "authorization_code");
				String retData = restTemplate.getForObject("https://api.weixin.qq.com/sns/oauth2/access_token?appid={appid}&secret={secret}&code={code}&grant_type={grant_type}",String.class, urlVariables);
				JSONObject json = JSONObject.parseObject(retData);
				String openId = json.getString("openid");
				session.setAttribute("wxOpenId", openId);
				//设置cookie
				Cookie cookieOpenId = new Cookie("wxOpenId",openId);
				cookieOpenId.setPath("/");
				cookieOpenId.setDomain(".ecaicn.com");
		        response.addCookie(cookieOpenId);
		        log.debug("############### Set weixin user openid = {}",openId);
				
				if(wxAuth.isLogin()) {
					//用户登录
					String servicePoint = cbphost + "unlogin/homeSchoolLogin?openId={openId}";
					urlVariables = new HashMap<String, Object>(10);
					urlVariables.put("openId", openId);
					retData = restTemplate.postForObject(servicePoint, null, String.class, urlVariables);
					json = JSONObject.parseObject(retData);
					//登录成功
					if(json!=null && json.containsKey("code") && json.getIntValue("code") == 0) {
						String token  = json.getJSONObject("data").getString("token");
						Cookie cookieToken = new Cookie("token",token);
						cookieToken.setPath("/");
						cookieToken.setDomain(".ecaicn.com");
				        response.addCookie(cookieToken);
						session.setAttribute("userSession", retData);
					}else {
					}
				}
			}
			Cookie[] cookies = request.getCookies();
			if (cookies != null && cookies.length > 0) {
				for (Cookie cookie : cookies) {
					if("wxOpenId".equals(cookie.getName())) {
						session.setAttribute("wxOpenId", cookie.getValue());
						break;
					}
				}
			}
			Object wxOpenId = session.getAttribute("wxOpenId");			
			if(wxOpenId == null) {
				if(wxAuth.isRedirect()) {
					String redirectUrl = wxAuth.redirectUrl();
					if(StringUtils.isBlank(redirectUrl)) {
						RequestDispatcher requestDispatcher = request.getRequestDispatcher("/Weixin/User/index");
						requestDispatcher.forward(request, response);
						return;
					}else {
						response.sendRedirect(redirectUrl);
						return;
					}
				}
				response.sendRedirect(getCode(request.getRequestURL().toString()));
				return;
			}			
		}
	}
}
