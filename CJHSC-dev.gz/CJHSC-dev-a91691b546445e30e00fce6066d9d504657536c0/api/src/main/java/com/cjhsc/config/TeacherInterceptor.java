package com.cjhsc.config;

import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.cjhsc.annotation.TeacherAuth;
import com.cjhsc.util.ApiError;

@Aspect
@Component
/**
 * 微信拦截器 获取用户openId
 * 
 * @author chenxh
 *
 */
public class TeacherInterceptor {
	private static final Logger log = LoggerFactory.getLogger(TeacherInterceptor.class);

	@Value("${wechat.appid}")
	private String appid;

	@Value("${wechat.appsecret}")
	private String appsecret;

	private final static String SCOPE = "snsapi_base";

	@Value("${cbp.host}")
	private String cbphost;

	@Value("${webhost}")
	private String webhost;

	@SuppressWarnings("all")
	private String getCode(String forwordUrl) throws Exception {
		return String.format(
				"https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=%s&state=STAT#wechat_redirect",
				appid, URLEncoder.encode(forwordUrl, "UTF-8"), SCOPE);
	}

	/**
	 * 描述：函数执行前判定用户openid是否，是否需要登录，需要登录时进行登录，并设置session数据和cookies数据
	 * 
	 * @param point
	 * @param teacherAuth
	 * @throws Throwable
	 */
	@Before("@annotation(teacherAuth)")
	public void getWxOpenIdInfo(JoinPoint point, TeacherAuth teacherAuth) throws Throwable {
		if (teacherAuth.enable()) {
			HttpServletRequest request = getRequest(point);
			HttpServletResponse response = getResponse(point);
			HttpSession session = request != null ? request.getSession() : null;
			String openId = "";

			if (request == null || response == null || session == null) {
				return;
			}
			openId = request.getHeader("openId");
			if (StringUtils.isBlank(openId)) {
				openId = getOpenId(request, session, openId);
			} else {
				session.setAttribute("wxOpenId", openId);
				session.removeAttribute("userSession");
			}
			if (StringUtils.isBlank(openId)) {
				log.error("help！获取不到用户的openId！！！！！");
				return;
			}
			Object userSeeionObject = session.getAttribute("userSession");
			try {
				if (userSeeionObject != null) {
					JSONObject json = JSONObject.parseObject(userSeeionObject.toString());
					if (!"1".equals(json.getJSONObject("data").getJSONObject("userSession").getString("type"))) {
						throw new RuntimeException("非教师用户");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (StringUtils.isNotBlank(openId) && teacherAuth.isLogin() && userSeeionObject == null) {
				reLogin(response, session, openId);
			}
		}
	}

	/**
	 * 描述：根据返回结果判定若用户没有登录，就重新登录，设置session数据和cookie数据。
	 * 
	 * @param joinPoint
	 * @param teacherAuth
	 * @param rvt
	 * @return
	 */
	@AfterReturning(returning = "rvt", pointcut = "@annotation(teacherAuth)")
	public Object afterExec(JoinPoint joinPoint, TeacherAuth teacherAuth, Object rvt) {
		if (teacherAuth.enable()) {
			try {
				JSONObject retJson = (JSONObject) JSONObject.toJSON(rvt);
				log.debug("返回结果是：{}", retJson);
				if (Arrays.asList(703, ApiError.NO_LOGIN.getCode(), ApiError.NO_TOKEN.getCode())
						.contains(retJson.getInteger("code"))) {
					log.error("返回结果表明，需要重新登录！！！！，请注意");
					HttpServletRequest request = getRequest(joinPoint);
					HttpServletResponse response = getResponse(joinPoint);
					HttpSession session = request != null ? request.getSession() : null;
					String openId = "";
					if (request == null || response == null || session == null) {
						return rvt;
					}
					openId = request.getHeader("openId");
					if (StringUtils.isBlank(openId)) {
						openId = getOpenId(request, session, openId);
					} else {
						session.setAttribute("wxOpenId", openId);
						session.removeAttribute("userSession");
					}
					if (StringUtils.isBlank(openId)) {
						log.error("help！获取不到用户的openId！！！！！");
						return rvt;
					}
					session.removeAttribute("userSession");
					Object userSeeionObject = session.getAttribute("userSession");
					try {
						if (userSeeionObject != null) {
							JSONObject json = JSONObject.parseObject(userSeeionObject.toString());
							if (!"1".equals(
									json.getJSONObject("data").getJSONObject("userSession").getString("type"))) {
								throw new RuntimeException("非教师用户");
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					if (StringUtils.isNotBlank(openId) && teacherAuth.isLogin() && userSeeionObject == null) {
						reLogin(response, session, openId);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return rvt;
	}

	/**
	 * 重新登录
	 * 
	 * @param response
	 * @param session
	 * @param openId
	 */
	private void reLogin(HttpServletResponse response, HttpSession session, String openId) {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, Object> urlVariables = new HashMap<String, Object>();
		String servicePoint = cbphost + "unlogin/homeSchoolLogin?openId={openId}";
		urlVariables = new HashMap<String, Object>();
		urlVariables.put("openId", openId);
		String retData = restTemplate.postForObject(servicePoint, null, String.class, urlVariables);
		log.debug("*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*[RELOGIN] TeacherInterceptor userLogin data:{}", retData);
		JSONObject json = JSONObject.parseObject(retData);
		if (json != null && json.containsKey("code") && json.getIntValue("code") == 0) {
			if (!"1".equals(json.getJSONObject("data").getJSONObject("userSession").getString("type"))) {
				throw new RuntimeException("非教师用户");
			}
			session.setAttribute("userSession", retData);

			String token = json.getJSONObject("data").getString("token");
			Cookie cookieToken = new Cookie("token", token);
			cookieToken.setPath("/");
			cookieToken.setDomain(".ecaicn.com");
			response.addCookie(cookieToken);

			Cookie cookieOpenId = new Cookie("wxOpenId", openId);
			cookieOpenId.setPath("/");
			cookieOpenId.setDomain(".ecaicn.com");
			response.addCookie(cookieOpenId);

			Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType",
					json.getJSONObject("data").getJSONObject("userSession").getString("type"));
			cookieBindUserRoleType.setPath("/");
			cookieBindUserRoleType.setDomain(".ecaicn.com");
			response.addCookie(cookieBindUserRoleType);

			Cookie cookieBinduser = new Cookie("binduser", "true");
			cookieBinduser.setDomain(".ecaicn.com");
			cookieBinduser.setPath("/");
			response.addCookie(cookieBinduser);
		}
	}

	private String getOpenId(HttpServletRequest request, HttpSession session, String openId) {
		Object wxOpenId = session.getAttribute("wxOpenId");
		if (wxOpenId == null) {
			Cookie[] cookies = request.getCookies();
			if (cookies != null && cookies.length > 0) {
				for (Cookie cookie : cookies) {
					if ("wxOpenId".equals(cookie.getName())) {
						openId = cookie.getValue();
						break;
					}
				}
			}
			if (StringUtils.isNotBlank(openId)) {
				session.setAttribute("wxOpenId", openId);
			} else {
				wxOpenId = null;
			}
		} else {
			openId = session.getAttribute("wxOpenId").toString();
		}
		return openId;
	}

	private HttpServletRequest getRequest(JoinPoint point) {
		Object[] args = point.getArgs();
		for (Object arg : args) {
			if (arg instanceof HttpServletRequest) {
				HttpServletRequest request = (HttpServletRequest) arg;
				HttpSession session = request.getSession();
				log.debug("get HttpServletRequest ...{}...sessionId={}", request.getRequestURI(), session.getId());
				return request;
			}
		}
		return null;
	}

	private HttpServletResponse getResponse(JoinPoint point) {
		Object[] args = point.getArgs();
		for (Object arg : args) {
			if (arg instanceof HttpServletResponse) {
				return (HttpServletResponse) arg;
			}
		}
		return null;
	}
}
