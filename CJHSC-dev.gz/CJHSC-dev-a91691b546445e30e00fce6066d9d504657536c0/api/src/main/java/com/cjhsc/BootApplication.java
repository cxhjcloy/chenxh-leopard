package com.cjhsc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

import com.cjhsc.datasource.DynamicDataSourceRegister;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * spring boot启动类
 *
 * @author 杨英杰
 * @create 2017-03-30 下午 13:55
 **/
@Configuration 
@EnableAutoConfiguration()
@ComponentScan(basePackages = {"com.cjhsc"})
@PropertySource({ "classpath:application.properties"})
@ImportResource({"classpath:app-config.xml"})
@Import({DynamicDataSourceRegister.class})
@EnableAspectJAutoProxy(proxyTargetClass = true,exposeProxy = true)
@EnableTransactionManagement
public class BootApplication {
    public static void main(String[] args) throws Exception {
        SpringApplication.run(BootApplication.class, args);
    }
}
