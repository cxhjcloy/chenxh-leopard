package com.cjhsc.datasource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * 
*   
* 项目名称：CJHSC  
* 类名称：.DynamicDataSource  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:20:13
* 描述：
*
 */
public class DynamicDataSource extends AbstractRoutingDataSource {
	   
    @Override
    protected Object determineCurrentLookupKey() {
       return DynamicDataSourceContextHolder.getDataSourceType();
    }
}
