package com.cjhsc.config;

import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cjhsc.annotation.ParentAuth;
import com.cjhsc.service.CJYunApiService;
import com.cjhsc.util.ApiError;

@Aspect
@Component
/**
 * 微信拦截器 获取用户openId
 * 
 * @author chenxh
 * 
 */
public class ParentInterceptor {

	private static final Logger log = LoggerFactory.getLogger(ParentInterceptor.class);

	@Value("${wechat.appid}")
	private String appid;

	@Value("${wechat.appsecret}")
	private String appsecret;

	private final static String SCOPE = "snsapi_base";

	@Value("${cbp.host}")
	private String cbphost;

	@Value("${webhost}")
	private String webhost;

	@Autowired
	private CJYunApiService cJYunApiService;

	@SuppressWarnings("all")
	private String getCode(String forwordUrl) throws Exception {
		return String.format(
				"https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=%s&state=STAT#wechat_redirect",
				appid, URLEncoder.encode(forwordUrl, "UTF-8"), SCOPE);
	}

	/**
	 * 描述：拦截家长接口，检测用户的openid数据是否存在，需要登录时进行登录，并设置session和cookie数据。
	 * 
	 * @param point
	 * @param parentAuth
	 * @throws Throwable
	 */
	@Before("@annotation(parentAuth)")
	public void getWxOpenIdInfo(JoinPoint point, ParentAuth parentAuth) throws Throwable {
		if (parentAuth.enable()) {
			HttpServletRequest request = getRequest(point);
			HttpServletResponse response = getResponse(point);
			HttpSession session = request != null ? request.getSession() : null;
			String openId = "";
			openId = request.getHeader("openId");
			if (StringUtils.isBlank(openId)) {
				openId = getOpenId(request, session, openId);
			} else {
				session.setAttribute("wxOpenId", openId);
				session.removeAttribute("userSession");
			}
			if (StringUtils.isBlank(openId)) {
				log.error("help！获取不到用户的openId！！！！！");
				return;
			}
			Object userSessionObject = session.getAttribute("userSession");
			try {
				if (userSessionObject != null) {
					JSONObject json = JSONObject.parseObject(userSessionObject.toString());
					if (!"2".equals(json.getJSONObject("data").getJSONObject("userSession").getString("type"))) {
						throw new RuntimeException("非家长用户");
					}
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			if (StringUtils.isNotBlank(openId) && parentAuth.isLogin() && userSessionObject == null) {
				// 重新登录
				reLongin(parentAuth, response, session, openId);
			}
		}
	}

	/**
	 * 描述：检测返回结果，若发现返回结果报错用户未登录(code=703),进行登录并设置session数据和cookies数据。
	 * 
	 * @param joinPoint
	 * @param parentAuth
	 * @param rvt
	 * @return
	 */
	@AfterReturning(returning = "rvt", pointcut = "@annotation(parentAuth)")
	public Object afterExec(JoinPoint joinPoint, ParentAuth parentAuth, Object rvt) {
		if (parentAuth.enable()) {
			try {
				JSONObject retJson = (JSONObject) JSONObject.toJSON(rvt);
				log.debug("返回结果是：{}", retJson);
				if (Arrays.asList(703, ApiError.NO_LOGIN.getCode(), ApiError.NO_TOKEN.getCode(),
						ApiError.NO_STUDENTS.getCode()).contains(retJson.getInteger("code"))) {// 用户未登录
					log.error("返回结果表明，需要重新登录！！！！，请注意");
					HttpServletRequest request = getRequest(joinPoint);
					HttpServletResponse response = getResponse(joinPoint);
					HttpSession session = request != null ? request.getSession() : null;
					String openId = "";
					if (request == null || response == null || session == null) {
						return rvt;
					}
					openId = request.getHeader("openId");
					if (StringUtils.isBlank(openId)) {
						openId = getOpenId(request, session, openId);
						session.removeAttribute("userSession");
						Object userSessionObject = session.getAttribute("userSession");
						if (StringUtils.isBlank(openId)) {
							log.error("help！获取不到用户的openId！！！！！");
							return rvt;
						}
						try {
							if (userSessionObject != null) {
								JSONObject json = JSONObject.parseObject(userSessionObject.toString());
								if (!"2".equals(
										json.getJSONObject("data").getJSONObject("userSession").getString("type"))) {
									throw new RuntimeException("非家长用户");
								}
							}
						} catch (Exception e1) {
							e1.printStackTrace();
						}
						if (StringUtils.isNotBlank(openId) && parentAuth.isLogin() && userSessionObject == null) {
							// 重新登录
							reLongin(parentAuth, response, session, openId);
						}
					} else {
						session.setAttribute("wxOpenId", openId);
						session.removeAttribute("userSession");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return rvt;
	}

	private String getOpenId(HttpServletRequest request, HttpSession session, String openId) {
		Object wxOpenId = session.getAttribute("wxOpenId");
		if (wxOpenId == null) {
			Cookie[] cookies = request.getCookies();
			if (cookies != null && cookies.length > 0) {
				for (Cookie cookie : cookies) {
					if ("wxOpenId".equals(cookie.getName())) {
						openId = cookie.getValue();
						break;
					}
				}
			}
			if (StringUtils.isNotBlank(openId)) {
				session.setAttribute("wxOpenId", openId);
			} else {
				wxOpenId = null;
			}
		} else {
			openId = session.getAttribute("wxOpenId").toString();
		}
		return openId;
	}

	private HttpServletRequest getRequest(JoinPoint point) {
		Object[] args = point.getArgs();
		for (Object arg : args) {
			if (arg instanceof HttpServletRequest) {
				HttpServletRequest request = (HttpServletRequest) arg;
				HttpSession session = request.getSession();
				log.debug("get HttpServletRequest ...{}...sessionId={}", request.getRequestURI(), session.getId());
				return request;
			}
		}
		return null;
	}

	private HttpServletResponse getResponse(JoinPoint point) {
		Object[] args = point.getArgs();
		for (Object arg : args) {
			if (arg instanceof HttpServletResponse) {
				return (HttpServletResponse) arg;
			}
		}
		return null;
	}

	/**
	 * 重新登录
	 * 
	 * @param parentAuth
	 * @param response
	 * @param session
	 * @param openId
	 * @throws Exception
	 */
	private void reLongin(ParentAuth parentAuth, HttpServletResponse response, HttpSession session, String openId)
			throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, Object> urlVariables = new HashMap<String, Object>();
		// 用户登录
		String servicePoint = cbphost + "unlogin/homeSchoolLogin?openId={openId}";
		urlVariables = new HashMap<String, Object>();
		urlVariables.put("openId", openId);
		String retData = restTemplate.postForObject(servicePoint, null, String.class, urlVariables);
		log.debug("*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*[RELOGIN] ParentInterceptor userLogin data:{}", retData);
		JSONObject json = JSONObject.parseObject(retData);
		// 成功登录
		if (json != null && json.containsKey("code") && json.getIntValue("code") == 0) {
			if (!"2".equals(json.getJSONObject("data").getJSONObject("userSession").getString("type"))) {
				throw new RuntimeException("非家长用户");
			}
			session.setAttribute("userSession", retData);
			String token = json.getJSONObject("data").getString("token");
			// 若请求需要用户的schoolsId
			if (parentAuth.needSchoolIds()) {
				// 得到家长的绑定孩子的schoolIds
				JSONArray schoolIdsArray = json.getJSONObject("data").getJSONObject("userSession")
						.getJSONArray("schoolId");
				if (schoolIdsArray != null && schoolIdsArray.size() > 0) {
					log.debug("****{}", schoolIdsArray.toJSONString());
					Set<String> schoolIds = new HashSet<String>();
					for (Object object : schoolIdsArray) {
						schoolIds.add(object.toString());
					}
					if (schoolIds.size() > 0) {
						// 设置session数据保存家长的schoolIds数据
						session.setAttribute("parentSchoolIds", String.join(",", schoolIds));
					}
				}
				// 得不到该数据时 从家长绑定的孩子列表中获取schoolIds数据
				if (session.getAttribute("parentSchoolIds") == null) {
					String tempStr = cJYunApiService.getbindStudentList(token);
					json = JSONObject.parseObject(tempStr);
					try {
						if (json != null && json.containsKey("data") && json.getJSONArray("data").size() > 0) {
							Set<String> schoolIds = new HashSet<String>();
							for (Object object : json.getJSONArray("data")) {
								JSONObject tempJson = (JSONObject) object;
								schoolIds.add(tempJson.getString("schoolId"));
							}
							if (schoolIds.size() > 0) {
								session.setAttribute("parentSchoolIds", String.join(",", schoolIds));
							} else {
								log.debug(
										"*****************ParentInterceptor can not get schoolids,set default:\"1,2,3\"");
								// 获取不到采用默认值
								session.setAttribute("parentSchoolIds", "1,2,3");
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						log.error(e.getMessage());
						log.error("*****************ParentInterceptor can not get schoolids,set default:\"1,2,3\"");
						// 获取不到采用默认值
						session.setAttribute("parentSchoolIds", "1,2,3");
					}
				}
			}
			// 重新设置用户的cookies数据
			Cookie cookieOpenId = new Cookie("wxOpenId", openId);
			cookieOpenId.setPath("/");
			cookieOpenId.setDomain(".ecaicn.com");
			response.addCookie(cookieOpenId);
			// 家长type=2
			Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType","2");
			cookieBindUserRoleType.setPath("/");
			cookieBindUserRoleType.setDomain(".ecaicn.com");
			response.addCookie(cookieBindUserRoleType);
			Cookie cookieBinduser = new Cookie("binduser", "true");
			cookieBinduser.setDomain(".ecaicn.com");
			cookieBinduser.setPath("/");
			response.addCookie(cookieBinduser);
			Cookie cookieToken = new Cookie("token", token);
			cookieToken.setPath("/");
			cookieToken.setDomain(".ecaicn.com");
			response.addCookie(cookieToken);
		}
	}
}
