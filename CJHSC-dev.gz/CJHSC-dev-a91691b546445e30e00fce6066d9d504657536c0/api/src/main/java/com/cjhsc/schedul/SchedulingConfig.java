package com.cjhsc.schedul;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.cjhsc.service.SendWeixinUserMqService;


/**
 * 
*   
* 项目名称：cjhsc-api  
* 类名称：com.cjhsc.schedul.SchedulingConfig  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:32:39
* 描述：
*
 */

@Configuration
@EnableScheduling
public class SchedulingConfig {
    private static final Logger log = LoggerFactory.getLogger(SchedulingConfig.class);
    @Autowired
    private SendWeixinUserMqService sendWeixinUserMqService;
    /**
     * 每天21点进行检测消息
     * @throws Exception
     */
    @Scheduled(cron = "0 0  21  * * ?")
    public void receiveSendMq() throws Exception {
        log.debug("发送消息");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sendWeixinUserMqService.process(sdf.format(new Date()));
        sendWeixinUserMqService.process4Teachers(sdf.format(new Date()));
    }
    
    
    /**
     * 每隔1秒发送课堂热报消息
     * @throws Exception
     */
    @Scheduled(fixedRate=10000,initialDelay=60000)
    public void setHostReportMq() throws Exception {
        log.debug("发送课堂热报");
        sendWeixinUserMqService.setHostReportMq();
    }
}
