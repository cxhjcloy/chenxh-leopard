package com.cjhsc.config;

import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

/**
 * 
*   
* 项目名称：cjhsc-api  
* 类名称：com.cjhsc.config.RedisHttpSessionConfig  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:45:34
* 描述：缓存半小时
*
 */
@EnableRedisHttpSession(maxInactiveIntervalInSeconds=1800)
public class RedisHttpSessionConfig {

}
