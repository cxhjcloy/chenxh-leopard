package com.cjhsc.datasource;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
*   
* 项目名称：CJHSC  
* 类名称：.DynamicDataSourceContextHolder  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:10:55
* 描述：
*
 */
public class DynamicDataSourceContextHolder {
    public static final Logger log = LoggerFactory.getLogger(DynamicDataSourceContextHolder.class);

    private static final ThreadLocal<String> CONTEXT_HOLDER = new ThreadLocal<String>();
    
    public static List<String> dataSourceIds = new ArrayList<String>();
    
    public static void setDataSourceType(String dataSourceType) {
    	CONTEXT_HOLDER.set(dataSourceType);
    }
 
    public static String getDataSourceType() {
       return CONTEXT_HOLDER.get();
    }
 
    public static void clearDataSourceType() {
    	CONTEXT_HOLDER.remove();
    }
   
    public static boolean containsDataSource(String dataSourceId){
        return dataSourceIds.contains(dataSourceId);
    }
}
