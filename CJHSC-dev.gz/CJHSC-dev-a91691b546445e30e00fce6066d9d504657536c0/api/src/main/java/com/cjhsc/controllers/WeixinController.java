package com.cjhsc.controllers;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.cjhsc.annotation.WxAuth;
import com.cjhsc.service.CJYunApiService;
import com.cjhsc.service.WxService;

import weixin.popular.api.UserAPI;
import weixin.popular.bean.user.User;

/**
 * 
*   
* 项目名称：cjhsc-api  
* 类名称：com.cjhsc.controllers.WeixinController  
* @author：chenxh  
* 创建时间：2017年12月15日 下午12:26:22
* 描述：
*
 */
@Controller
public class WeixinController {
    private static final Logger log = LoggerFactory.getLogger(WeixinController.class);
    @Autowired
    private WxService wxService;
    @Autowired
    private CJYunApiService cJYunApiService;
    @Value("${wechat.key}")
    private String token;

    @Value("${wechat.appid}")
    private String appid;

    @Value("${wechat.appsecret}")
    private String appsecret;
    @Value("${cbp.host}")
    private String cbphost;
    private final static String SCOPE = "snsapi_base";
    @Value("${webhost}")
    private String webhost;

   
    @SuppressWarnings("all")
    private String getCode(String forwordUrl) throws Exception{
        return String.format(
                "https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=%s&state=STAT#wechat_redirect",
                appid, URLEncoder.encode(webhost + forwordUrl,"UTF-8"), SCOPE);
    }

    //退出登录
    @GetMapping("/Weixin/exit0")
    public void exit(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();
        Object userSessionObject = session.getAttribute("userSession");
        if (userSessionObject != null) {
            JSONObject jsonData = JSONObject.parseObject(userSessionObject.toString());
            if (jsonData != null && jsonData.containsKey("token")) {
                cJYunApiService.logout(jsonData.getString("token"));
            }
        }
        cleanLoginData(request, response);
        response.sendRedirect("/Weixin/User/index");
        return;
    }

    //登录 获取微信数据和用户信息
    @GetMapping("/Weixin/login")
    public void login(@RequestParam(name = "code", required = true) String code, @RequestParam(name = "state", required = false) String state, HttpServletRequest request, HttpServletResponse response) {
        try {
            log.debug("-----------login---------------");
            HttpSession session = request.getSession();
            //获取code openid 页面accesstoken
            RestTemplate restTemplate = new RestTemplate();
            Map<String, Object> urlVariables = new HashMap<String, Object>();
            urlVariables.put("appid", appid);
            urlVariables.put("secret", appsecret);
            urlVariables.put("code", code);
            urlVariables.put("grant_type", "authorization_code");
            String retData = restTemplate.getForObject("https://api.weixin.qq.com/sns/oauth2/access_token?appid={appid}&secret={secret}&code={code}&grant_type={grant_type}", String.class, urlVariables);
            JSONObject json = JSONObject.parseObject(retData);
            log.debug("retJsonData={}", retData);
            String openId = json.getString("openid");
            session.setAttribute("wxOpenId", openId);
            // 获取用户信息
            String servicePoint = cbphost + "/guardian/teacherAndFamily?openId={openId}";//查询用户登录状态
            urlVariables = new HashMap<String, Object>();
            urlVariables.put("openId", openId);
            retData = restTemplate.getForObject(servicePoint, String.class, urlVariables);
            log.debug("retJsonData={}", retData);
            json = JSONObject.parseObject(retData);
            if (json != null && json.containsKey("code") && json.getIntValue("code") == 0) {
                json = json.getJSONObject("data");
                if (json != null && json.containsKey("loginStatus") && json.getIntValue("loginStatus") == 0) {//说明用户退出
                    response.sendRedirect("/Weixin/User/index");
                    return;
                }
            }
            String accessToken = wxService.getAccessToken();
            User user = UserAPI.userInfo(accessToken, openId);
            if (user.isSuccess()) {
                session.setAttribute("wxUserInfo", JSONObject.toJSONString(user));//session 记录用户微信登录信息
                servicePoint = cbphost + "unlogin/homeSchoolLogin?openId={openId}";//用户登录
                urlVariables = new HashMap<String, Object>();
                urlVariables.put("openId", openId);
                retData = restTemplate.postForObject(servicePoint, null, String.class, urlVariables);
                log.debug("*****************retData={}", retData);
                json = JSONObject.parseObject(retData);
                if (json != null && json.containsKey("token")) {
                    String type = json.getJSONObject("userSession").getString("type");
                    session.setAttribute("userSession", retData);
                    Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType", type);
                    cookieBindUserRoleType.setPath("/");
                    cookieBindUserRoleType.setDomain(".ecaicn.com");
                    response.addCookie(cookieBindUserRoleType);
                    Cookie cookieBinduser = new Cookie("binduser", "true");
                    cookieBinduser.setPath("/");
                    cookieBinduser.setDomain(".ecaicn.com");
                    String token = json.getString("token");
                    Cookie cookieToken = new Cookie("token", token);
                    cookieToken.setPath("/");
                    cookieToken.setDomain(".ecaicn.com");
                    response.addCookie(cookieToken);
                    response.addCookie(cookieBinduser);
                } else {
                		
                }
                response.sendRedirect("/Weixin/User/index");
                return;
            } else {
                log.debug("获取用户信息失败:{}", user.getErrmsg());
                throw new RuntimeException("获取用户信息失败:" + user.getErrmsg());
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("获取用户信息失败!");
            throw new RuntimeException("获取用户信息失败");
        }
    }
	

    @GetMapping("/weixin/user/index/**")
    @WxAuth
    public String index(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        log.debug("-----------index---------------{},", session.getAttribute("wxOpenId"));
        String requestURI = request.getRequestURI();
        if (requestURI.contains(".")) {
            String redirectUrl = requestURI.replace("/weixin/user/index/", "");
            log.debug(webhost + redirectUrl);
            response.sendRedirect(webhost + redirectUrl);
            return null;
        }
        return "index";
    }
    private void cleanLoginData(HttpServletRequest request, HttpServletResponse response) {
    	// 清除cookie
		Cookie[] cookies = request.getCookies();
		String openId="";
		if (cookies != null && cookies.length > 0) {
			for (Cookie cookie : cookies) {
				if("wxOpenId".equals(cookie.getName())) {
					openId = cookie.getValue();
					continue;
				}
				cookie.setMaxAge(0);
				cookie.setPath("/");
				cookie.setDomain(".ecaicn.com");
				response.addCookie(cookie);
			}
		}
		// 清除session数据
		HttpSession session = request.getSession();
		List<String> attributes = new ArrayList<String>();
		Enumeration<String> names = session.getAttributeNames();
		while (names.hasMoreElements()) {
			attributes.add(names.nextElement());
		}
		for (String attribute : attributes) {
			session.removeAttribute(attribute);
		}
		
		if(StringUtils.isNotBlank(openId)) {
			//设置cookie
			Cookie cookieOpenId = new Cookie("wxOpenId",openId);
			cookieOpenId.setPath("/");
			cookieOpenId.setDomain(".ecaicn.com");
	        response.addCookie(cookieOpenId);
			session.setAttribute("wxOpenId",openId);
		}
    }
}
