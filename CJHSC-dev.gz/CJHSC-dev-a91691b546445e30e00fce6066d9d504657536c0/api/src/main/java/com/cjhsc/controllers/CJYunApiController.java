package com.cjhsc.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cjhsc.annotation.ParentAuth;
import com.cjhsc.annotation.TeacherAuth;
import com.cjhsc.dtomodal.BindStudentDto;
import com.cjhsc.dtomodal.BindStudentParmsDto;
import com.cjhsc.dtomodal.ClassPerformanceDto;
import com.cjhsc.dtomodal.ClassPerformanceTrendDto;
import com.cjhsc.dtomodal.ClassPerformanceTrendListDataDto;
import com.cjhsc.dtomodal.ExitDto;
import com.cjhsc.dtomodal.FamilyRelationDto;
import com.cjhsc.dtomodal.HotReportsDto;
import com.cjhsc.dtomodal.RegisterDto;
import com.cjhsc.dtomodal.StudentDayStatisDto;
import com.cjhsc.dtomodal.StudentDayStatisDtoNew;
import com.cjhsc.dtomodal.StudentLessonDto;
import com.cjhsc.dtomodal.StudentLessonDtoNew;
import com.cjhsc.dtomodal.StudentLessonTotalDto;
import com.cjhsc.dtomodal.StudentPerformanceTrendChartDataDto;
import com.cjhsc.dtomodal.StudentPerformanceTrendDto;
import com.cjhsc.dtomodal.StudentStatisDto;
import com.cjhsc.dtomodal.StudentStudyPortraitDto;
import com.cjhsc.dtomodal.StudentTodayHomeworkStatisDto;
import com.cjhsc.dtomodal.StudentYesterdayHomeworkStatisDto;
import com.cjhsc.dtomodal.TeacherClassDto;
import com.cjhsc.dtomodal.TeacherDayLessonCountDto;
import com.cjhsc.dtomodal.TeacherDayLessonDto;
import com.cjhsc.dtomodal.TeacherDayLessonDtoNew;
import com.cjhsc.dtomodal.TeacherDayLessonTotalDto;
import com.cjhsc.dtomodal.TeacherLessonDto;
import com.cjhsc.dtomodal.TeacherLessonDtoNew;
import com.cjhsc.dtomodal.TeacherLoginParmsDto;
import com.cjhsc.dtomodal.TeacherStatisDto;
import com.cjhsc.dtomodal.TeacherStatisDtoNew;
import com.cjhsc.dtomodal.UpdatePasswordParmsDto;
import com.cjhsc.service.CJYunApiService;
import com.cjhsc.util.APIResult;
import com.cjhsc.util.ApiError;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;



/**
 * 
*   
* 项目名称：cjhsc-api  
* 类名称：com.cjhsc.controllers.CJYunApiController  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:28:07
* 描述：
*
 */
@RestController
@SuppressWarnings("all")
@Api(tags = "e家e校接口", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class CJYunApiController {
	private static final Logger log = LoggerFactory.getLogger(CJYunApiController.class);
	/**
	 * 替换字符串，用于处理返回结果null值忽略问题。
	 */
	private static String REPACE_STR = "1111111111100000000000";
	@Value("${cbp.host}")
	private String cbphost;
	@Autowired
	private CJYunApiService cJYunApiService;

	// 通过手机获取注册验证码
	@ApiOperation(value = "通过手机获取注册验证码", httpMethod = "GET", consumes = "String")
	//@ApiImplicitParams({@ApiImplicitParam(name = "openId", value = "Authorization token", required = true, dataType = "string", paramType = "header")})
	@GetMapping(value = "/service/sendPhoneCode", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)	
	public APIResult sendPhoneCode(@ApiParam(value = "手机号码", name = "phone", required = true, example = "15656941192") @RequestParam(name = "phone", required = true) String phone,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult aPIResult = new APIResult();
		try {
			String tempStr = cJYunApiService.sendPhoneCode(phone);
			aPIResult = JSONObject.parseObject(tempStr,APIResult.class);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取注册验证码异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		return aPIResult;
	}

	// 校验手机验证码
	@ApiOperation(value = "校验手机验证码", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/service/checkPhoneCode", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)	
	public APIResult checkPhoneCode(
			@ApiParam(value = "手机号码", name = "phone", required = true, example = "15656941192") @RequestParam(name = "phone", required = true) String phone,
			@ApiParam(value = "手机验证码", name = "phonecode", required = true, example = "123456") @RequestParam(name = "phonecode", required = true) String phonecode,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult aPIResult = new APIResult();
		try {
			String tempStr = cJYunApiService.checkPhoneCode(phone, phonecode);
			aPIResult =  JSONObject.parseObject(tempStr, APIResult.class);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("校验手机验证码异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		return aPIResult;
	}

	// 家长注册
	@ApiOperation(value = "家长注册", httpMethod = "POST", consumes = "String")
	@PostMapping(value = "/user/register", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	//@WxAuth
	@ParentAuth(isLogin=false)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult guardianRegister(@ApiParam(value = "家长注册对象") @RequestBody RegisterDto requestData, HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession();
		APIResult aPIResult = new APIResult();
		try {
			if (StringUtils.isBlank(requestData.getRealName())||StringUtils.isBlank(requestData.getPhone())||StringUtils.isBlank(requestData.getPassword())||StringUtils.isBlank(requestData.getPhoneCode())) {
				aPIResult.setCode(ApiError.PARAS_INCOMPLETE.getCode());
				aPIResult.setMessage(ApiError.PARAS_INCOMPLETE.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}			
			String guardianOpenId = "";
			JSONObject jsonData = null;
			Object wxUserInfoSessionObject = session.getAttribute("wxUserInfo");
			if (wxUserInfoSessionObject == null) {
				guardianOpenId = (String) session.getAttribute("wxOpenId");
			} else {
				jsonData = JSONObject.parseObject(wxUserInfoSessionObject.toString());
				if (jsonData != null && jsonData.containsKey("openid")) {
					guardianOpenId = jsonData.getString("openid");
				} 
			}
			if (StringUtils.isBlank(guardianOpenId)) {
				aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
				aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}

			String tempStr = cJYunApiService.guardianRegister(requestData.getPhone(), requestData.getPhoneCode(), requestData.getPassword(), requestData.getRealName(), guardianOpenId);
			if (StringUtils.isBlank(tempStr)) {
				throw new RuntimeException("注册失败");
			}
			jsonData = JSONObject.parseObject(tempStr);
			aPIResult =  JSONObject.parseObject(tempStr, APIResult.class);
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getInteger("code") == 0) {
				String userSession = cJYunApiService.loginByOpenId(guardianOpenId);
				if (StringUtils.isNotBlank(userSession)) {
					session.setAttribute("userSession", userSession);
					JSONObject json = JSONObject.parseObject(userSession);
					Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType","2");
					cookieBindUserRoleType.setPath("/");
					cookieBindUserRoleType.setDomain(".ecaicn.com");
					response.addCookie(cookieBindUserRoleType);
					Cookie cookieBinduser = new Cookie("binduser", "true");
					cookieBinduser.setPath("/");
					cookieBinduser.setDomain(".ecaicn.com");
					response.addCookie(cookieBinduser);
					
					String token  = json.getJSONObject("data").getString("token");
					Cookie cookieToken = new Cookie("token",token);
					cookieToken.setPath("/");
					cookieToken.setDomain(".ecaicn.com");
					//cookieToken.setHttpOnly(true);
			        response.addCookie(cookieToken);
			        Map<String,Object> tokenMap = new HashMap<>();
			        tokenMap.put("token", token);
			        tokenMap.put("userInfo", json.getJSONObject("data").getJSONObject("userSession"));
			        aPIResult.setData(tokenMap);
				} else {
					cleanLoginData(request, response);
				}
			}
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("家长注册异常:{}", e.getMessage());
			throw new RuntimeException("注册失败"+e.getMessage());
		}		
	}

	@ApiOperation(value = "教师登录", httpMethod = "POST", consumes = "String")
	@PostMapping(value = "/user/login", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	//@WxAuth
	@TeacherAuth(isLogin=false)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult teacherLogin(@ApiParam(value = "教师登录对象", required = true) @RequestBody TeacherLoginParmsDto loginData, HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession();
		APIResult aPIResult = new APIResult();
		try {
			String userName = loginData.getUserName();
			String passWord = loginData.getPassWord();
			if (StringUtils.isBlank(userName) || StringUtils.isBlank(passWord)) {
				aPIResult.setCode(ApiError.PARAS_INCOMPLETE.getCode());
				aPIResult.setMessage(ApiError.PARAS_INCOMPLETE.getMessage());
				aPIResult.setData("");
			}
			String tempStr = cJYunApiService.teacherLogin(userName, passWord);
			aPIResult = JSONObject.parseObject(tempStr,APIResult.class);
			JSONObject json = JSONObject.parseObject(tempStr);
			if (json!=null && json.containsKey("code")&& json.getInteger("code") == 0) {
				String teacherId4Compare = json.getJSONObject("data").getJSONObject("userInfo").getString("teacherId");
				JSONArray schoolRoleList = json.getJSONObject("data").getJSONObject("userInfo").getJSONArray("schoolRoleList");
				if (schoolRoleList.contains("TEACHER")) {
					/// 查询用户是否绑定了openId 若没有绑定进行绑定
					String openId = "";
					Object wxUserInfoSessionObject = session.getAttribute("wxUserInfo");
					if (wxUserInfoSessionObject == null) {
						openId = (String) session.getAttribute("wxOpenId");
					} else {
						JSONObject jsonData = JSONObject.parseObject(wxUserInfoSessionObject.toString());
						if (jsonData != null && jsonData.containsKey("openid")) {
							openId = jsonData.getString("openid");
						} else {
							aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
							aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
							aPIResult.setData("");
							return aPIResult;
						}
					}
					if (StringUtils.isBlank(openId)) {
						aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
						aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
						aPIResult.setData("");
						return aPIResult;
					} else {
						session.setAttribute("wxOpenId", openId);
					}
					String teacherInfoStr = null;
					RestTemplate restTemplate = new RestTemplate();
					try {
						String servicePoint = cbphost + "unlogin/homeSchoolLogin?openId={openId}";
						Map<String, Object> urlVariables = new HashMap<String, Object>();
						urlVariables.put("openId", openId);
						teacherInfoStr = restTemplate.postForObject(servicePoint, null, String.class, urlVariables);
					} catch (Exception e) {
						e.printStackTrace();
						throw new RuntimeException(e.getMessage());
					}
					String type = "1";
					JSONObject teacherInfoJson = JSONObject.parseObject(teacherInfoStr);
					if (!(teacherInfoJson != null && teacherInfoJson.containsKey("code")&& teacherInfoJson.getIntValue("code")==0)) {
						//String userId4Compare = teacherInfoJson.get
						// 使用OpenId绑定用户
						try {
							String teacherId = json.getJSONObject("data").getJSONObject("userInfo").getString("teacherId");
							if(StringUtils.isBlank(teacherId)) {
								aPIResult.setCode(ApiError.NOT_TEACHERID.getCode());
								aPIResult.setMessage(ApiError.NOT_TEACHERID.getMessage());
								aPIResult.setData("");
								return aPIResult;
							}
							tempStr = cJYunApiService.bindUserByOpenId(teacherId, openId, type);
							aPIResult = JSONObject.parseObject(tempStr.replaceAll("userSession", "userInfo").replaceAll("家长", ""),APIResult.class);
						} catch (Exception e) {
							log.error("教师登录异常:{}", e.getMessage());
							e.printStackTrace();
							throw new RuntimeException(e.getMessage());							
						}
						if (aPIResult.getCode() != 0) {
							return aPIResult;
						}
						try {
							String servicePoint = cbphost + "unlogin/homeSchoolLogin?openId={openId}";
							Map<String, Object> urlVariables = new HashMap<String, Object>();
							urlVariables.put("openId", openId);
							teacherInfoStr = restTemplate.postForObject(servicePoint, null, String.class, urlVariables);
							aPIResult = JSONObject.parseObject(teacherInfoStr.replaceAll("userSession", "userInfo"),APIResult.class);
						} catch (Exception e) {
							log.error("教师登录异常:{}", e.getMessage());
							e.printStackTrace();
							throw new RuntimeException(e.getMessage());
						}
					}else {
						String userId4Compare = teacherInfoJson.getJSONObject("data").getJSONObject("userSession").getString("id");
						if(!teacherId4Compare.equalsIgnoreCase(userId4Compare)) {
							aPIResult.setCode(ApiError.BIND_OTHER.getCode());
							aPIResult.setMessage(ApiError.BIND_OTHER.getMessage());
							aPIResult.setData("");
							return aPIResult;
						}
					}
					session.setAttribute("userSession", teacherInfoStr);
					//设置cookie
					Cookie cookieOpenId = new Cookie("wxOpenId",openId);
					cookieOpenId.setPath("/");
					cookieOpenId.setDomain(".ecaicn.com");
			        response.addCookie(cookieOpenId);
					
					Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType", type);
					cookieBindUserRoleType.setPath("/");
					cookieBindUserRoleType.setDomain(".ecaicn.com");
					response.addCookie(cookieBindUserRoleType);
					
					Cookie cookieBinduser = new Cookie("binduser", "true");
					cookieBinduser.setPath("/");
					cookieBinduser.setDomain(".ecaicn.com");
					response.addCookie(cookieBinduser);
					
					String token  = json.getJSONObject("data").getString("token");
					Cookie cookieToken = new Cookie("token",token);
					cookieToken.setPath("/");
					cookieToken.setDomain(".ecaicn.com");
			        response.addCookie(cookieToken);
			        
					return aPIResult;
				} else {
					aPIResult.setCode(ApiError.NOT_TEACHER.getCode());
					aPIResult.setMessage(ApiError.NOT_TEACHER.getMessage());
					aPIResult.setData("");
					return aPIResult;
				}
			} else {				
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师登录异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	@ApiOperation(value = "根据手机号码是否与微信openid绑定", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/user", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth(isLogin=false)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult checkUserBind(@ApiParam(value = "手机号码", name = "phone", required = true, example = "15656941192") @RequestParam(name = "phone", required = true) String phone,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult aPIResult = new APIResult();
		HttpSession session = request.getSession();
		JSONObject jsonData = null;
		String openId = "";
		try {
			Object wxUserInfoSessionObject = session.getAttribute("wxUserInfo");
			if (wxUserInfoSessionObject == null) {
				openId = (String) session.getAttribute("wxOpenId");
			} else {
				jsonData = JSONObject.parseObject(wxUserInfoSessionObject.toString());
				if (jsonData != null && jsonData.containsKey("openid")) {
					openId = jsonData.getString("openid");
				}
			}
			if (StringUtils.isBlank(openId)) {
				aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
				aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}
			//设置openId cookie
			Cookie cookieOpenId = new Cookie("wxOpenId",openId);
			cookieOpenId.setPath("/");
			cookieOpenId.setDomain(".ecaicn.com");
	        response.addCookie(cookieOpenId);
	        
			String tempStr = cJYunApiService.detectBindWeChatUser(phone, openId);
			jsonData = JSONObject.parseObject(tempStr);
			if ((jsonData!=null && jsonData.containsKey("token") && StringUtils.isNotBlank(jsonData.getString("token")))||jsonData.containsKey("code") && jsonData.getIntValue("code") == 100) {
				if( StringUtils.isNotBlank(jsonData.getString("token")) && !"GUARDIAN".equalsIgnoreCase(jsonData.getJSONObject("userSession").getString("currentSchoolRole"))) {
					aPIResult.setCode(ApiError.NOT_GUARDIAN.getCode());
					aPIResult.setMessage(ApiError.NOT_GUARDIAN.getMessage());
					aPIResult.setData("");
					return aPIResult;
				}
				String bindUserId4Compare = null;
				Object userSessionSessionObject = null;
				if( StringUtils.isNotBlank(jsonData.getString("token"))){
					bindUserId4Compare = jsonData.getJSONObject("userSession").getString("id");
					userSessionSessionObject = session.getAttribute("userSession");
				}
				// 检测用户是否已经登录
				String userId = "";
				if (userSessionSessionObject == null) {
					// 用户登录					
					try {
						String servicePoint = cbphost + "unlogin/homeSchoolLogin?openId={openId}";
						Map<String, Object> urlVariables = new HashMap<String, Object>();
						urlVariables.put("openId", openId);
						RestTemplate restTemplate = new RestTemplate();
						String logData = restTemplate.postForObject(servicePoint, null, String.class, urlVariables);
						//设置家长登陆后的得到的schoolIds
						JSONObject logDataJson =  JSONObject.parseObject(logData);
						if(logDataJson!=null && logDataJson.containsKey("code") && logDataJson.getIntValue("code")==0) {
							session.setAttribute("userSession", logData);
							JSONArray schoolIdsArray = logDataJson.getJSONObject("data").getJSONObject("userSession").getJSONArray("schoolId");
							userId = logDataJson.getJSONObject("data").getJSONObject("userSession").getString("id");
							if( bindUserId4Compare != null && !bindUserId4Compare.equals(userId)) {
								aPIResult.setCode(ApiError.BIND_OTHER.getCode());
								aPIResult.setMessage(ApiError.BIND_OTHER.getMessage());
								aPIResult.setData("");
								return aPIResult;
							}
							if(schoolIdsArray!=null && schoolIdsArray.size()>0) {
								Set<String> schoolIds  = new HashSet<String>();
								for (Object object : schoolIdsArray) {
									schoolIds.add(object.toString());
								}
								if(schoolIds.size()>0) {
									session.setAttribute("parentSchoolIds",String.join(",", schoolIds));
								}								
							}
						}						
						if(session.getAttribute("parentSchoolIds")==null) {
							String tempStr001 = cJYunApiService.getbindStudentList(logDataJson.getJSONObject("data").getString("token"));
							JSONObject json = JSONObject.parseObject(tempStr001);
							try {
								if(json!=null && json.containsKey("data") && json.getJSONArray("data").size()>0) {
									Set<String> schoolIds  = new HashSet<String>();
									for (Object object : json.getJSONArray("data")) {
										JSONObject tempJson = (JSONObject) object;
										schoolIds.add(tempJson.getString("schoolId"));
									}
									if(schoolIds.size()>0) {
										session.setAttribute("parentSchoolIds",String.join(",", schoolIds));
									}else {
										session.setAttribute("parentSchoolIds", "1,2,3");
									}
								}
							} catch (Exception e) {
								e.printStackTrace();
								session.setAttribute("parentSchoolIds", "1,2,3");
							}
						}
						jsonData = JSONObject.parseObject(logData);
						Cookie cookieBindUserRoleType = new Cookie("bindUserRoleType","2");
						cookieBindUserRoleType.setPath("/");
						cookieBindUserRoleType.setDomain(".ecaicn.com");
						response.addCookie(cookieBindUserRoleType);
						
						Cookie cookieBinduser = new Cookie("binduser", "true");
						cookieBinduser.setDomain(".ecaicn.com");
						cookieBinduser.setPath("/");
						response.addCookie(cookieBinduser);
						
						String token  = jsonData.getJSONObject("data").getString("token");
						Cookie cookieToken = new Cookie("token",token);
						cookieToken.setPath("/");
						cookieToken.setDomain(".ecaicn.com");
				        response.addCookie(cookieToken);				        
					} catch (Exception e) {
						e.printStackTrace();
					}
				}				
				aPIResult.setMessage("成功");
				aPIResult.setCode(0);
				Map<String, Object> bind = new HashMap<>();
				bind.put("bind", 1);
				JSONObject userInfo =  JSONObject.parseObject(session.getAttribute("userSession").toString()).getJSONObject("data").getJSONObject("userSession");
				userInfo.put("id", userId);
				bind.put("userInfo", userInfo);
				aPIResult.setData(bind);				
			} else {
				aPIResult.setMessage("成功");
				aPIResult.setCode(0);
				Map<String, Object> bind = new HashMap<>();
				bind.put("bind", 0);
				aPIResult.setData(bind);
			}
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("根据手机号码查询关联账号异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}		
	}

	@ApiOperation(value = "绑定孩子", httpMethod = "POST", consumes = "String")
	@PostMapping(value = "/student/bindStudent", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult bindStudent(@ApiParam(value = "绑定孩子对象") @RequestBody BindStudentParmsDto requestData, HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession();
		APIResult aPIResult = new APIResult();
		try {
			String familyRelationCode =requestData.getFamilyRelationCode();
			if (StringUtils.isBlank(requestData.getStudentName())|| StringUtils.isBlank(requestData.getVerificationCode())) {
				aPIResult.setCode(ApiError.PARAS_INCOMPLETE.getCode());
				aPIResult.setMessage(ApiError.PARAS_INCOMPLETE.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}
			String token = "";
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0 ) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}
			if (StringUtils.isBlank(familyRelationCode) || "false".equals(familyRelationCode.trim())) {
				String tempStr = cJYunApiService.getbindStudentList(token);
				Map<String, Object> retData = (Map<String, Object>) JSONObject.parse(tempStr);
				JSONArray studentData = null;
				if (retData != null && retData.containsKey("data")) {
					studentData = (JSONArray) retData.get("data");
					if (studentData != null && studentData.size() > 0) {
						familyRelationCode = ((JSONObject) studentData.get(0)).getString("familyRelationCode");
					} else {
						aPIResult.setCode(ApiError.PARAS_INCOMPLETE.getCode());
						aPIResult.setMessage(ApiError.PARAS_INCOMPLETE.getMessage());
						aPIResult.setData("");
						return aPIResult;
					}
				} else {
					aPIResult.setCode(ApiError.PARAS_INCOMPLETE.getCode());
					aPIResult.setMessage(ApiError.PARAS_INCOMPLETE.getMessage());
					aPIResult.setData("");
					return aPIResult;
				}
			}
			if(StringUtils.isBlank(familyRelationCode)) {
				aPIResult.setCode(ApiError.PARAS_INCOMPLETE.getCode());
				aPIResult.setMessage(ApiError.PARAS_INCOMPLETE.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}
			String tempStr = cJYunApiService.bindStudent(requestData.getStudentName(), requestData.getVerificationCode(), familyRelationCode, token);
			aPIResult = JSONObject.parseObject(tempStr,APIResult.class);
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("绑定孩子异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	@ApiOperation(value = "查询已绑定孩子列表", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/student/bindStudent", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth(isLogin=true)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<BindStudentDto> getbindStudentList(HttpServletRequest request, HttpServletResponse response) {
		APIResult<BindStudentDto> aPIResult = new APIResult<BindStudentDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			String token = "";
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String guardianOpenId = "";
			Object wxUserInfoSessionObject = session.getAttribute("wxUserInfo");
			if (wxUserInfoSessionObject == null) {
				guardianOpenId = (String) session.getAttribute("wxOpenId");
			} else {
				jsonData = JSONObject.parseObject(wxUserInfoSessionObject.toString());
				if (jsonData != null && jsonData.containsKey("openid")) {
					guardianOpenId = jsonData.getString("openid");
				} else {
					aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
					aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
					aPIResult.setData(null);
					return aPIResult;
				}
			}
			if (StringUtils.isBlank(guardianOpenId)) {
				aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
				aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.getbindStudentList(token);
			Map<String, Object> retData = (Map<String, Object>) JSONObject.parse(tempStr);
			JSONArray studentData = null;
			if (retData != null && retData.containsKey("code") && "0".equals(retData.get("code").toString()) && retData.containsKey("data")) {
				studentData = (JSONArray) retData.get("data");
				for (Object object : studentData) {
					JSONObject student = (JSONObject) object;
				}
				try {
					JSONObject json = JSONObject.parseObject(tempStr);
					if(json!=null && json.containsKey("data") && json.getJSONArray("data").size()>0) {
						Set<String> schoolIds  = new HashSet<String>();
						for (Object object : json.getJSONArray("data")) {
							JSONObject tempJson = (JSONObject) object;
							schoolIds.add(tempJson.getString("schoolId"));
						}
						if(schoolIds.size()>0) {
							session.setAttribute("parentSchoolIds",String.join(",", schoolIds));
						}else {
							session.setAttribute("parentSchoolIds", "1,2,3");
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					session.setAttribute("parentSchoolIds", "1,2,3");
				}
				retData.put("message", "成功");
			}			
			Map data = new HashMap();
			data.put("items", studentData);
			retData.put("data", data);
			aPIResult = JSONObject.parseObject(JSONObject.toJSONString(retData), APIResult.class);
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("查询已绑定孩子列表异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	@ApiOperation(value = "查询家庭关系列表", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/student/relaction", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)	
	public APIResult<FamilyRelationDto> getFamilyRelactiont(HttpServletRequest request, HttpServletResponse response) {
		APIResult<FamilyRelationDto> aPIResult = new APIResult<FamilyRelationDto>();
		try {
			Map<String, Object> retData = new HashMap<>();
			String tempStr = cJYunApiService.getFamilyRelactiont();
			retData = (Map<String, Object>) JSONObject.parse(tempStr);			
			retData.put("message", "成功");
			Map data = new HashMap();
			data.put("items", retData.get("data"));
			retData.put("data", data);
			aPIResult = JSONObject.parseObject(JSONObject.toJSONString(retData), APIResult.class);
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("查询家庭关系列表异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	@ApiOperation(value = "教师主页 - 学情报告(顶部)", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/teacherStatis", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherStatisDtoNew> teacherStatis_New(HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherStatisDtoNew> aPIResult = new APIResult<TeacherStatisDtoNew>();
		HttpSession session = request.getSession();
		try {
			String teacherId = "";
			Object teacherSessionObject = session.getAttribute("userSession");
			if (teacherSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(teacherSessionObject.toString());
			if (jsonData != null &&  jsonData.containsKey("code")&& jsonData.getIntValue("code") == 0) {
				teacherId = jsonData.getJSONObject("data").getJSONObject("userSession").getString("id");
			} else {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String token = jsonData.getJSONObject("data").getString("token");
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.teacherStatis(teacherId, token);


			JSONObject json = JSONObject.parseObject(tempStr);
			try {
				if(json.getIntValue("code")==0 && json.containsKey("data") && json.getJSONObject("data").getJSONObject("items")!=null) {
					JSONObject items =  json.getJSONObject("data").getJSONObject("items");
					if(!items.containsKey("correctRate") || items.get("correctRate")==null) {
						items.put("correctRate", 0);
					}
					if(!items.containsKey("focusRate") || items.get("focusRate")==null) {
						items.put("focusRate", 0);
					}
					if(!items.containsKey("lessonNum") || items.get("lessonNum")==null) {
						items.put("lessonNum", 0);
					}
				}else if(json.getIntValue("code")==0){
					Map data = new HashMap();
					data.put("total", 0);
					Map sub = new HashMap();
					sub.put("correctRate", 0);
					sub.put("focusRate", 0);
					sub.put("lessonNum", 0);
					data.put("items", sub);
					json.remove("data");
					json.put("data", data);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}	
			aPIResult = JSONObject.parseObject(json.toJSONString(),aPIResult.getClass());
			if(aPIResult.getData() == null) {
				aPIResult.setCode(ApiError.UNKNOWN_ERROR.getCode());
				aPIResult.setMessage(ApiError.UNKNOWN_ERROR.getMessage());
				aPIResult.setData(null);
			}
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师学期统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}	
	
	@GetMapping(value = "/report/teacherStatis_Old", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherStatisDto> teacherStatis_Old(HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherStatisDto> aPIResult = new APIResult<TeacherStatisDto>();
		HttpSession session = request.getSession();
		try {
			String teacherId = "";
			Object teacherSessionObject = session.getAttribute("userSession");
			if (teacherSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(teacherSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("userSession")&& jsonData.getJSONObject("userSession").containsKey("id")) {
				teacherId = jsonData.getJSONObject("userSession").getString("id");
			} else {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String token = jsonData.getString("token");
			String tempStr = cJYunApiService.teacherStatis(teacherId, token);
			aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师学期统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	@GetMapping(value = "/report/teacherDayLessonCount_Old", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherDayLessonCountDto> teacherDayLessonCount(@ApiParam(value = "分页", name = "page", required = true, example = "1") @RequestParam(name = "page", required = true) String page,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherDayLessonCountDto> aPIResult = new APIResult<TeacherDayLessonCountDto>();
		HttpSession session = request.getSession();
		try {
			String teacherId = "";
			Object teacherSessionObject = session.getAttribute("userSession");
			if (teacherSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(teacherSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("userSession")&& jsonData.getJSONObject("userSession").containsKey("id")) {
				teacherId = jsonData.getJSONObject("userSession").getString("id");
			} else {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String token = jsonData.getString("token");
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.teacherDayLessonCount(teacherId, page, token);
			aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师学期日授课次数统计(分页)异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	@ApiOperation(value = "教师主页 - 课堂观察报告列表(日统计)", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/teacherDayLessonCount", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherDayLessonTotalDto> teacherDayLessonCount_New(@ApiParam(value = "分页", name = "page", required = true, example = "1") @RequestParam(name = "page", required = true) String page,
			@ApiParam(value = "分页大小(默认10)", name = "pageSize", required = false, example = "10") @RequestParam(name = "pageSize", required = false,defaultValue="10") String pageSize,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherDayLessonTotalDto> aPIResult = new APIResult<TeacherDayLessonTotalDto>();
		HttpSession session = request.getSession();
		try {
			String teacherId = "";
			Object teacherSessionObject = session.getAttribute("userSession");
			if (teacherSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(teacherSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code")&& jsonData.getIntValue("code")==0) {
				teacherId = jsonData.getJSONObject("data").getJSONObject("userSession").getString("id");
			} else {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String token = jsonData.getJSONObject("data").getString("token");
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.teacherDayLessonCountNew(teacherId, page,pageSize, token);
			JSONObject json = JSONObject.parseObject(tempStr);
			try {
				if(json.getIntValue("code")==0 && json.containsKey("data") && json.getJSONObject("data").getJSONArray("items").size()>0) {
					JSONArray array =  json.getJSONObject("data").getJSONArray("items");
					for (Object ar : array) {
						JSONObject itme = (JSONObject) ar;
						String teachingDate = itme.getString("teachingDate");
						Integer readStatus = cJYunApiService.getTeacherReadStatus(teacherId,teachingDate);
						if(readStatus == null) {
							readStatus = 0;
						}
						itme.put("readStatus", readStatus);
						if(!itme.containsKey("activeRate") || itme.get("activeRate") == null) {
							itme.put("activeRate", 0);
						}
						if(!itme.containsKey("correctRate") || itme.get("correctRate") == null) {
							itme.put("correctRate", 0);
						}
						if(!itme.containsKey("focusRate") || itme.get("focusRate") == null) {
							itme.put("focusRate", 0);
						}
						if(!itme.containsKey("lessonNum") || itme.get("lessonNum") == null) {
							itme.put("lessonNum", 0);
						}
					}
				}else if(json.getIntValue("code")==0) {
					Map data = new HashMap();
					data.put("total", 0);
					data.put("items", new ArrayList());
					json.remove("data");
					json.put("data", data);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			aPIResult = JSONObject.parseObject(json.toJSONString(),aPIResult.getClass());
			if(aPIResult.getData() == null) {
				aPIResult.setCode(ApiError.UNKNOWN_ERROR.getCode());
				aPIResult.setMessage(ApiError.UNKNOWN_ERROR.getMessage());
				aPIResult.setData(null);
			}
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师学期日授课次数统计(分页)异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	@GetMapping(value = "/report/teacherDayLesson_Old", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherDayLessonDto> teacherDayLesson(
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-08-31") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherDayLessonDto> aPIResult = new APIResult<TeacherDayLessonDto>();
		HttpSession session = request.getSession();
		try {
			Object teacherInfoSessionObject = session.getAttribute("userSession");
			if (teacherInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(teacherInfoSessionObject.toString());
			String teacherId = jsonData.getJSONObject("userSession").getString("id");
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.teacherDayLesson(teacherId, teachingDate,jsonData.getString("token"));
			aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师日授课统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	@ApiOperation(value = "教师课堂观察日报 - 课堂观察(授课日报-列表)", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/teacherDayLesson", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherDayLessonDtoNew> teacherDayLesson_new(
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-08-31") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherDayLessonDtoNew> aPIResult = new APIResult<TeacherDayLessonDtoNew>();
		HttpSession session = request.getSession();
		try {
			Object teacherInfoSessionObject = session.getAttribute("userSession");
			if (teacherInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(teacherInfoSessionObject.toString());
			String teacherId = jsonData.getJSONObject("data").getJSONObject("userSession").getString("id");
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String token = jsonData.getJSONObject("data").getString("token");
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.teacherDayLessonNew(teacherId, teachingDate,token);
			String otherStr = cJYunApiService.lessonEntiretyTarget(teacherId, teachingDate,token);
			jsonData = JSONObject.parseObject(tempStr);
			JSONObject jsonOtherData = JSONObject.parseObject(otherStr);
			try {
				if(jsonData!=null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0 && jsonOtherData!=null && jsonOtherData.containsKey("code") && jsonOtherData.getIntValue("code") == 0) {//接口调用成功后更细阅读状态
					jsonData.getJSONObject("data").put("activeRate", jsonOtherData.getJSONObject("data").getJSONObject("items").getDoubleValue("activeRate"));
					jsonData.getJSONObject("data").put("correctRate", jsonOtherData.getJSONObject("data").getJSONObject("items").getDoubleValue("correctRate"));
					jsonData.getJSONObject("data").put("focusRate", jsonOtherData.getJSONObject("data").getJSONObject("items").getDoubleValue("focusRate"));
				}
			} catch (Exception e) {
				log.error("教师日授课统计异常:{}", e.getMessage());
				e.printStackTrace();
			}
			aPIResult = JSONObject.parseObject(jsonData.toJSONString(),aPIResult.getClass());
			if(aPIResult.getCode() == 0) {
				Integer readStatus = cJYunApiService.getTeacherReadStatus(teacherId,teachingDate);
				if(readStatus == null || readStatus.intValue() == 0) {
					cJYunApiService.updateTeacherReadStatus(teacherId,teachingDate);
				}
			}
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师日授课统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}	
	
	

	@GetMapping(value = "/report/teacherLesson_Old", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherLessonDto> teacherLesson(
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-09-01") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			@ApiParam(value = "课堂Id", name = "lessonId", required = true, example = "201709011739061118") @RequestParam(name = "lessonId", required = true) String lessonId,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherLessonDto> aPIResult = new APIResult<TeacherLessonDto>();
		HttpSession session = request.getSession();
		try {
			Object teacherInfoSessionObject = session.getAttribute("userSession");
			if (teacherInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(teacherInfoSessionObject.toString());
			String teacherId = jsonData.getJSONObject("userSession").getString("id");
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.teacherLesson(teacherId, teachingDate, lessonId,jsonData.getString("token"));
			aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师课堂分析统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	@ApiOperation(value = "教师课堂观察 - (课堂详情)", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/teacherLesson", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherLessonDtoNew> teacherLesson_New(
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-09-01") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			@ApiParam(value = "课堂Id", name = "lessonId", required = true, example = "201709011739061118") @RequestParam(name = "lessonId", required = true) String lessonId,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherLessonDtoNew> aPIResult = new APIResult<TeacherLessonDtoNew>();
		HttpSession session = request.getSession();
		try {
			Object teacherInfoSessionObject = session.getAttribute("userSession");
			if (teacherInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(teacherInfoSessionObject.toString());
			String teacherId = jsonData.getJSONObject("data").getJSONObject("userSession").getString("id");
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.teacherLessonNew(teacherId, teachingDate, lessonId,jsonData.getJSONObject("data").getString("token"));
			aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师课堂分析统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}	

	@GetMapping(value = "/report/studentLesson_Old", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentLessonDto> studentLesson(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-09-01") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentLessonDto> aPIResult = new APIResult<StudentLessonDto>();
		HttpSession session = request.getSession();
		try {
			Object openIdJwtInfo = session.getAttribute("openIdJwtInfo");
			if (openIdJwtInfo == null) {
				String guardianOpenId = "";
				JSONObject jsonData = null;
				Object wxUserInfoSessionObject = session.getAttribute("wxUserInfo");
				if (wxUserInfoSessionObject == null) {
					guardianOpenId = (String) session.getAttribute("wxOpenId");
				} else {
					jsonData = JSONObject.parseObject(wxUserInfoSessionObject.toString());
					if (jsonData != null && jsonData.containsKey("openid")) {
						guardianOpenId = jsonData.getString("openid");
					} 
				}
				if (StringUtils.isBlank(guardianOpenId)) {
					aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
					aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
					aPIResult.setData(null);
					return aPIResult;
				}
				String jwtString = cJYunApiService.getStudentJwtByOpeId(guardianOpenId, studentId);
				jsonData = JSONObject.parseObject(jwtString);
				if (jsonData != null && jsonData.containsKey("token")&& StringUtils.isNotBlank(jsonData.getString("token"))) {
					session.setAttribute("openIdJwtInfo", jwtString);
					openIdJwtInfo = jsonData;
				} else {
					aPIResult.setCode(ApiError.JWT_NOTFOUND.getCode());
					aPIResult.setMessage(ApiError.JWT_NOTFOUND.getMessage());
					aPIResult.setData(null);
					return aPIResult;
				}
			}
			JSONObject jsonData = JSONObject.parseObject(openIdJwtInfo.toString());
			String tempStr = cJYunApiService.studentLesson(studentId, teachingDate, jsonData.getString("token"));
			aPIResult = JSONObject.parseObject(tempStr, aPIResult.getClass());
			return aPIResult;
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("学生授课日课堂统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	@GetMapping(value = "/report/studentDayStatis_Old", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentDayStatisDto> studentDayStatis(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-09-01") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentDayStatisDto> aPIResult = new APIResult<StudentDayStatisDto>();
		HttpSession session = request.getSession();
		try {
			Object openIdJwtInfo = session.getAttribute("openIdJwtInfo");
			if (openIdJwtInfo == null) {
				String guardianOpenId = "";
				JSONObject jsonData = null;
				Object wxUserInfoSessionObject = session.getAttribute("wxUserInfo");
				if (wxUserInfoSessionObject == null) {
					guardianOpenId = (String) session.getAttribute("wxOpenId");
				} else {
					jsonData = JSONObject.parseObject(wxUserInfoSessionObject.toString());
					if (jsonData != null && jsonData.containsKey("openid")) {
						guardianOpenId = jsonData.getString("openid");
					}
				}
				if (StringUtils.isBlank(guardianOpenId)) {
					aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
					aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
					aPIResult.setData(null);
					return aPIResult;
				}
				String jwtString = cJYunApiService.getStudentJwtByOpeId(guardianOpenId, studentId);
				jsonData = JSONObject.parseObject(jwtString);
				if (jsonData != null && jsonData.containsKey("token") && StringUtils.isNotBlank(jsonData.getString("token"))) {
					session.setAttribute("openIdJwtInfo", jwtString);
					openIdJwtInfo = jsonData;
				} else {
					aPIResult.setCode(ApiError.JWT_NOTFOUND.getCode());
					aPIResult.setMessage(ApiError.JWT_NOTFOUND.getMessage());
					aPIResult.setData(null);
					return aPIResult;
				}
			}
			JSONObject jsonData = JSONObject.parseObject(openIdJwtInfo.toString());
			String tempStr = cJYunApiService.studentDayStatis(studentId, teachingDate, jsonData.getString("token"));
			jsonData = JSONObject.parseObject(tempStr);
			try {
				if(jsonData!=null && jsonData.containsKey("data")) {
					JSONObject itmes = jsonData.getJSONObject("data").getJSONObject("items");
					if(itmes != null) {
						StringBuffer briefComment = new StringBuffer("{studentName}同学今天参与了{lessonNum}堂智慧课堂。");
						StringBuffer focusAndCorrectInfo = new StringBuffer("课堂中");
						Double focusRate = itmes.getDouble("focusRate");
						Double correctRate =itmes.getDouble("correctRate");
			            if (correctRate > 60) {
			                focusAndCorrectInfo.append("习题正确率很高，");
			            } else if (correctRate == 60) {
			            	focusAndCorrectInfo.append("习题正确率还不错，");
			            } else if (correctRate < 60) {
			            	focusAndCorrectInfo.append("习题正确率不是很高哦，");
			            }
						
						if (focusRate > 60) {
				            focusAndCorrectInfo.append("听课很专注，");
				        } else if (focusRate == 60) {
				            focusAndCorrectInfo .append("听课比较专注，");
				        } else if (focusRate < 60) {
				            focusAndCorrectInfo.append("听课不够专注哦，");
			                if (correctRate < 60) {
			                    focusAndCorrectInfo.append("有待加强，");
			                }
				        }
						briefComment.append(focusAndCorrectInfo);
				        if (itmes.containsKey("lessonNum") && itmes.getIntValue("lessonNum")> 1) {
				        	briefComment.append("其中表现最好的一堂课是：{bestLessonSubjectName}。");
				        	itmes.put("briefComment", briefComment);
				        } else {
				        	itmes.put("briefComment", briefComment.substring(0, briefComment.length()-1)+"。");
				        }
				        
				        
				        StringBuffer performanceComment = new StringBuffer("课堂中被选中答题{selectedNum}次，课堂中完成了{completePractiseNum}次练习题。");
				        if (itmes.containsKey("lessonAllPreivewNum")) {
				            if (itmes.containsKey("noReviewLessonSubjectNames") && StringUtils.isNoneBlank(itmes.getString("noReviewLessonSubjectNames"))) {
				                performanceComment.append("{noReviewLessonSubjectNames}没有完成老师布置的复习任务。");
				            } else {
				                performanceComment.append("完成老师布置的复习任务。");
				            }
				        }
				        if (itmes.containsKey("lessonAllPrepareNum")) {
				            if (itmes.containsKey("noPrepareLessonSubjectNames") && StringUtils.isEmpty(itmes.getString("noPrepareLessonSubjectNames"))) {
				            	performanceComment.append("完成老师布置的预习任务。");
				            	
				            } else {
				            	performanceComment.append("{noPrepareLessonSubjectNames}没有完成老师布置的预习任务。");
				            }
				        }
				        itmes.put("performanceComment", performanceComment);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			aPIResult = JSONObject.parseObject(jsonData.toJSONString(), aPIResult.getClass());
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("学生授课日概况异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	private void cleanLoginData(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String openId="";
		if (cookies != null && cookies.length > 0) {
			for (Cookie cookie : cookies) {
				if("wxOpenId".equals(cookie.getName())) {
					openId = cookie.getValue();
					continue;
				}
				cookie.setMaxAge(0);
				cookie.setPath("/");
				cookie.setDomain(".ecaicn.com");
				response.addCookie(cookie);
			}
		}
		HttpSession session = request.getSession();
		List<String> attributes = new ArrayList<String>();
		Enumeration<String> names = session.getAttributeNames();
		while (names.hasMoreElements()) {
			attributes.add(names.nextElement());
		}
		for (String attribute : attributes) {
			session.removeAttribute(attribute);
		}
		
		if(StringUtils.isNotBlank(openId)) {
			//设置cookie
			Cookie cookieOpenId = new Cookie("wxOpenId",openId);
			cookieOpenId.setPath("/");
			cookieOpenId.setDomain(".ecaicn.com");
	        response.addCookie(cookieOpenId);
			session.setAttribute("wxOpenId",openId);
		}
	}

	@GetMapping(value = "/helpcenter/commonqa", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)	
	public Map<String, Object> getCommonQa(
			@ApiParam(value = "问题", name = "question", required = false, example = "什么是专注度") @RequestParam(name = "question", required = false) String question,HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> retData = new HashMap<>();
		try {
			List<Map<Object, Object>> list = cJYunApiService.getCommonQa(question);
			retData.put("code", "0");
			retData.put("data", list);
			retData.put("message", "成功");
			return retData;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取帮助中心常见问题列表异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	@ApiOperation(value = "修改密码", httpMethod = "POST", consumes = "String")
	@PostMapping(value = "/user/updatePassword", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult updatePassword(@ApiParam(value = "新旧密码变更对象", required = true) @RequestBody UpdatePasswordParmsDto requestData,HttpServletRequest request, HttpServletResponse response) {
		APIResult aPIResult = new APIResult();
		HttpSession session = request.getSession();
		try {
			String oldPassword = requestData.getOldPassword();
			String newPassword = requestData.getNewPassword();
			if (StringUtils.isBlank(oldPassword) || StringUtils.isBlank(newPassword)) {
				aPIResult.setCode(ApiError.PARAS_INCOMPLETE.getCode());
				aPIResult.setMessage(ApiError.PARAS_INCOMPLETE.getMessage());
				aPIResult.setData("");
				return aPIResult;
			}
			String token = "";
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code")==0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.updatePassword(oldPassword, newPassword, token);
			aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
			return aPIResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("修改用户密码异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "家长-学情报告主页-顶部汇总统计", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/studentStatis", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth(needSchoolIds=true)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentStatisDto> studentStatis(HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentStatisDto> aPIResult = new APIResult<StudentStatisDto>();
		HttpSession session = request.getSession();
		try {
			String token = "";
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			Object schoolIds =  session.getAttribute("parentSchoolIds");
			if(schoolIds==null) {
				JSONObject json = new JSONObject();
				Map data = new HashMap();
				data.put("total", 0);
				Map sub = new HashMap();
				sub.put("homeWorkNum", 0);
				sub.put("lessonNum", 0);
				data.put("items", sub);
				json.remove("data");
				json.put("data", data);
				aPIResult = JSONObject.parseObject(json.toJSONString(),APIResult.class);
				return aPIResult;
			}
			String bindStudentListStr = cJYunApiService.getbindStudentList(token);
			JSONObject bindStudentListData =  JSONObject.parseObject(bindStudentListStr);
			List<String> studentIds = new ArrayList<>();
			try {
				if (bindStudentListData != null && bindStudentListData.getIntValue("code") == 0) {
					JSONArray ar = bindStudentListData.getJSONArray("data");
					for (Object studentData : ar) {
						JSONObject ajson = (JSONObject) studentData;
						studentIds.add(ajson.getString("studentId"));
					}
				} else {
					aPIResult.setCode(ApiError.NO_STUDENTS.getCode());
					aPIResult.setMessage(ApiError.NO_STUDENTS.getMessage());
					aPIResult.setData(null);
					return aPIResult;
				}
			}catch (Exception e){
				e.printStackTrace();
				log.error("家长-学情报告主页-顶部汇总统计异常:{}", e.getMessage());
				aPIResult.setCode(ApiError.NO_STUDENTS.getCode());
				aPIResult.setMessage(ApiError.NO_STUDENTS.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if(studentIds.size()<1){
				aPIResult.setCode(ApiError.NO_STUDENTS.getCode());
				aPIResult.setMessage(ApiError.NO_STUDENTS.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}		
			String tempStr = cJYunApiService.studentStatis(schoolIds.toString(),String.join(",",studentIds),token);
			JSONObject json = JSONObject.parseObject(tempStr);
			try {
				if(json.getIntValue("code")==0 && json.containsKey("data") && json.getJSONObject("data").getJSONObject("items")!=null) {
					JSONObject items =  json.getJSONObject("data").getJSONObject("items");
					if(!items.containsKey("homeWorkNum") || items.get("homeWorkNum")==null) {
						items.put("homeWorkNum", 0);
					}
					if(!items.containsKey("lessonNum") || items.get("lessonNum")==null) {
						items.put("lessonNum", 0);
					}
				}else if(json.getIntValue("code")==0){
					Map data = new HashMap();
					data.put("total", 0);
					Map sub = new HashMap();
					sub.put("homeWorkNum", 0);
					sub.put("lessonNum", 0);
					data.put("items", sub);
					json.remove("data");
					json.put("data", data);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}			
			aPIResult = JSONObject.parseObject(json.toJSONString(),APIResult.class);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("家长-学情报告主页-顶部汇总统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		if(aPIResult.getData() == null) {
			aPIResult.setCode(ApiError.UNKNOWN_ERROR.getCode());
			aPIResult.setMessage(ApiError.UNKNOWN_ERROR.getMessage());
			aPIResult.setData(null);
		}
		return aPIResult;
	}
	
	
	@ApiOperation(value = "家长-学情报告主页-学生学情日报列表", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/studentDayStatis", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth(needSchoolIds=true)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentDayStatisDtoNew> studentDayStatis_New(@ApiParam(value = "分页", name = "page", required = true, example = "1") @RequestParam(name = "page", required = true) String page,
			@ApiParam(value = "分页大小(默认10)", name = "pageSize", required = false, example = "10") @RequestParam(name = "pageSize", required = false,defaultValue="10") String pageSize,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentDayStatisDtoNew> aPIResult = new APIResult<StudentDayStatisDtoNew>();
		HttpSession session = request.getSession();
		try {
			String token = "";
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			
			String guardianOpenId = "";
			Object wxUserInfoSessionObject = session.getAttribute("wxUserInfo");
			if (wxUserInfoSessionObject == null) {
				guardianOpenId = (String) session.getAttribute("wxOpenId");
			} else {
				jsonData = JSONObject.parseObject(wxUserInfoSessionObject.toString());
				if (jsonData != null && jsonData.containsKey("openid")) {
					guardianOpenId = jsonData.getString("openid");
				} 
			}
			if (StringUtils.isBlank(guardianOpenId)) {
				aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
				aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			Object schoolIds =  session.getAttribute("parentSchoolIds");
			if(schoolIds==null) {
				JSONObject json = new JSONObject();
				Map data = new HashMap();
				data.put("total", 0);
				data.put("items", new ArrayList());
				json.put("data", data);
				aPIResult = JSONObject.parseObject(json.toJSONString(),aPIResult.getClass());
				return aPIResult;
			}
			String bindStudentListStr = cJYunApiService.getbindStudentList(token);
			JSONObject bindStudentListData =  JSONObject.parseObject(bindStudentListStr);
			List<String> studentIds = new ArrayList<>();
			try {
				if (bindStudentListData != null && bindStudentListData.getIntValue("code") == 0) {
					JSONArray ar = bindStudentListData.getJSONArray("data");
					for (Object studentData : ar) {
						JSONObject ajson = (JSONObject) studentData;
						studentIds.add(ajson.getString("studentId"));
					}
				} else {
					aPIResult.setCode(ApiError.NO_STUDENTS.getCode());
					aPIResult.setMessage(ApiError.NO_STUDENTS.getMessage());
					aPIResult.setData(null);
					return aPIResult;
				}
			}catch (Exception e){
				e.printStackTrace();
				log.error("家长-学情报告主页-学生学情日报列表异常:{}", e.getMessage());
				aPIResult.setCode(ApiError.NO_STUDENTS.getCode());
				aPIResult.setMessage(ApiError.NO_STUDENTS.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if(studentIds.size()<1){
				aPIResult.setCode(ApiError.NO_STUDENTS.getCode());
				aPIResult.setMessage(ApiError.NO_STUDENTS.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.studentDayStatisNew(page,pageSize,String.join(",",studentIds),schoolIds.toString(),token);
			JSONObject json = JSONObject.parseObject(tempStr);
			try {
				if(json.getIntValue("code")==0 && json.containsKey("data") && json.getJSONObject("data").getJSONArray("items").size()>0) {
					JSONArray array =  json.getJSONObject("data").getJSONArray("items");
					for (Object ar : array) {
						JSONObject itme = (JSONObject) ar;
						Integer studentId = itme.getIntValue("studentId");
						String teachingDate = itme.getString("teachingDate");
						if(StringUtils.isBlank(teachingDate)) {
							itme.put("teachingDate", "2017-11-16");
						}
						Integer readStatus = cJYunApiService.getStudentReadStatus(studentId,teachingDate,guardianOpenId);
						if(readStatus == null) {
							readStatus = 0;
						}
						itme.put("readStatus", readStatus);
					}
				}else if(json.getIntValue("code")==0){
					Map data = new HashMap();
					data.put("total", 0);
					data.put("items", new ArrayList());
					json.remove("data");
					json.put("data", data);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}			
			aPIResult = JSONObject.parseObject(json.toJSONString(),aPIResult.getClass());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("家长-学情报告主页-学生学情日报列表异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		if(aPIResult.getData() == null) {
			aPIResult.setCode(ApiError.UNKNOWN_ERROR.getCode());
			aPIResult.setMessage(ApiError.UNKNOWN_ERROR.getMessage());
			aPIResult.setData(null);
		}
		return aPIResult;
	}	

	@ApiOperation(value = "学生学习日报-课堂报告", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/studentLesson", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth(needSchoolIds=true)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentLessonDtoNew> studentLessonStatis(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-09-01") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentLessonDtoNew> aPIResult = new APIResult<StudentLessonDtoNew>();
		HttpSession session = request.getSession();
		try {
			String token = "";
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			Object schoolIds =  session.getAttribute("parentSchoolIds");
			if(schoolIds==null) {
				return aPIResult;
			}
			String tempStr = cJYunApiService.studentLessonStatis(studentId,teachingDate,schoolIds.toString(),token);
			JSONObject jsonData001 = JSONObject.parseObject(tempStr);
			if(jsonData001.getIntValue("code") == 0 && jsonData001.getJSONObject("data").getJSONObject("items").getIntValue("lessonNum") == 0) {
				StudentLessonDtoNew tempDta = new StudentLessonDtoNew();
				tempDta.setItems(null);
				aPIResult.setData(tempDta);
				return aPIResult;
			}
			String subTempStr = cJYunApiService.studentLessonStatisList(studentId,teachingDate,schoolIds.toString(),token);	
			JSONObject jsonData002 = JSONObject.parseObject(subTempStr);
			try {
				if(jsonData001!=null && jsonData001.containsKey("data") && jsonData001.getJSONObject("data").containsKey("items") && jsonData001.getJSONObject("data").getJSONObject("items")!=null&& jsonData002!=null && jsonData002.containsKey("data") && jsonData002.getJSONObject("data").containsKey("items") && jsonData002.getJSONObject("data").getJSONArray("items")!=null) {
					JSONObject data = jsonData001.getJSONObject("data").getJSONObject("items");
					data.put("lessonsStatis", jsonData002.getJSONObject("data").getJSONArray("items"));
					StringBuffer briefComment = new StringBuffer("{studentName}同学今天参与了{lessonNum}堂智慧课堂。");
					StringBuffer focusAndCorrectInfo = new StringBuffer("课堂中");
					Double correctRate = data.getDouble("correctRate");
					if(correctRate==null) {
						correctRate = 0.0;
					}
		            if (correctRate > 60) {
		                focusAndCorrectInfo.append("习题正确率很高，");
		            } else if (correctRate == 60) {
		            	focusAndCorrectInfo.append("习题正确率还不错，");
		            } else if (correctRate < 60) {
		            	focusAndCorrectInfo.append("习题正确率不是很高哦，");
		            }
		            Double focusRate = data.getDouble("focusRate");
		            if(focusRate==null) {
		            	focusRate = 0.0;
					}
					if (focusRate > 60) {
			            focusAndCorrectInfo.append("听课很专注，");
			        } else if (focusRate == 60) {
			            focusAndCorrectInfo .append("听课比较专注，");
			        } else if (focusRate < 60) {
			            focusAndCorrectInfo.append("听课不够专注哦，");
		                if (correctRate < 60) {
		                    focusAndCorrectInfo.append("有待加强，");
		                }
			        }
					Integer lessonNum = data.getInteger("lessonNum");
					 if(lessonNum==null) {
						 lessonNum = 0;
						}
					briefComment.append(focusAndCorrectInfo);
			        if (lessonNum !=null && lessonNum > 1) {
			        	briefComment.append("其中表现最好的一堂课是：{bestLessonSubjectName}。");
			        	jsonData001.getJSONObject("data").getJSONObject("items").put("lessonOverview",briefComment);
			        } else {
			        	jsonData001.getJSONObject("data").getJSONObject("items").put("lessonOverview",briefComment.substring(0, briefComment.length()-1)+"。");
			        }
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			aPIResult = JSONObject.parseObject(jsonData001.toJSONString(),aPIResult.getClass());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("学生学习日报-课堂报告异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		return aPIResult;
	}	

	@ApiOperation(value = "学生学习日报-课堂报告-顶部", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/studentLessonStatis", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth(needSchoolIds=true)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentLessonTotalDto> studentLessonStatisTotal(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-09-01") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentLessonTotalDto> aPIResult = new APIResult<StudentLessonTotalDto>();
		HttpSession session = request.getSession();
		try {
			String token = "";
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			
			String guardianOpenId = "";
			Object wxUserInfoSessionObject = session.getAttribute("wxUserInfo");
			if (wxUserInfoSessionObject == null) {
				guardianOpenId = (String) session.getAttribute("wxOpenId");
			} else {
				jsonData = JSONObject.parseObject(wxUserInfoSessionObject.toString());
				if (jsonData != null && jsonData.containsKey("openid")) {
					guardianOpenId = jsonData.getString("openid");
				} 
			}
			if (StringUtils.isBlank(guardianOpenId)) {
				aPIResult.setCode(ApiError.WX_OPENID_NOTFOUND.getCode());
				aPIResult.setMessage(ApiError.WX_OPENID_NOTFOUND.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			Object schoolIds =  session.getAttribute("parentSchoolIds");
			if(schoolIds==null) {
				return aPIResult;
			}
			
			String subTempStr = cJYunApiService.studentLessonStatisData(studentId,teachingDate,schoolIds.toString(),token);
			jsonData = JSONObject.parseObject(subTempStr);
			try {
				if(jsonData!=null && jsonData.containsKey("data") && jsonData.getJSONObject("data").containsKey("items") && jsonData.getJSONObject("data").getJSONArray("items")!=null && jsonData.getJSONObject("data").getJSONArray("items").size()>0) {
					JSONObject targetData = jsonData.getJSONObject("data").getJSONArray("items").getJSONObject(0);
					if(targetData.containsKey("studentName") && StringUtils.isBlank(targetData.getString("studentName"))) {
						String bindStudentStr = cJYunApiService.getbindStudentList(token);
						JSONObject bindStudentJson = JSONObject.parseObject(bindStudentStr);
						if(bindStudentJson.getIntValue("code") == 0 && bindStudentJson.getJSONArray("data").size()>0) {
							JSONArray bindStudentArray =  bindStudentJson.getJSONArray("data");
							for (Object student : bindStudentArray) {
								JSONObject studentJson = (JSONObject)student;
								if(studentJson.getString("userId").equals(studentId)) {
									targetData.put("studentId", studentId);
									targetData.put("studentName", studentJson.getString("realName"));
									targetData.put("className", studentJson.getString("className"));
								}
							}
						}
					}
					if(targetData.containsKey("criticismNum") && StringUtils.isBlank(targetData.getString("criticismNum"))) {
						targetData.put("criticismNum", 0);
					}
					if(targetData.containsKey("praiseNum") && StringUtils.isBlank(targetData.getString("praiseNum"))) {
						targetData.put("praiseNum", 0);
					}
					if(targetData.containsKey("bestNum") && StringUtils.isBlank(targetData.getString("bestNum"))) {
						targetData.put("bestNum", 0);
					}else if(targetData.containsKey("bestNum") && StringUtils.isNotBlank(targetData.getString("bestNum"))) {
						targetData.put("bestNum", Integer.parseInt(targetData.getString("bestNum")));
					}
					
					if(!targetData.containsKey("bestNum") || targetData.get("bestNum") == null) {
						targetData.put("bestNum",0);
					}
					if(!targetData.containsKey("criticismNum") || targetData.get("criticismNum") == null) {
						targetData.put("criticismNum",0);
					}
					if(!targetData.containsKey("praiseNum") || targetData.get("praiseNum") == null) {
						targetData.put("praiseNum",0);
					}
					jsonData.getJSONObject("data").remove("items");
					jsonData.getJSONObject("data").put("items", targetData);
					Integer readStatus =  cJYunApiService.getStudentReadStatus(Integer.parseInt(studentId), teachingDate, guardianOpenId);
					if(readStatus == null || readStatus.intValue() == 0) {
						cJYunApiService.updateStudentReadStatus(studentId,teachingDate,guardianOpenId);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			aPIResult = JSONObject.parseObject(jsonData.toJSONString(),aPIResult.getClass());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("学生学习日报-课堂报告异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		if(aPIResult.getData() == null) {
			aPIResult.setCode(ApiError.UNKNOWN_ERROR.getCode());
			aPIResult.setMessage(ApiError.UNKNOWN_ERROR.getMessage());
			aPIResult.setData(null);
		}
		return aPIResult;
	}	
	@ApiOperation(value = "学生学习日报-作业报告-今日作业概览", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/studentTodayHomeworkStatis", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth(needSchoolIds=true)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentTodayHomeworkStatisDto> studentTodayHomeworkStatis(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-09-01") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentTodayHomeworkStatisDto> aPIResult = new APIResult<StudentTodayHomeworkStatisDto>();
		HttpSession session = request.getSession();
		try {
			String token = "";
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			Object schoolIds =  session.getAttribute("parentSchoolIds");
			if(schoolIds==null) {
				return aPIResult;
			}
			String tempStr = cJYunApiService.studentTodayHomeworkStatis(studentId,teachingDate,schoolIds.toString(),token);
			try {
				jsonData = JSONObject.parseObject(tempStr);
				JSONObject itemsData = jsonData.getJSONObject("data").getJSONObject("items");
				if(jsonData!=null && jsonData.containsKey("code") && jsonData.getIntValue("code") ==0 && itemsData != null && itemsData.containsKey("quesionNum") && StringUtils.isNotBlank(itemsData.getString("quesionNum"))) {
					if(itemsData.containsKey("subjectNum") && StringUtils.isBlank(itemsData.getString("subjectNum"))) {
						itemsData.put("subjectNum", 0);
					}
					if(itemsData.containsKey("teacherEstimateTime") && StringUtils.isBlank(itemsData.getString("teacherEstimateTime"))) {
						itemsData.put("teacherEstimateTime", 0);
					}
					if(itemsData.containsKey("subjectName") && StringUtils.isBlank(itemsData.getString("subjectName"))) {
						itemsData.put("subjectName", "");
					}
				}else {
					StudentTodayHomeworkStatisDto tempObj = new StudentTodayHomeworkStatisDto();
					tempObj.setItems(null);
					aPIResult.setData(tempObj);
					return aPIResult;
				}
			} catch (Exception e) {
				log.error("学生学习日报-作业报告-今日作业统计异常:{}", e.getMessage());
				e.printStackTrace();
			}			
			aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("学生学习日报-作业报告-今日作业统计异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		return aPIResult;
	}
	
	@ApiOperation(value = "学生学习日报-作业报告-上次作业情况", httpMethod = "GET", consumes = "String")
	@GetMapping(value = "/report/studentYesterdayHomeworkStatis", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)	
	@ParentAuth(needSchoolIds=true)
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentYesterdayHomeworkStatisDto> studentYesterdayHomeworkStatis(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,
			@ApiParam(value = "教学日期", name = "teachingDate", required = true, example = "2017-09-01") @RequestParam(name = "teachingDate", required = true) String teachingDate,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentYesterdayHomeworkStatisDto> aPIResult = new APIResult<StudentYesterdayHomeworkStatisDto>();
		HttpSession session = request.getSession();
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = formatter.parse(teachingDate);
			Calendar calendar = new GregorianCalendar();
			calendar.setTime(date);
			calendar.add(5, -1);
			date = calendar.getTime(); 
			String token = "";
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			Object schoolIds =  session.getAttribute("parentSchoolIds");
			if(schoolIds==null) {
				return aPIResult;
			}
			String tempStr = cJYunApiService.studentYesterdayHomeworkStatis(studentId, formatter.format(date),schoolIds.toString(), token);
			jsonData = JSONObject.parseObject(tempStr);
			if (jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				jsonData.getJSONObject("data").put("homeworkDate", formatter.format(date));
			}
			JSONObject itemsData = jsonData.getJSONObject("data").getJSONObject("items");
			if(jsonData.containsKey("code") && jsonData.getIntValue("code") == 0 && itemsData != null && itemsData.containsKey("quesionNum") && itemsData.getIntValue("quesionNum") >0 ) {
				if(itemsData.containsKey("classCompleteRate") && StringUtils.isBlank(itemsData.getString("classCompleteRate"))) {
					itemsData.put("classCompleteRate", 0);
				}
				if(itemsData.containsKey("classCorrectRate") && StringUtils.isBlank(itemsData.getString("classCorrectRate"))) {
					itemsData.put("classCorrectRate", 0);
				}
				if(itemsData.containsKey("completeQuesionNum ") && StringUtils.isBlank(itemsData.getString("completeQuesionNum "))) {
					itemsData.put("completeQuesionNum ", 0);
				}
				if(itemsData.containsKey("completeRate") && StringUtils.isBlank(itemsData.getString("completeRate"))) {
					itemsData.put("completeRate", 0);
				}
				if(itemsData.containsKey("correctQuesionNum") && StringUtils.isBlank(itemsData.getString("correctQuesionNum"))) {
					itemsData.put("correctQuesionNum", 0);
				}
				if(itemsData.containsKey("correctQuesionNumOrder") && StringUtils.isBlank(itemsData.getString("correctQuesionNumOrder"))) {
					itemsData.put("correctQuesionNumOrder", 0);
				}
				if(itemsData.containsKey("correctRate") && StringUtils.isBlank(itemsData.getString("correctRate"))) {
					itemsData.put("correctRate", 0);
				}
				if(itemsData.containsKey("elapsedTime") && StringUtils.isBlank(itemsData.getString("elapsedTime"))) {
					itemsData.put("elapsedTime", 0);
				}
				if(itemsData.containsKey("elapsedTimeOrder") && StringUtils.isBlank(itemsData.getString("elapsedTimeOrder"))) {
					itemsData.put("elapsedTimeOrder", 0);
				}
				if(itemsData.containsKey("errorQuesionNum") && StringUtils.isBlank(itemsData.getString("errorQuesionNum"))) {
					itemsData.put("errorQuesionNum", 0);
				}
				if(itemsData.containsKey("teacherEstimateTime") && StringUtils.isBlank(itemsData.getString("teacherEstimateTime"))) {
					itemsData.put("teacherEstimateTime", 0);
				}
				if("0".equals(itemsData.getString("elapsedTime"))) {
					itemsData.put("completeQuesionNum","-");
					itemsData.put("errorQuesionNum", "-");
				}
				aPIResult = JSONObject.parseObject(jsonData.toJSONString(),aPIResult.getClass());
			}else {
				StudentYesterdayHomeworkStatisDto tempObj = new StudentYesterdayHomeworkStatisDto();
				tempObj.setHomeworkDate(formatter.format(date));
				tempObj.setItems(null);
				aPIResult.setData(tempObj);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("学生学习日报-作业报告-上次作业情况异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		return aPIResult;
	}
	
	
	/**
	 * 退出登录后解除微信账号的绑定，以便于微信端账号的切换。
	 * @param request
	 * @param response
	 * @return
	 */
	@ApiOperation(value = "退出登录", httpMethod = "POST", consumes = "String")
	@PostMapping(value = "/Weixin/exit", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public APIResult<ExitDto> exit(HttpServletRequest request, HttpServletResponse response) {
		HttpSession  session = request.getSession();
		APIResult<ExitDto> aPIResult = new APIResult<ExitDto>();
		aPIResult.setData(new ExitDto() );
		Object userSessionObject = session.getAttribute("userSession");
		if(userSessionObject!=null) {
			JSONObject jsonData = JSONObject.parseObject(userSessionObject.toString());
			if(jsonData !=null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0 ){
				try {
					String token = jsonData.getJSONObject("data").getString("token");
					cJYunApiService.deleteWeChatBind(token);
					cJYunApiService.logout(token);
				} catch (Exception e) {
					log.error("退出登录异常:{}", e.getMessage());
					e.printStackTrace();
				}
			}
			if(jsonData !=null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0 ){
				aPIResult.getData().setUserRoleTyp(jsonData.getJSONObject("data").getJSONObject("userSession").getString("type"));
			}else {
				aPIResult.getData().setUserRoleTyp("2");
			}
		}else {
			aPIResult.getData().setUserRoleTyp("2");
		}
		cleanLoginData(request,response);
		return aPIResult;
	}
	
	
	@GetMapping(value = "/teacher/class", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiOperation(value = "查询老师所教的班级", httpMethod = "GET", consumes = "String")
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<TeacherClassDto> teacherClass(HttpServletRequest request, HttpServletResponse response) {
		APIResult<TeacherClassDto> aPIResult = new APIResult<TeacherClassDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			String token = "";
			String teacherId = "";
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (jsonData != null && jsonData.getJSONObject("data").containsKey("userSession")&& jsonData.getJSONObject("data").getJSONObject("userSession").containsKey("id")) {
				teacherId = jsonData.getJSONObject("data").getJSONObject("userSession").getString("id");
			} else {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.teacherClass(teacherId,token);
			tempStr = tempStr.replaceAll("recordClassId", "classId");
			tempStr = tempStr.replaceAll("null", REPACE_STR);
			jsonData = JSONObject.parseObject(tempStr);
			if(jsonData!=null && jsonData.getIntValue("code") == 0) {
				JSONArray arr = jsonData.getJSONArray("data");
				List<Object> list = new ArrayList<>();
				for (Object object : arr) {
					JSONArray aa = (JSONArray)object;
					for (Object object2 : aa) {
						JSONObject data002 = (JSONObject)object2;
						list.add(data002);
					}
				}
				Map<String,List<Object>> items = new HashMap<>();
				items.put("items", list);
				jsonData.remove("data");
				jsonData.put("data", items);
				tempStr = jsonData.toJSONString();
				tempStr = tempStr.replaceAll(REPACE_STR, "null");
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}else{
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("查询老师所教的班级异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	
	@GetMapping(value = "/student/studyportrait", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth
	@ApiOperation(value = "孩子学习方法分析(学习画像)", httpMethod = "GET", consumes = "String")
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentStudyPortraitDto> studyPortrait(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,
			@ApiParam(value = "时段 7：最近7天，30：过去30天，semester：本学期", name = "period", required = true, example = "7：最近7天，30：过去30天，semester：本学期") @RequestParam(name = "period", required = true) String period,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentStudyPortraitDto> aPIResult = new APIResult<StudentStudyPortraitDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			String token = "";
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.studyPortrait(studentId,period,token);
			tempStr = tempStr.replaceAll("attendLectureHabit", "lessonHabit").replaceAll("classAttendLectureHabit", "classLessonHabit").replaceAll("classHomeWorkHabit", "classHomeworkHabit")
			.replaceAll("classLearnResultHabit", "classLearningEffect").replaceAll("classPlanHabit", "classPlanHabit").replaceAll("classPrepareHabit", "classPreviewHabit").replaceAll("classReviewHabit", "classReviewHabit")
			.replaceAll("homeWorkHabit", "homeworkHabit").replaceAll("learnResultHabit", "learningEffect").replaceAll("planHabit", "planHabit").replaceAll("prepareHabit", "previewHabit").replaceAll("reviewHabit", "reviewHabit")
			.replaceAll("null", REPACE_STR);
			jsonData = JSONObject.parseObject(tempStr);
			if(jsonData!=null && jsonData.getIntValue("code") == 0) {
				JSONObject jsonData0;
				try {
					jsonData0 = (JSONObject)jsonData.getJSONObject("data").getJSONArray("items").get(0);
					/*if(jsonData0.getDouble("classPlanHabit") == null) {
						jsonData0.put("classPlanHabit", 0.0);
					}
					if(jsonData0.getDouble("homeworkHabit") == null) {
						jsonData0.put("homeworkHabit", 0.0);
					}
					if(jsonData0.getDouble("classHomeworkHabit")==null) {
						jsonData0.put("classHomeworkHabit", 0.0);
					}
					if(jsonData0.getDouble("lessonHabit")==null) {
						jsonData0.put("lessonHabit", 0.0);
					}
					if(jsonData0.getDouble("classLessonHabit")==null) {
						jsonData0.put("classLessonHabit", 0.0);
					}
					if(jsonData0.getDouble("reviewHabit")==null) {
						jsonData0.put("reviewHabit", 0.0);
					}
					if(jsonData0.getDouble("classReviewHabit")==null) {
						jsonData0.put("classReviewHabit", 0.0);
					}
					if(jsonData0.getDouble("previewHabit")==null) {
						jsonData0.put("previewHabit", 0.0);
					}
					if(jsonData0.getDouble("planHabit")==null) {
						jsonData0.put("planHabit", 0.0);
					}
					if(jsonData0.getDouble("classPreviewHabit")==null) {
						jsonData0.put("classPreviewHabit", 0.0);
					}
					if(jsonData0.getDouble("learningEffect")==null) {
						jsonData0.put("learningEffect", 0.0);
					}
					if(jsonData0.getDouble("classLearningEffect")==null) {
						jsonData0.put("classLearningEffect", 0.0);
					}*/
					jsonData0.remove("studentName");
				} catch (Exception e) {
					jsonData0= new JSONObject();
				}
				Map<String,JSONObject>mapData = new HashMap<>();
				mapData.put("items", jsonData0);
				jsonData.remove("data");
				jsonData.put("data", mapData);
				aPIResult = JSONObject.parseObject(jsonData.toJSONString().replaceAll(REPACE_STR, "null"),aPIResult.getClass());				
				return aPIResult;
			}else{
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("孩子学习方法分析异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	@GetMapping(value = "/teacher/classPerformance", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiOperation(value = "教师学情分析-班级整体表现", httpMethod = "GET", consumes = "String")
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<ClassPerformanceDto> classPerformance(
			@ApiParam(value = "班级ID", name = "classId", required = true) @RequestParam(name = "classId", required = true) String classId,
			@ApiParam(value = "科目ID,班主任时，不传", name = "subjectId", required = false, example = "科目ID，班主任时，不传") @RequestParam(name = "subjectId", required = false) String subjectId,
			@ApiParam(value = "时段 7：最近7天，30：过去30天，semester：本学期", name = "period", required = true, example = "7：最近7天，30：过去30天，semester：本学期") @RequestParam(name = "period", required = true) String period,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<ClassPerformanceDto> aPIResult = new APIResult<ClassPerformanceDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			String token = "";
			String teacherId = "";
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (jsonData != null && jsonData.getJSONObject("data").containsKey("userSession")&& jsonData.getJSONObject("data").getJSONObject("userSession").containsKey("id")) {
				teacherId = jsonData.getJSONObject("data").getJSONObject("userSession").getString("id");
			} else {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.classPerformance(teacherId,classId,subjectId,period,token);
			tempStr =  tempStr.replaceAll("cohesionScore", "cohesion").replaceAll("homeWorkCompleteRate", "completeRate").replaceAll("confidentScore", "confidentRate").replaceAll("selfAppraisedScore", "selfEvaluationScore");
			jsonData = JSONObject.parseObject(tempStr);
			if(jsonData!=null && jsonData.getIntValue("code") == 0) {
				JSONObject jsonData0;
				try {
					jsonData0 = (JSONObject)jsonData.getJSONObject("data").getJSONObject("items");
				} catch (Exception e) {
					jsonData0= new JSONObject();
				}
				Map<String,JSONObject>mapData = new HashMap<>();
				mapData.put("items", jsonData0);
				jsonData.remove("data");
				jsonData.put("data", mapData);
				aPIResult = JSONObject.parseObject(jsonData.toJSONString(),aPIResult.getClass());
				return aPIResult;
			}else{
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师学情分析-班级整体表现异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	
	
	
	@GetMapping(value = "/student/performanceTrendListData", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth
	@ApiOperation(value = "孩子最近表现趋势(趋势图列表数据)", httpMethod = "GET", consumes = "String")
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentPerformanceTrendChartDataDto> performanceTrendListData(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,
			@ApiParam(value = "时段 day：天数，week：学周，month：月份", name = "period", required = true, example = "day：天数，week：学周，month：月份") @RequestParam(name = "period", required = true) String period,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentPerformanceTrendChartDataDto> aPIResult = new APIResult<StudentPerformanceTrendChartDataDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			String token = "";
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.performanceTrendListData(studentId,period,token);
			jsonData = JSONObject.parseObject(tempStr);
			if(jsonData!=null && jsonData.getIntValue("code") == 0) {
				JSONArray arr;
				try {
					arr = (JSONArray)jsonData.getJSONObject("data").getJSONArray("items");
				} catch (Exception e) {
					arr = new JSONArray();
				}
				Map<String,JSONArray>mapData = new HashMap<>();
				for (Object object : arr) {
					JSONObject tempJsonData = (JSONObject)object;
					tempJsonData.remove("ui_student_id");
				}
				mapData.put("items", arr);
				jsonData.remove("data");
				jsonData.put("data", mapData);
				aPIResult = JSONObject.parseObject(jsonData.toJSONString(),aPIResult.getClass());
				return aPIResult;
			}else{
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("孩子最近表现趋势异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	@GetMapping(value = "/student/performanceTrendData", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth
	@ApiOperation(value = "孩子最近表现趋势", httpMethod = "GET", consumes = "String")
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<StudentPerformanceTrendDto> performanceTrend(
			@ApiParam(value = "学生id", name = "studentId", required = true, example = "456") @RequestParam(name = "studentId", required = true) String studentId,HttpServletRequest request, HttpServletResponse response) {
		APIResult<StudentPerformanceTrendDto> aPIResult = new APIResult<StudentPerformanceTrendDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			String token = "";
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.performanceTrend(studentId,token);
			tempStr = tempStr.replaceAll("selfevaluationScore", "selfEvaluationScore");
			tempStr = tempStr.replaceAll("null", REPACE_STR);
			jsonData = JSONObject.parseObject(tempStr);
			if(jsonData!=null && jsonData.getIntValue("code") == 0) {
				JSONObject jsonData0;
				try {
					jsonData0 = (JSONObject)jsonData.getJSONObject("data").getJSONArray("items").get(0);
					jsonData0.remove("ui_student_id");
				} catch (Exception e) {
					jsonData0= new JSONObject();
				}
				Map<String,JSONObject>mapData = new HashMap<>();
				mapData.put("items", jsonData0);
				jsonData.remove("data");
				jsonData.put("data", mapData);
				aPIResult = JSONObject.parseObject(jsonData.toJSONString().replaceAll(REPACE_STR, "null"),aPIResult.getClass());
				return aPIResult;
			}else{
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("孩子最近表现趋势异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	
	@GetMapping(value = "/teacher/classPerformanceTrendListData", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiOperation(value = "教师学情分析-班级最近表现趋势((趋势图列表数据))", httpMethod = "GET", consumes = "String")
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<ClassPerformanceTrendListDataDto> classPerformanceTrendListData(
			@ApiParam(value = "班级ID", name = "classId", required = true) @RequestParam(name = "classId", required = true) String classId,
			@ApiParam(value = "科目ID,班主任时，不传", name = "subjectId", required = false, example = "科目ID，班主任时，不传") @RequestParam(name = "subjectId", required = false) String subjectId,
			@ApiParam(value = "时段 day：天数，week：学周，month：月份", name = "period", required = true, example = "day：天数，week：学周，month：月份") @RequestParam(name = "period", required = true) String period,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<ClassPerformanceTrendListDataDto> aPIResult = new APIResult<ClassPerformanceTrendListDataDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			String token = "";
			String teacherId = "";
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (jsonData != null && jsonData.getJSONObject("data").containsKey("userSession")&& jsonData.getJSONObject("data").getJSONObject("userSession").containsKey("id")) {
				teacherId = jsonData.getJSONObject("data").getJSONObject("userSession").getString("id");
			} else {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.classPerformanceTrendChartData(teacherId,classId,subjectId,period,token);
			jsonData = JSONObject.parseObject(tempStr);
			if(jsonData!=null && jsonData.getIntValue("code") == 0) {
				JSONArray arr;
				try {
					arr = (JSONArray)jsonData.getJSONObject("data").getJSONArray("items");
				} catch (Exception e) {
					arr = new JSONArray();
				}
				Map<String,JSONArray>mapData = new HashMap<>();
				mapData.put("items", arr);
				jsonData.remove("data");
				jsonData.put("data", mapData);
				aPIResult = JSONObject.parseObject(jsonData.toJSONString(),aPIResult.getClass());
				return aPIResult;
			}else{
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师学情分析-班级最近表现趋势:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	@GetMapping(value = "/teacher/classPerformanceTrend", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@TeacherAuth
	@ApiOperation(value = "教师学情分析-班级最近表现趋势", httpMethod = "GET", consumes = "String")
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<ClassPerformanceTrendDto> classPerformanceTrend(	
			@ApiParam(value = "班级ID", name = "classId", required = true) @RequestParam(name = "classId", required = true) String classId,
			@ApiParam(value = "科目ID,班主任时，不传", name = "subjectId", required = false, example = "科目ID，班主任时，不传") @RequestParam(name = "subjectId", required = false) String subjectId,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<ClassPerformanceTrendDto> aPIResult = new APIResult<ClassPerformanceTrendDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			String token = "";
			String teacherId = "";
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (jsonData != null && jsonData.getJSONObject("data").containsKey("userSession")&& jsonData.getJSONObject("data").getJSONObject("userSession").containsKey("id")) {
				teacherId = jsonData.getJSONObject("data").getJSONObject("userSession").getString("id");
			} else {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(teacherId)) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.classPerformanceTrend(teacherId,classId,subjectId,token);
			tempStr = tempStr.replaceAll("null", REPACE_STR);
			jsonData = JSONObject.parseObject(tempStr);
			if(jsonData!=null && jsonData.getIntValue("code") == 0) {
				JSONObject jsonData0;
				try {
					jsonData0 = (JSONObject)jsonData.getJSONObject("data").getJSONArray("items").get(0);
				} catch (Exception e) {
					jsonData0= new JSONObject();
				}
				Map<String,JSONObject>mapData = new HashMap<>();
				mapData.put("items", jsonData0);
				jsonData.remove("data");
				jsonData.put("data", mapData);
				aPIResult = JSONObject.parseObject(jsonData.toJSONString().replaceAll(REPACE_STR, "null"),aPIResult.getClass());
				return aPIResult;
			}else{
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("教师学情分析-班级最近表现趋势:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	
	/**
	 * 
	 * @param studentId
	 * @param request
	 * @param response
	 * @return
	 */
	@GetMapping(value = "/hotreports", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ParentAuth
	@ApiOperation(value = "课堂热报", httpMethod = "GET", consumes = "String")
	@ApiImplicitParam(name = "openId", value = "微信openid(测试使用可不传)", required = false, dataType = "string", paramType = "header")
	public APIResult<HotReportsDto> hotreports(@ApiParam(value = "分页", name = "pageNo", required = true, example = "1") @RequestParam(name = "pageNo", required = true) String pageNo,
			@ApiParam(value = "分页大小(默认20)", name = "pageSize", required = false, example = "20") @RequestParam(name = "pageSize", required = false,defaultValue="20") String pageSize,
			HttpServletRequest request, HttpServletResponse response) {
		APIResult<HotReportsDto> aPIResult = new APIResult<HotReportsDto>();
		HttpSession session = request.getSession();
		try {
			Object userLogInfoSessionObject = session.getAttribute("userSession");
			String token = "";
			if (userLogInfoSessionObject == null) {
				aPIResult.setCode(ApiError.NO_LOGIN.getCode());
				aPIResult.setMessage(ApiError.NO_LOGIN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			JSONObject jsonData = JSONObject.parseObject(userLogInfoSessionObject.toString());
			if (jsonData != null && jsonData.containsKey("code") && jsonData.getIntValue("code") == 0) {
				token = jsonData.getJSONObject("data").getString("token");
			} else {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			if (StringUtils.isBlank(token)) {
				aPIResult.setCode(ApiError.NO_TOKEN.getCode());
				aPIResult.setMessage(ApiError.NO_TOKEN.getMessage());
				aPIResult.setData(null);
				return aPIResult;
			}
			String tempStr = cJYunApiService.hotreports(token,pageNo,pageSize);
			tempStr = tempStr.replaceAll("null", REPACE_STR);
			jsonData = JSONObject.parseObject(tempStr);
			if(jsonData!=null && jsonData.getIntValue("code") == 0) {
				JSONArray  arr;
				try {
					arr = (JSONArray)jsonData.getJSONObject("data").getJSONArray("items");
					for (Object item : arr) {
						JSONObject json = (JSONObject)item;
						String content = json.getString("content");
						if(StringUtils.isNotBlank(content)) {
							json.put("contents", Arrays.asList(content.split("#")));
						}
						json.remove("content");
						if(json.containsKey("eventTime")) {
							json.put("lessonTime", json.getString("eventTime"));
							json.put("reportDate", json.getString("eventTime").substring(0, 10));
						}
						json.put("hotReportsId",UUID.randomUUID().toString());
					}
				} catch (Exception e) {
					aPIResult = JSONObject.parseObject(jsonData.toJSONString().replaceAll(REPACE_STR, "null"),aPIResult.getClass());
					return aPIResult;
				}
				aPIResult = JSONObject.parseObject(jsonData.toJSONString().replaceAll(REPACE_STR, "null"),aPIResult.getClass());
				return aPIResult;
			}else{
				aPIResult = JSONObject.parseObject(tempStr,aPIResult.getClass());
				return aPIResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("课堂热报异常:{}", e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
}
