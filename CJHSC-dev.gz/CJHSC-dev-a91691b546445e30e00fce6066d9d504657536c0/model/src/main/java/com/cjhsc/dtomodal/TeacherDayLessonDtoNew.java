package com.cjhsc.dtomodal;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.TeacherDayLessonDtoNew  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:33:34
* 描述：
*
 */
@ApiModel(description = "教师日课统计列表")
public class TeacherDayLessonDtoNew {
	@ApiModelProperty(value = "教师日课统计数据", name = "items")
	private List<TeacherDayLessonStaticData> items;
	@ApiModelProperty(value = "记录数", name = "total", required = true, example = "0")
	private Integer total;
	
	@ApiModelProperty(value = "活跃度",name="activeRate")
	private Double activeRate ;	
	
	@ApiModelProperty(value = "正确率",name="correctRate")
	private Double correctRate ;
	
	@ApiModelProperty(value = "关注度",name="focusRate")
	private Double focusRate ;
	
	public List<TeacherDayLessonStaticData> getItems() {
		return items;
	}

	public void setItems(List<TeacherDayLessonStaticData> items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}
	public Double getActiveRate() {
		return activeRate;
	}

	public void setActiveRate(Double activeRate) {
		this.activeRate = activeRate;
	}

	public Double getCorrectRate() {
		return correctRate;
	}

	public void setCorrectRate(Double correctRate) {
		this.correctRate = correctRate;
	}

	public Double getFocusRate() {
		return focusRate;
	}

	public void setFocusRate(Double focusRate) {
		this.focusRate = focusRate;
	}

	@ApiModel(description = "教师日课统计数据")
	class TeacherDayLessonStaticData{
		@ApiModelProperty(value = "活跃度", name = "activeRate")
		private Double activeRate;
		
		@ApiModelProperty(value = "授课班级名称", name = "className")
		private String className;
		
		@ApiModelProperty(value = "正确度", name = "correctRate")
		private Double correctRate;
		
		@ApiModelProperty(value = "课堂结束时间", name = "lessonEndTime")
		private String lessonEndTime;
		
		@ApiModelProperty(value = "课堂Id", name = "lessonId")
		private String lessonId;
		
		@ApiModelProperty(value = "课堂起始时间", name = "lessonStartTime")
		private String lessonStartTime;
		
		@ApiModelProperty(value = "课堂整体质量得分", name = "meanScore")
		private Double meanScore;
		
		public Double getActiveRate() {
			return activeRate;
		}

		public void setActiveRate(Double activeRate) {
			this.activeRate = activeRate;
		}

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public String getLessonEndTime() {
			return lessonEndTime;
		}

		public void setLessonEndTime(String lessonEndTime) {
			this.lessonEndTime = lessonEndTime;
		}

		public String getLessonId() {
			return lessonId;
		}

		public void setLessonId(String lessonId) {
			this.lessonId = lessonId;
		}

		public String getLessonStartTime() {
			return lessonStartTime;
		}

		public void setLessonStartTime(String lessonStartTime) {
			this.lessonStartTime = lessonStartTime;
		}

		public Double getMeanScore() {
			return meanScore;
		}

		public void setMeanScore(Double meanScore) {
			this.meanScore = meanScore;
		}		
	}
}
