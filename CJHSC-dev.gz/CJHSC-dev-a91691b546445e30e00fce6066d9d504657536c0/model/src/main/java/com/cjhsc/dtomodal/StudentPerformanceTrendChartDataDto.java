package com.cjhsc.dtomodal;


import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.StudentPerformanceTrendChartDataDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:28:53
* 描述：
*
 */
@ApiModel(description = "孩子最近表现趋势对象(趋势图表数据)")
public class StudentPerformanceTrendChartDataDto {
		@ApiModelProperty(value = "表现趋势数据列表(趋势图表数据)", name = "items")
		private  List<TrendListData> items;
		
		public List<TrendListData> getItems() {
			return items;
		}

		public void setItems(List<TrendListData> items) {
			this.items = items;
		}


		class TrendListData{
			@ApiModelProperty(value = "日期时间", name = "teachingDate")
			private String teachingDate;
			@ApiModelProperty(value = "作业完成率", name = "homeworkCompleteRate")
			private Double homeworkCompleteRate;
			
			@ApiModelProperty(value = "学习正确率", name = "correctRate")
			private Double correctRate;
			
			@ApiModelProperty(value = "课堂活跃度", name = "activeRate")
			private Double activeRate;

			public String getTeachingDate() {
				return teachingDate;
			}

			public void setTeachingDate(String teachingDate) {
				this.teachingDate = teachingDate;
			}

			public Double getHomeworkCompleteRate() {
				return homeworkCompleteRate;
			}

			public void setHomeworkCompleteRate(Double homeworkCompleteRate) {
				this.homeworkCompleteRate = homeworkCompleteRate;
			}

			public Double getCorrectRate() {
				return correctRate;
			}

			public void setCorrectRate(Double correctRate) {
				this.correctRate = correctRate;
			}

			public Double getActiveRate() {
				return activeRate;
			}

			public void setActiveRate(Double activeRate) {
				this.activeRate = activeRate;
			}
		}
}
