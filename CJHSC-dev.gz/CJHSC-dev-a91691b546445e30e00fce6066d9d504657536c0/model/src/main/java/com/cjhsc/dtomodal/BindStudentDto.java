package com.cjhsc.dtomodal;

import java.util.List;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.BindStudentDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:22:39
* 描述：
*
 */
@ApiModel(description="已绑定孩子列表")
public class BindStudentDto {
	@ApiModelProperty(value = "已绑定孩子数组",name="items")
	private List<BindStudent> items;
	
	public List<BindStudent> getItems() {
		return items;
	}

	public void setItems(List<BindStudent> items) {
		this.items = items;
	}

	@ApiModel(description="孩子对象")
	class BindStudent{
		@ApiModelProperty(value = "孩子生日",name="birthDate")
		private String birthDate;
		
		@ApiModelProperty(value = "班级id",name="classId")
		private String classId;
		
		@ApiModelProperty(value = "班级名称",name="className")
		private String className;
		
		@ApiModelProperty(value = "email地址",name="email")
		private String email;
		
		@ApiModelProperty(value = "家庭关系代码",name="familyRelationCode" ,required = true,example="FATHER")
		private String familyRelationCode;
		
		@ApiModelProperty(value = "家庭关系名称",name="familyRelationName",required = true,example="父亲")
		private String familyRelationName;
		
		@ApiModelProperty(value = "年级id",name="gradeId")
		private String gradeId;
		
		@ApiModelProperty(value = "年级名称",name="gradeName")
		private String gradeName;
		
		@ApiModelProperty(value = "身份证号",name="idcard")
		private String idcard;	
		
		@ApiModelProperty(value = "手机号",name="mobile")
		private String mobile;
		
		@ApiModelProperty(value = "学生姓名",name="realName")
		private String realName;
		
		@ApiModelProperty(value = "班级记录id",name="recordClassId")
		private String recordClassId;
		
		@ApiModelProperty(value = "教室名称",name="roomName")
		private String roomName;
		
		@ApiModelProperty(value = "学校id",name="schoolId")
		private String schoolId;
		
		@ApiModelProperty(value = "学校名称",name="schoolName")
		private String schoolName;
		
		@ApiModelProperty(value = "学校类型",name="schoolTypeName")
		private String schoolTypeName;	
		
		@ApiModelProperty(value = "学生性别",name="sex")
		private String sex;
		
		@ApiModelProperty(value = "学生id",name="studentId")
		private String studentId;
		
		@ApiModelProperty(value = "用户id",name="userId")
		private String userId;
		
		@ApiModelProperty(value = "学生学情读取状态",name="reprotReadStatus")
		private Integer reprotReadStatus;
		
		@ApiModelProperty(value = "最新学情更新时间",name="lastReportDate")
		private String lastReportDate;
		
		@ApiModelProperty(value = "是否毕业,true:没有毕业, false:已毕业",name="activeStatus")
		private Boolean activeStatus;


		public Boolean getActiveStatus() {
			return activeStatus;
		}

		public void setActiveStatus(Boolean activeStatus) {
			this.activeStatus = activeStatus;
		}

		public String getClassId() {
			return classId;
		}

		public void setClassId(String classId) {
			this.classId = classId;
		}

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getFamilyRelationCode() {
			return familyRelationCode;
		}

		public void setFamilyRelationCode(String familyRelationCode) {
			this.familyRelationCode = familyRelationCode;
		}

		public String getFamilyRelationName() {
			return familyRelationName;
		}

		public void setFamilyRelationName(String familyRelationName) {
			this.familyRelationName = familyRelationName;
		}

		public String getGradeId() {
			return gradeId;
		}

		public void setGradeId(String gradeId) {
			this.gradeId = gradeId;
		}

		public String getGradeName() {
			return gradeName;
		}

		public void setGradeName(String gradeName) {
			this.gradeName = gradeName;
		}

		public String getIdcard() {
			return idcard;
		}

		public void setIdcard(String idcard) {
			this.idcard = idcard;
		}

		public String getMobile() {
			return mobile;
		}

		public void setMobile(String mobile) {
			this.mobile = mobile;
		}

		public String getRealName() {
			return realName;
		}

		public void setRealName(String realName) {
			this.realName = realName;
		}

		public String getRecordClassId() {
			return recordClassId;
		}

		public void setRecordClassId(String recordClassId) {
			this.recordClassId = recordClassId;
		}

		public String getRoomName() {
			return roomName;
		}

		public void setRoomName(String roomName) {
			this.roomName = roomName;
		}

		public String getSchoolId() {
			return schoolId;
		}

		public void setSchoolId(String schoolId) {
			this.schoolId = schoolId;
		}

		public String getSchoolName() {
			return schoolName;
		}

		public void setSchoolName(String schoolName) {
			this.schoolName = schoolName;
		}

		public String getSchoolTypeName() {
			return schoolTypeName;
		}

		public void setSchoolTypeName(String schoolTypeName) {
			this.schoolTypeName = schoolTypeName;
		}

		public String getSex() {
			return sex;
		}

		public void setSex(String sex) {
			this.sex = sex;
		}

		public String getStudentId() {
			return studentId;
		}

		public void setStudentId(String studentId) {
			this.studentId = studentId;
		}

		public String getUserId() {
			return userId;
		}

		public void setUserId(String userId) {
			this.userId = userId;
		}

		public Integer getReprotReadStatus() {
			return reprotReadStatus;
		}

		public void setReprotReadStatus(Integer reprotReadStatus) {
			this.reprotReadStatus = reprotReadStatus;
		}

		public String getBirthDate() {
			return birthDate;
		}

		public void setBirthDate(String birthDate) {
			this.birthDate = birthDate;
		}

		public String getLastReportDate() {
			return lastReportDate;
		}

		public void setLastReportDate(String lastReportDate) {
			this.lastReportDate = lastReportDate;
		}
	}
}
