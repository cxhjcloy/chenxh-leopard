package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.StudentYesterdayHomeworkStatisDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:31:56
* 描述：
*
 */
@ApiModel(description="学生作业报告上次作业情况")
public class StudentYesterdayHomeworkStatisDto {
	@ApiModelProperty(value = "上次作业情况数据",name="items")
	private StudentYesterdayHomeworkStatis items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	@ApiModelProperty(value = "昨日作业日期",name="homeworkDate")
	private String homeworkDate;
	
	
	public String getHomeworkDate() {
		return homeworkDate;
	}

	public void setHomeworkDate(String homeworkDate) {
		this.homeworkDate = homeworkDate;
	}

	public StudentYesterdayHomeworkStatis getItems() {
		return items;
	}

	public void setItems(StudentYesterdayHomeworkStatis items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="上次作业情况数据")
	class StudentYesterdayHomeworkStatis{
		@ApiModelProperty(value = "班级作业完成率",name="classCompleteRate")
		private Double classCompleteRate;
		
		@ApiModelProperty(value = "班级课堂正确率",name="classCorrectRate")
		private Double classCorrectRate;
		
		@ApiModelProperty(value = "完成题目数",name="completeQuesionNum")
		private Integer completeQuesionNum;
		
		@ApiModelProperty(value = "作业完成率",name="completeRate")
		private Double completeRate;
		
		@ApiModelProperty(value = "正确习题数",name="correctQuesionNum")
		private Integer correctQuesionNum;
		
		@ApiModelProperty(value = "正确率班级排名",name="correctQuesionNumOrder")
		private Integer correctQuesionNumOrder;
		
		@ApiModelProperty(value = "课堂正确率",name="correctRate")
		private Double correctRate;
		
		@ApiModelProperty(value = "实际总耗时",name="elapsedTime")
		private String elapsedTime;
		
		@ApiModelProperty(value = "耗时班级排行",name="elapsedTimeOrder")
		private Integer elapsedTimeOrder;
		
		@ApiModelProperty(value = "错误习题数",name="errorQuesionNum")
		private Integer errorQuesionNum;
		
		@ApiModelProperty(value = "总题目数",name="quesionNum")
		private Integer quesionNum;
		
		@ApiModelProperty(value = "教师预估总时长",name="teacherEstimateTime")
		private String teacherEstimateTime;

		@ApiModelProperty(value = "作业日期",name="homeworkDate")
		private String homeworkDate;
		
		public Double getClassCompleteRate() {
			return classCompleteRate;
		}

		public void setClassCompleteRate(Double classCompleteRate) {
			this.classCompleteRate = classCompleteRate;
		}

		public Double getClassCorrectRate() {
			return classCorrectRate;
		}

		public void setClassCorrectRate(Double classCorrectRate) {
			this.classCorrectRate = classCorrectRate;
		}

		public Integer getCompleteQuesionNum() {
			return completeQuesionNum;
		}

		public void setCompleteQuesionNum(Integer completeQuesionNum) {
			this.completeQuesionNum = completeQuesionNum;
		}

		public Double getCompleteRate() {
			return completeRate;
		}

		public void setCompleteRate(Double completeRate) {
			this.completeRate = completeRate;
		}

		public Integer getCorrectQuesionNum() {
			return correctQuesionNum;
		}

		public void setCorrectQuesionNum(Integer correctQuesionNum) {
			this.correctQuesionNum = correctQuesionNum;
		}

		public Integer getCorrectQuesionNumOrder() {
			return correctQuesionNumOrder;
		}

		public void setCorrectQuesionNumOrder(Integer correctQuesionNumOrder) {
			this.correctQuesionNumOrder = correctQuesionNumOrder;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public String getElapsedTime() {
			return elapsedTime;
		}

		public void setElapsedTime(String elapsedTime) {
			this.elapsedTime = elapsedTime;
		}

		public Integer getElapsedTimeOrder() {
			return elapsedTimeOrder;
		}

		public void setElapsedTimeOrder(Integer elapsedTimeOrder) {
			this.elapsedTimeOrder = elapsedTimeOrder;
		}

		public Integer getErrorQuesionNum() {
			return errorQuesionNum;
		}

		public void setErrorQuesionNum(Integer errorQuesionNum) {
			this.errorQuesionNum = errorQuesionNum;
		}

		public Integer getQuesionNum() {
			return quesionNum;
		}

		public void setQuesionNum(Integer quesionNum) {
			this.quesionNum = quesionNum;
		}

		public String getTeacherEstimateTime() {
			return teacherEstimateTime;
		}

		public String getHomeworkDate() {
			return homeworkDate;
		}

		public void setHomeworkDate(String homeworkDate) {
			this.homeworkDate = homeworkDate;
		}

		public void setTeacherEstimateTime(String teacherEstimateTime) {
			this.teacherEstimateTime = teacherEstimateTime;
		}
	}
}
