package com.cjhsc.dtomodal;



import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="学生授课日概况对象")
public class StudentDayStatisDto {
	@ApiModelProperty(value = "学生学情数据",name="items")
	private StudentDayStatisData items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	public StudentDayStatisData getItems() {
		return items;
	}
	public void setItems(StudentDayStatisData items) {
		this.items = items;
	}	
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="学生学情数据")
	class StudentDayStatisData{
		@ApiModelProperty(value = "学生活跃度",name="activeRate")
		private Double activeRate;//学生活跃度
		
		@ApiModelProperty(value = "最佳课堂科目名称",name="bestLessonSubjectName")
		private String bestLessonSubjectName;//最佳课堂科目名称
		
		@ApiModelProperty(value = "被评最佳次数",name="bestNum")
		private Integer bestNum;//被评最佳次数
		
		@ApiModelProperty(value = "班级活跃度 ",name="classActiveRate")
		private Double classActiveRate;//班级活跃度 
		
		@ApiModelProperty(value = "班级正确率",name="classCorrectRate")
		private Double classCorrectRate;//班级正确率		
		
		@ApiModelProperty(value = "班级专注度 ",name="classFocusRate")
		private Double classFocusRate;//班级专注度 
		
		@ApiModelProperty(value = "班级名称",name="className")
		private String className;//班级名称
		
		@ApiModelProperty(value = "完成练习次数",name="completePractiseNum")
		private Integer completePractiseNum;//完成练习次数
		
		@ApiModelProperty(value = "正确率",name="correctRate")
		private Double correctRate;//正确率		
		
		@ApiModelProperty(value = "批评次数",name="criticismNum")
		private Integer criticismNum;//批评次数
		
		@ApiModelProperty(value = "课堂表现平均评价分数",name="estimateAvgScore")
		private Double estimateAvgScore;//课堂表现平均评价分数
		
		@ApiModelProperty(value = "学生专注度",name="focusRate")
		private Double focusRate;//学生专注度
		
		@ApiModelProperty(value = "学生年级名称",name="gradeName")
		private Double gradeName;//学生年级名称
		
		@ApiModelProperty(value = "学生举手次数",name="handsupNum")
		private Integer handsupNum;//学生举手次数
		
		@ApiModelProperty(value = "课堂总提问互动总次数",name="lessonAllAskedNum")
		private Integer lessonAllAskedNum;//课堂总提问互动总次数
		
		@ApiModelProperty(value = "课堂调查互动总次数",name="lessonAllInvestigatedNum")
		private Integer lessonAllInvestigatedNum;//课堂调查互动总次数		
		
		@ApiModelProperty(value = "课堂习题互动总次数",name="lessonAllPractiseNum")
		private Integer lessonAllPractiseNum;//课堂习题互动总次数
		
		@ApiModelProperty(value = "教师发起复习调查总次数",name="lessonAllPreivewNum")
		private Integer lessonAllPreivewNum;//教师发起复习调查总次数
		
		@ApiModelProperty(value = "教师发起预习调查总次数",name="lessonAllPrepareNum")
		private Integer lessonAllPrepareNum;//教师发起预习调查总次数
		
		@ApiModelProperty(value = "学生上课次数",name="lessonNum")
		private Integer lessonNum;//学生上课次数
		
		@ApiModelProperty(value = "未预习科目名称(多个使用逗号拼接)",name="noPrepareLessonSubjectNames")
		private String noPrepareLessonSubjectNames;//未预习科目名称(多个使用逗号拼接)
		
		@ApiModelProperty(value = "未复习科目名称(多个使用逗号拼接)",name="noReviewLessonSubjectNames")
		private String noReviewLessonSubjectNames;//未复习科目名称(多个使用逗号拼接)
		
		@ApiModelProperty(value = "学生举手被选中总次数",name="pitchOnHandsupNum")
		private Integer pitchOnHandsupNum;//学生举手被选中总次数
		
		@ApiModelProperty(value = "学生被表扬次数",name="praiseNum")
		private Integer praiseNum;//学生被表扬次数
		
		@ApiModelProperty(value = "学生习题练习次数",name="practiseNum")
		private Integer practiseNum;//学生习题练习次数
		
		@ApiModelProperty(value = "学校名称",name="schoolName")
		private String schoolName;//学校名称
		
		@ApiModelProperty(value = "举手被选中次数",name="selectedNum")
		private Integer selectedNum;//举手被选中次数
		
		@ApiModelProperty(value = "学生姓名",name="studentName")
		private String studentName;//学生姓名

		public Double getActiveRate() {
			return activeRate;
		}

		public void setActiveRate(Double activeRate) {
			this.activeRate = activeRate;
		}

		public String getBestLessonSubjectName() {
			return bestLessonSubjectName;
		}

		public void setBestLessonSubjectName(String bestLessonSubjectName) {
			this.bestLessonSubjectName = bestLessonSubjectName;
		}

		public Integer getBestNum() {
			return bestNum;
		}

		public void setBestNum(Integer bestNum) {
			this.bestNum = bestNum;
		}

		public Double getClassActiveRate() {
			return classActiveRate;
		}

		public void setClassActiveRate(Double classActiveRate) {
			this.classActiveRate = classActiveRate;
		}

		public Double getClassCorrectRate() {
			return classCorrectRate;
		}

		public void setClassCorrectRate(Double classCorrectRate) {
			this.classCorrectRate = classCorrectRate;
		}

		public Double getClassFocusRate() {
			return classFocusRate;
		}

		public void setClassFocusRate(Double classFocusRate) {
			this.classFocusRate = classFocusRate;
		}

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public Integer getCompletePractiseNum() {
			return completePractiseNum;
		}

		public void setCompletePractiseNum(Integer completePractiseNum) {
			this.completePractiseNum = completePractiseNum;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public Integer getCriticismNum() {
			return criticismNum;
		}

		public void setCriticismNum(Integer criticismNum) {
			this.criticismNum = criticismNum;
		}

		public Double getEstimateAvgScore() {
			return estimateAvgScore;
		}

		public void setEstimateAvgScore(Double estimateAvgScore) {
			this.estimateAvgScore = estimateAvgScore;
		}

		public Double getFocusRate() {
			return focusRate;
		}

		public void setFocusRate(Double focusRate) {
			this.focusRate = focusRate;
		}

		public Double getGradeName() {
			return gradeName;
		}

		public void setGradeName(Double gradeName) {
			this.gradeName = gradeName;
		}

		public Integer getHandsupNum() {
			return handsupNum;
		}

		public void setHandsupNum(Integer handsupNum) {
			this.handsupNum = handsupNum;
		}

		public Integer getLessonAllAskedNum() {
			return lessonAllAskedNum;
		}

		public void setLessonAllAskedNum(Integer lessonAllAskedNum) {
			this.lessonAllAskedNum = lessonAllAskedNum;
		}

		public Integer getLessonAllInvestigatedNum() {
			return lessonAllInvestigatedNum;
		}

		public void setLessonAllInvestigatedNum(Integer lessonAllInvestigatedNum) {
			this.lessonAllInvestigatedNum = lessonAllInvestigatedNum;
		}

		public Integer getLessonAllPractiseNum() {
			return lessonAllPractiseNum;
		}

		public void setLessonAllPractiseNum(Integer lessonAllPractiseNum) {
			this.lessonAllPractiseNum = lessonAllPractiseNum;
		}

		public Integer getLessonAllPreivewNum() {
			return lessonAllPreivewNum;
		}

		public void setLessonAllPreivewNum(Integer lessonAllPreivewNum) {
			this.lessonAllPreivewNum = lessonAllPreivewNum;
		}

		public Integer getLessonAllPrepareNum() {
			return lessonAllPrepareNum;
		}

		public void setLessonAllPrepareNum(Integer lessonAllPrepareNum) {
			this.lessonAllPrepareNum = lessonAllPrepareNum;
		}

		public Integer getLessonNum() {
			return lessonNum;
		}

		public void setLessonNum(Integer lessonNum) {
			this.lessonNum = lessonNum;
		}

		public String getNoPrepareLessonSubjectNames() {
			return noPrepareLessonSubjectNames;
		}

		public void setNoPrepareLessonSubjectNames(String noPrepareLessonSubjectNames) {
			this.noPrepareLessonSubjectNames = noPrepareLessonSubjectNames;
		}

		public String getNoReviewLessonSubjectNames() {
			return noReviewLessonSubjectNames;
		}

		public void setNoReviewLessonSubjectNames(String noReviewLessonSubjectNames) {
			this.noReviewLessonSubjectNames = noReviewLessonSubjectNames;
		}

		public Integer getPitchOnHandsupNum() {
			return pitchOnHandsupNum;
		}

		public void setPitchOnHandsupNum(Integer pitchOnHandsupNum) {
			this.pitchOnHandsupNum = pitchOnHandsupNum;
		}

		public Integer getPraiseNum() {
			return praiseNum;
		}

		public void setPraiseNum(Integer praiseNum) {
			this.praiseNum = praiseNum;
		}

		public Integer getPractiseNum() {
			return practiseNum;
		}

		public void setPractiseNum(Integer practiseNum) {
			this.practiseNum = practiseNum;
		}

		public String getSchoolName() {
			return schoolName;
		}

		public void setSchoolName(String schoolName) {
			this.schoolName = schoolName;
		}

		public Integer getSelectedNum() {
			return selectedNum;
		}

		public void setSelectedNum(Integer selectedNum) {
			this.selectedNum = selectedNum;
		}

		public String getStudentName() {
			return studentName;
		}

		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}	
		
	}
}
