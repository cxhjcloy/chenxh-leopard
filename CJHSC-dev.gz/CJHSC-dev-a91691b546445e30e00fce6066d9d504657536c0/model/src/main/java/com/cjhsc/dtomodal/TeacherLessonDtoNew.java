package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.TeacherLessonDtoNew  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:34:58
* 描述：
*
 */
@ApiModel(description="教师课堂观察详情对象")
public class TeacherLessonDtoNew {
	@ApiModelProperty(value = "教师课堂观察详情数据",name="items")
	private TeacherLessonStaticData items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public TeacherLessonStaticData getItems() {
		return items;
	}

	public void setItems(TeacherLessonStaticData items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="教师课堂观察详情数据")
	class TeacherLessonStaticData{
		@ApiModelProperty(value="课堂活跃度",name="activeRate")
		private Integer activeRate;
		
		@ApiModelProperty(value="提问互动次数",name="askedNum")
		private Integer askedNum;
		
		@ApiModelProperty(value="课堂最佳表现学生名称(逗号分隔)",name="bestStudentNames")
		private String bestStudentNames;
		
		@ApiModelProperty(value="课堂正确度",name="correctRate")
		private Double correctRate;
		
		@ApiModelProperty(value="课堂难易度",name="difficultyRate")
		private Double difficultyRate;
		
		@ApiModelProperty(value="学生对课堂的评价分",name="estimateScore")
		private Double estimateScore;
		
		@ApiModelProperty(value="课堂专注度",name="focusRate")
		private Double focusRate;
		
		@ApiModelProperty(value="课堂完整度",name="integrityRate")
		private Double integrityRate;
		
		@ApiModelProperty(value="调查互动次数",name="investigatedNum")
		private Integer investigatedNum;
		
		@ApiModelProperty(value="习题互动次数",name="practiseNum")
		private Integer practiseNum;
		
		@ApiModelProperty(value="课堂预习率",name="prepareRate")
		private Integer prepareRate;

		public Integer getActiveRate() {
			return activeRate;
		}

		public void setActiveRate(Integer activeRate) {
			this.activeRate = activeRate;
		}

		public Integer getAskedNum() {
			return askedNum;
		}

		public void setAskedNum(Integer askedNum) {
			this.askedNum = askedNum;
		}

		public String getBestStudentNames() {
			return bestStudentNames;
		}

		public void setBestStudentNames(String bestStudentNames) {
			this.bestStudentNames = bestStudentNames;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public Double getDifficultyRate() {
			return difficultyRate;
		}

		public void setDifficultyRate(Double difficultyRate) {
			this.difficultyRate = difficultyRate;
		}

		public Double getEstimateScore() {
			return estimateScore;
		}

		public void setEstimateScore(Double estimateScore) {
			this.estimateScore = estimateScore;
		}

		public Double getFocusRate() {
			return focusRate;
		}

		public void setFocusRate(Double focusRate) {
			this.focusRate = focusRate;
		}

		public Double getIntegrityRate() {
			return integrityRate;
		}

		public void setIntegrityRate(Double integrityRate) {
			this.integrityRate = integrityRate;
		}

		public Integer getInvestigatedNum() {
			return investigatedNum;
		}

		public void setInvestigatedNum(Integer investigatedNum) {
			this.investigatedNum = investigatedNum;
		}

		public Integer getPractiseNum() {
			return practiseNum;
		}

		public void setPractiseNum(Integer practiseNum) {
			this.practiseNum = practiseNum;
		}

		public Integer getPrepareRate() {
			return prepareRate;
		}

		public void setPrepareRate(Integer prepareRate) {
			this.prepareRate = prepareRate;
		}
	}
}
