package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.StudentLessonTotalDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:28:33
* 描述：
*
 */
@ApiModel(description="学习日报汇总信息")
public class StudentLessonTotalDto {
	
	@ApiModelProperty(value = "学习日报汇总数据",name="items")
	private StudentLessonTotalData items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	public StudentLessonTotalData getItems() {
		return items;
	}
	public void setItems(StudentLessonTotalData items) {
		this.items = items;
	}	
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	@ApiModel(description="学习日报汇总数据")
	class StudentLessonTotalData{
		@ApiModelProperty(value = "学生所在班级",name="className")
		private String className;
		
		@ApiModelProperty(value = "学生Id",name="studentId")
		private Integer studentId;
		
		@ApiModelProperty(value = "学生姓名",name="studentName")
		private String studentName;
		
		@ApiModelProperty(value = "被评最佳次数",name="bestNum")
		private Integer bestNum;	
		@ApiModelProperty(value = "被批评次数",name="criticismNum")
		private Integer criticismNum;
		
		@ApiModelProperty(value = "被表扬次数",name="praiseNum")
		private Integer praiseNum;

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public Integer getStudentId() {
			return studentId;
		}

		public void setStudentId(Integer studentId) {
			this.studentId = studentId;
		}

		public String getStudentName() {
			return studentName;
		}

		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}

		public Integer getBestNum() {
			return bestNum;
		}

		public void setBestNum(Integer bestNum) {
			this.bestNum = bestNum;
		}

		public Integer getCriticismNum() {
			return criticismNum;
		}

		public void setCriticismNum(Integer criticismNum) {
			this.criticismNum = criticismNum;
		}

		public Integer getPraiseNum() {
			return praiseNum;
		}

		public void setPraiseNum(Integer praiseNum) {
			this.praiseNum = praiseNum;
		}	
	}
}
