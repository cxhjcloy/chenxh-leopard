package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.StudentTodayHomeworkStatisDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:31:36
* 描述：
*
 */
@ApiModel(description="学生学习日报今日作业概览对象")
public class StudentTodayHomeworkStatisDto {
	@ApiModelProperty(value = "今日作业概览数据",name="items")
	private StudentTodayHomeworkStatis items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public StudentTodayHomeworkStatis getItems() {
		return items;
	}

	public void setItems(StudentTodayHomeworkStatis items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="今日作业概览数据对象")
	class StudentTodayHomeworkStatis{
		@ApiModelProperty(value = "作业题目数",name="quesionNum")
		private Integer quesionNum;
		@ApiModelProperty(value = "科目名称",name="subjectName")
		private String subjectName;
		@ApiModelProperty(value = "科目数",name="subjectNum")
		private Integer subjectNum;
		@ApiModelProperty(value = "教师预估总时长",name="teacherEstimateTime")
		private String teacherEstimateTime;
		public Integer getQuesionNum() {
			return quesionNum;
		}
		public void setQuesionNum(Integer quesionNum) {
			this.quesionNum = quesionNum;
		}
		public String getSubjectName() {
			return subjectName;
		}
		public void setSubjectName(String subjectName) {
			this.subjectName = subjectName;
		}
		public Integer getSubjectNum() {
			return subjectNum;
		}
		public void setSubjectNum(Integer subjectNum) {
			this.subjectNum = subjectNum;
		}
		public String getTeacherEstimateTime() {
			return teacherEstimateTime;
		}
		public void setTeacherEstimateTime(String teacherEstimateTime) {
			this.teacherEstimateTime = teacherEstimateTime;
		}
	}
}
