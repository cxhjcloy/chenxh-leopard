package com.cjhsc.dtomodal;



import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.ClassPerformanceTrendDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:24:18
* 描述：
*
 */
@ApiModel(description = "班级最近表现趋势对象")
public class ClassPerformanceTrendDto {
	@ApiModelProperty(value = "班级最近表现趋势数据", name = "items")
	private ClassPerformanceTrend items;

	public ClassPerformanceTrend getItems() {
		return items;
	}

	public void setItems(ClassPerformanceTrend items) {
		this.items = items;
	}

	@ApiModel(description = "班级最近表现趋势数据")
	class ClassPerformanceTrend {
		@ApiModelProperty(value = "作业完成率", name = "homeworkCompleteRate")
		private Double homeworkCompleteRate;
		
		@ApiModelProperty(value = "学生正确率", name = "correctRate")
		private Double correctRate;
		
		@ApiModelProperty(value = "课堂举手次数", name = "handsupNum")
		private Integer handsupNum;
		
		@ApiModelProperty(value = "课堂答题", name = "answerNum")
		private Integer answerNum;
		
		@ApiModelProperty(value = "主动反馈次数", name = "feedbackNum")
		private Integer feedbackNum;
		
		@ApiModelProperty(value = "评价自己", name = "teacherEvaluationScore")
		private Double teacherEvaluationScore;
		
		@ApiModelProperty(value = "评价课堂", name = "lessonEvaluationScore")
		private Double lessonEvaluationScore;
		
		@ApiModelProperty(value = "批评次数",name="criticismNum")
		private Integer criticismNum;
		
		@ApiModelProperty(value = "表扬次数",name="praiseNum")
		private Integer praiseNum;

		public Double getHomeworkCompleteRate() {
			return homeworkCompleteRate;
		}

		public void setHomeworkCompleteRate(Double homeworkCompleteRate) {
			this.homeworkCompleteRate = homeworkCompleteRate;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public Integer getHandsupNum() {
			return handsupNum;
		}

		public void setHandsupNum(Integer handsupNum) {
			this.handsupNum = handsupNum;
		}

		public Integer getAnswerNum() {
			return answerNum;
		}

		public void setAnswerNum(Integer answerNum) {
			this.answerNum = answerNum;
		}

		public Integer getFeedbackNum() {
			return feedbackNum;
		}

		public void setFeedbackNum(Integer feedbackNum) {
			this.feedbackNum = feedbackNum;
		}

		public Double getTeacherEvaluationScore() {
			return teacherEvaluationScore;
		}

		public void setTeacherEvaluationScore(Double teacherEvaluationScore) {
			this.teacherEvaluationScore = teacherEvaluationScore;
		}

		public Double getLessonEvaluationScore() {
			return lessonEvaluationScore;
		}

		public void setLessonEvaluationScore(Double lessonEvaluationScore) {
			this.lessonEvaluationScore = lessonEvaluationScore;
		}

		public Integer getCriticismNum() {
			return criticismNum;
		}

		public void setCriticismNum(Integer criticismNum) {
			this.criticismNum = criticismNum;
		}

		public Integer getPraiseNum() {
			return praiseNum;
		}

		public void setPraiseNum(Integer praiseNum) {
			this.praiseNum = praiseNum;
		}
	}
}
