package com.cjhsc.dtomodal;


import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.TeacherClassDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:32:45
* 描述：
*
 */
@ApiModel(description = "教师所教的班级列表")
public class TeacherClassDto {
	@ApiModelProperty(value = "教师所教的班级数据", name = "items")
	private List<ClassDto> items;

	public List<ClassDto> getItems() {
		return items;
	}

	public void setItems(List<ClassDto> items) {
		this.items = items;
	}

	@ApiModel(description = "教师所教的班级数据")
	class ClassDto {

		@ApiModelProperty(value = "班级名称", name = "className")
		private String className;

		@ApiModelProperty(value = "班级Id", name = "recordClassId")
		private String classId;

		@ApiModelProperty(value = "班级名称", name = "name")
		private String name;

		@ApiModelProperty(value = "学校Id", name = "schoolId")
		private String schoolId;

		@ApiModelProperty(value = "学校名称", name = "schoolName")
		private String schoolName;

		@ApiModelProperty(value = "职务名称", name = "positionName")
		private String positionName;
		
		@ApiModelProperty(value = "职务Id", name = "positionId")
		private String positionId;
		
		@ApiModelProperty(value = "科目Id", name = "subjectId")
		private String subjectId;
		
		@ApiModelProperty(value = "科目名称", name = "subjectName")
		private String subjectName;

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public String getClassId() {
			return classId;
		}

		public void setClassId(String classId) {
			this.classId = classId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getSchoolId() {
			return schoolId;
		}

		public void setSchoolId(String schoolId) {
			this.schoolId = schoolId;
		}

		public String getSchoolName() {
			return schoolName;
		}

		public void setSchoolName(String schoolName) {
			this.schoolName = schoolName;
		}

		public String getPositionName() {
			return positionName;
		}

		public void setPositionName(String positionName) {
			this.positionName = positionName;
		}

		public String getPositionId() {
			return positionId;
		}

		public void setPositionId(String positionId) {
			this.positionId = positionId;
		}

		public String getSubjectId() {
			return subjectId;
		}

		public void setSubjectId(String subjectId) {
			this.subjectId = subjectId;
		}

		public String getSubjectName() {
			return subjectName;
		}

		public void setSubjectName(String subjectName) {
			this.subjectName = subjectName;
		}		
	}

}
