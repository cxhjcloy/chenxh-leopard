package com.cjhsc.dtomodal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.BindStudentParmsDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:12:27
* 描述：
*
 */
@ApiModel(description="绑定学生请求对象")
public class BindStudentParmsDto {
	@ApiModelProperty(value = "学生姓名",name="studentName", required = true,example="张玮")
	private String studentName;
	@ApiModelProperty(value = "学生验证码",name="verificationCode", required = true,example="34891387")
	private String verificationCode;
	@ApiModelProperty(value = "家庭关系代码",name="familyRelationCode", required = true,example="FATHER")
	private String familyRelationCode;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getVerificationCode() {
		return verificationCode;
	}
	public void setVerificationCode(String verificationCode) {
		this.verificationCode = verificationCode;
	}
	public String getFamilyRelationCode() {
		return familyRelationCode;
	}
	public void setFamilyRelationCode(String familyRelationCode) {
		this.familyRelationCode = familyRelationCode;
	}
}
