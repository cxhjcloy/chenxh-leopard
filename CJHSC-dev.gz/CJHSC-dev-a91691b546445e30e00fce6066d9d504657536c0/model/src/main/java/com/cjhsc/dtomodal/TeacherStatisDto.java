package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="教师学期统计指标")
public class TeacherStatisDto {
	@ApiModelProperty(value = "教师学期统计数据",name="items")
	private TeacherStatisData items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public TeacherStatisData getItems() {
		return items;
	}

	public void setItems(TeacherStatisData items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="教师学期统计指标")
	class TeacherStatisData{
		@ApiModelProperty(value = "智慧课堂授课数",name="lessonNum")
		private String lessonNum;//智慧课堂授课数
		
		@ApiModelProperty(value = "智慧课堂发布互动数",name="interactionsCount")
		private Integer interactionsCount;//智慧课堂发布互动数

		public String getLessonNum() {
			return lessonNum;
		}

		public void setLessonNum(String lessonNum) {
			this.lessonNum = lessonNum;
		}

		public Integer getInteractionsCount() {
			return interactionsCount;
		}

		public void setInteractionsCount(Integer interactionsCount) {
			this.interactionsCount = interactionsCount;
		}		
	}
}
