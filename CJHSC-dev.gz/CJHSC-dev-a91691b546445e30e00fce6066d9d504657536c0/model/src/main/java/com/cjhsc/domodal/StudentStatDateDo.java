package com.cjhsc.domodal;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.domodal.StudentStatDateDo  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:22:17
* 描述：
*
 */
public class StudentStatDateDo {

    /**
     * 微信openId
     */
    private String openId;

    /**
     * 学生ID
     */
    private String studentId;

    /**
     * 统计日期
     */
    private String statDate;


    public StudentStatDateDo() {
    }


    public StudentStatDateDo(String openId, String studentId, String statDate) {
        this.openId = openId;
        this.studentId = studentId;
        this.statDate = statDate;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }
}
