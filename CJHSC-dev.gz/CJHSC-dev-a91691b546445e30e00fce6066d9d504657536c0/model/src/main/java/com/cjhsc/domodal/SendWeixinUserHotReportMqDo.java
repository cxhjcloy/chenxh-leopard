package com.cjhsc.domodal;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.domodal.SendWeixinUserHotReportMqDo  
* @author：chenxh  
* 创建时间：2018年1月18日 下午2:43:37
* 描述：
*
 */
public class SendWeixinUserHotReportMqDo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 热报日期
	 */
	private String reportDate;
	
	@ApiModelProperty(value = "",name="guardianId", required = true,example="123")
	/**
	 * 家长Id
	 */
	private String guardianId;
	/**
	 * 学生Id
	 */
	private String studentId;
	
	/**
	 * 学生姓名
	 */
	private String studentName;
	
	/**
	 * 课堂id
	 */
	private String lessonId;
	
	/**
	 * 科目名称
	 */
	private String lessonName;
	
	/**
	 * 课堂开始时间
	 */
	private String lessonTime;
	
	/**
	 * 教师名称
	 */
	private String teacherName;
	
	/**
	 * 热报内容
	 */
	private List<String> contents;
	
	
	/**
     * 跳转链接
     */
    private String link;

	public String getReportDate() {
		return reportDate;
	}

	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

	public String getGuardianId() {
		return guardianId;
	}

	public void setGuardianId(String guardianId) {
		this.guardianId = guardianId;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getLessonId() {
		return lessonId;
	}

	public void setLessonId(String lessonId) {
		this.lessonId = lessonId;
	}

	public String getLessonName() {
		return lessonName;
	}

	public void setLessonName(String lessonName) {
		this.lessonName = lessonName;
	}

	public String getLessonTime() {
		return lessonTime;
	}

	public void setLessonTime(String lessonTime) {
		this.lessonTime = lessonTime;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public List<String> getContents() {
		return contents;
	}

	public void setContents(List<String> contents) {
		this.contents = contents;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public String toString() {
		return "SendWeixinUserHotReportMqDo [reportDate=" + reportDate + ", guardianId=" + guardianId + ", studentId="
				+ studentId + ", studentName=" + studentName + ", lessonId=" + lessonId + ", lessonName=" + lessonName
				+ ", lessonTime=" + lessonTime + ", teacherName=" + teacherName + ", contents=" + contents + ", link="
				+ link + "]";
	}
}
