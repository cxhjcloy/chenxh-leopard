package com.cjhsc.dtomodal;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.TeacherDayLessonCountDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:33:11
* 描述：
*
 */
@ApiModel(description="教师日授课总数统计对象")
public class TeacherDayLessonCountDto {
	@ApiModelProperty(value = "教师日授课列表",name="items")
	private List<TeacherDayLesson> items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public List<TeacherDayLesson> getItems() {
		return items;
	}

	public void setItems(List<TeacherDayLesson> items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="教师日授课对象")
	class TeacherDayLesson{
		@ApiModelProperty(value = "日授课总次数",name="lessonNum")
		private Integer lessonNum;
		
		@ApiModelProperty(value = "授课日期",name="teachingDate")
		private Integer teachingDate;

		public Integer getLessonNum() {
			return lessonNum;
		}

		public void setLessonNum(Integer lessonNum) {
			this.lessonNum = lessonNum;
		}

		public Integer getTeachingDate() {
			return teachingDate;
		}

		public void setTeachingDate(Integer teachingDate) {
			this.teachingDate = teachingDate;
		}		
	}
}
