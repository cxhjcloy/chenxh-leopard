package com.cjhsc.dtomodal;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "教师日课统计列表")
public class TeacherDayLessonDto {
	@ApiModelProperty(value = "教师日课统计数据", name = "items")
	private TeacherDayLessonData items;// 教师日课统计数据

	@ApiModelProperty(value = "记录数", name = "total", required = true, example = "0")
	private Integer total;//

	public TeacherDayLessonData getItems() {
		return items;
	}

	public void setItems(TeacherDayLessonData items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description = "教师日课统计数据")
	class TeacherDayLessonData {
		@ApiModelProperty(value = "教师授课记录列表", name = "records")
		private List<TeacherDayRecords> records;
		@ApiModelProperty(value = "日统计汇总数据", name = "statis")
		private TeacherDayStatis statis;

		public List<TeacherDayRecords> getRecords() {
			return records;
		}

		public void setRecords(List<TeacherDayRecords> records) {
			this.records = records;
		}

		public TeacherDayStatis getStatis() {
			return statis;
		}

		public void setStatis(TeacherDayStatis statis) {
			this.statis = statis;
		}

		@ApiModel(description = "教师授课记录")
		class TeacherDayRecords {
			@ApiModelProperty(value = "班级名称", name = "className")
			private String className;// 班级名称

			@ApiModelProperty(value = "年级名称", name = "gradeName")
			private String gradeName;// 年级名称

			@ApiModelProperty(value = "课堂结束时间", name = "lessonEndTime")
			private String lessonEndTime;// 课堂结束时间

			@ApiModelProperty(value = "课堂Id", name = "lessonId")
			private String lessonId;// 课堂Id

			@ApiModelProperty(value = "课堂开始时间", name = "lessonStartTime")
			private String lessonStartTime;// 课堂开始时间

			@ApiModelProperty(value = "课堂整体质量均分", name = "meanScore")
			private Double meanScore;// 课堂整体质量均分

			@ApiModelProperty(value = "课堂科目名称", name = "subjectName")
			private String subjectName;// 课堂科目名称

			public String getClassName() {
				return className;
			}

			public void setClassName(String className) {
				this.className = className;
			}

			public String getGradeName() {
				return gradeName;
			}

			public void setGradeName(String gradeName) {
				this.gradeName = gradeName;
			}

			public String getLessonEndTime() {
				return lessonEndTime;
			}

			public void setLessonEndTime(String lessonEndTime) {
				this.lessonEndTime = lessonEndTime;
			}

			public String getLessonId() {
				return lessonId;
			}

			public void setLessonId(String lessonId) {
				this.lessonId = lessonId;
			}

			public String getLessonStartTime() {
				return lessonStartTime;
			}

			public void setLessonStartTime(String lessonStartTime) {
				this.lessonStartTime = lessonStartTime;
			}

			public Double getMeanScore() {
				return meanScore;
			}

			public void setMeanScore(Double meanScore) {
				this.meanScore = meanScore;
			}

			public String getSubjectName() {
				return subjectName;
			}

			public void setSubjectName(String subjectName) {
				this.subjectName = subjectName;
			}		
		}

		@ApiModel(description = "日统计汇总数据")
		class TeacherDayStatis {
			@ApiModelProperty(value = "活跃度", name = "activeRate")
			private Double activeRate;// 活跃度
			
			@ApiModelProperty(value = "正确度", name = "correctRate")
			private Double correctRate;// 正确度
			
			@ApiModelProperty(value = "关注度", name = "focusRate")
			private Double focusRate;// 关注度

			public Double getActiveRate() {
				return activeRate;
			}

			public void setActiveRate(Double activeRate) {
				this.activeRate = activeRate;
			}

			public Double getCorrectRate() {
				return correctRate;
			}

			public void setCorrectRate(Double correctRate) {
				this.correctRate = correctRate;
			}

			public Double getFocusRate() {
				return focusRate;
			}

			public void setFocusRate(Double focusRate) {
				this.focusRate = focusRate;
			}		
		}
	}
}
