package com.cjhsc.dtomodal;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.TeacherDayLessonTotalDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:34:19
* 描述：
*
 */
@ApiModel(description="教师日授课总数统计对象")
public class TeacherDayLessonTotalDto {
	@ApiModelProperty(value = "教师课堂观察报告列表",name="items")
	private List<TeacherDayTotalLesson> items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public List<TeacherDayTotalLesson> getItems() {
		return items;
	}

	public void setItems(List<TeacherDayTotalLesson> items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="教师课堂观察报告对象")
	class TeacherDayTotalLesson{
		@ApiModelProperty(value = "日授智慧课总次数", name = "lessonNum")
		private Integer lessonNum;

		@ApiModelProperty(value = "授课日期", name = "teachingDate")
		private String teachingDate;

		@ApiModelProperty(value = "活跃度", name = "activeRate")
		private Double activeRate;

		@ApiModelProperty(value = "正确率", name = "correctRate")
		private Double correctRate;

		@ApiModelProperty(value = "关注度", name = "focusRate")
		private Double focusRate;//

		@ApiModelProperty(value = "用户是否阅读 0:未阅读 1：已阅读", name = "readStatus")
		private Integer readStatus = 0;//

		
		public Integer getLessonNum() {
			return lessonNum;
		}

		public void setLessonNum(Integer lessonNum) {
			this.lessonNum = lessonNum;
		}

		public Integer getReadStatus() {
			return readStatus;
		}

		public void setReadStatus(Integer readStatus) {
			this.readStatus = readStatus;
		}

		public String getTeachingDate() {
			return teachingDate;
		}

		public void setTeachingDate(String teachingDate) {
			this.teachingDate = teachingDate;
		}

		public Double getActiveRate() {
			System.out.println(activeRate);
			return activeRate;
		}

		public void setActiveRate(Double activeRate) {
			this.activeRate = activeRate;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public Double getFocusRate() {
			return focusRate;
		}

		public void setFocusRate(Double focusRate) {
			this.focusRate = focusRate;
		}	
	}
}
