package com.cjhsc.dtomodal;

import java.util.List;
import java.util.UUID;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.HotReportsDto  
* @author：chenxh  
* 创建时间：2018年1月15日 下午5:21:03
* 描述：
*
 */
@ApiModel(description="课堂热报列表")
public class HotReportsDto {
	@ApiModelProperty(value = "课堂热报",name="items")
	private List<HotReports> items;
	
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public List<HotReports> getItems() {
		return items;
	}

	public void setItems(List<HotReports> items) {
		this.items = items;
	}

	@ApiModel(description="课堂热报")
	class HotReports{
		@ApiModelProperty(value = "热报日期",name="reportDate", required = true,example="2018-02-28")
		private String reportDate;
		
		
		@ApiModelProperty(value = "热报Id",name="hotReportsId", required = true,example="ADSFdsfds2-23e3-dfasasd")
		private String hotReportsId = UUID.randomUUID().toString();
		
		@ApiModelProperty(value = "家长Id",name="guardianId", required = true,example="123")
		private String guardianId;
		
		@ApiModelProperty(value = "学生Id",name="studentId", required = true,example="456")
		private String studentId;
		
		@ApiModelProperty(value = "学生姓名",name="studentName", required = true,example="王二")
		private String studentName;
		
		@ApiModelProperty(value = "课堂id",name="lessonId", required = true,example="10000001")
		private String lessonId;
		
		@ApiModelProperty(value = "科目名称",name="lessonName", required = true,example="语文课")
		private String lessonName;
		
		@ApiModelProperty(value = "课堂时间开始",name="lessonTime",required = true,example="2018-02-28 11:00")
		private String lessonTime;
		
		@ApiModelProperty(value = "课堂时间结束",name="endTime",required = true,example="2018-02-28 11:45")
		private String endTime;
		
		@ApiModelProperty(value = "教师名称",name="teacherName",required = true,example="陈秋琳")
		private String teacherName;
		
		@ApiModelProperty(value = "热报内容",name="contents",required = true)
		private List<String> contents;
		
		public String getReportDate() {
			return reportDate;
		}
		public void setReportDate(String reportDate) {
			this.reportDate = reportDate;
		}
		public String getLessonId() {
			return lessonId;
		}
		public void setLessonId(String lessonId) {
			this.lessonId = lessonId;
		}
		public String getLessonName() {
			return lessonName;
		}
		public void setLessonName(String lessonName) {
			this.lessonName = lessonName;
		}
		public String getLessonTime() {
			return lessonTime;
		}
		public void setLessonTime(String lessonTime) {
			this.lessonTime = lessonTime;
		}
		public String getTeacherName() {
			return teacherName;
		}
		public void setTeacherName(String teacherName) {
			this.teacherName = teacherName;
		}
		public List<String> getContents() {
			return contents;
		}
		public void setContents(List<String> contents) {
			this.contents = contents;
		}
		public String getGuardianId() {
			return guardianId;
		}
		public void setGuardianId(String guardianId) {
			this.guardianId = guardianId;
		}
		public String getStudentId() {
			return studentId;
		}
		public void setStudentId(String studentId) {
			this.studentId = studentId;
		}
		public String getStudentName() {
			return studentName;
		}
		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}
		public String getHotReportsId() {
			return hotReportsId;
		}
		public String getEndTime() {
			return endTime;
		}
		public void setEndTime(String endTime) {
			this.endTime = endTime;
		}
		public void setHotReportsId(String hotReportsId) {
			this.hotReportsId = hotReportsId;
		}	
	}
}
