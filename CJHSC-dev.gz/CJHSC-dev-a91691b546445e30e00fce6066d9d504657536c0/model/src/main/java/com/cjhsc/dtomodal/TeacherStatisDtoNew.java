package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.TeacherStatisDtoNew  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:35:59
* 描述：
*
 */
@ApiModel(description="教师学期统计指标")
public class TeacherStatisDtoNew {
	@ApiModelProperty(value = "教师学期统计数据",name="items")
	private TeacherStatisData_New items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public TeacherStatisData_New getItems() {
		return items;
	}

	public void setItems(TeacherStatisData_New items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="教师学期统计指标")
	class TeacherStatisData_New{
		@ApiModelProperty(value = "智慧课堂上课次数",name="lessonNum")
		private Integer lessonNum;
		
		@ApiModelProperty(value = "学生正确率",name="correctRate")
		private Double correctRate;
		
		@ApiModelProperty(value = "学生专注度",name="focusRate")
		private Double focusRate;

		public Integer getLessonNum() {
			return lessonNum;
		}

		public void setLessonNum(Integer lessonNum) {
			this.lessonNum = lessonNum;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public Double getFocusRate() {
			return focusRate;
		}

		public void setFocusRate(Double focusRate) {
			this.focusRate = focusRate;
		}		
	}
}
