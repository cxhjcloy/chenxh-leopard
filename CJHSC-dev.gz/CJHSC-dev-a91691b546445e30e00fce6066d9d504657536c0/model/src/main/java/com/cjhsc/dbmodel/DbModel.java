package com.cjhsc.dbmodel;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dbmodel.DbModel  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:21:35
* 描述：
*
 */
public class DbModel {
    private String studentName;

    private String studentId;

    private String studentOpenId;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentOpenId() {
		return studentOpenId;
	}

	public void setStudentOpenId(String studentOpenId) {
		this.studentOpenId = studentOpenId;
	}
}
