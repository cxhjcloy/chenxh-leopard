package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="教师日报课堂详情")
public class TeacherLessonDto {
	@ApiModelProperty(value = "教师日报课堂数据",name="items")
	private TeacherLessonData items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public TeacherLessonData getItems() {
		return items;
	}

	public void setItems(TeacherLessonData items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="教师日报课堂数据")
	class TeacherLessonData{
		@ApiModelProperty(value="课堂活跃度",name="activeRate")
		private Integer activeRate;//课堂活跃度
		
		@ApiModelProperty(value="提问互动次数",name="askedNum")
		private Integer askedNum;//提问互动次数
		
		@ApiModelProperty(value="课堂最佳表现学生名称(逗号分隔)",name="bestStudentNames")
		private String bestStudentNames;//课堂最佳表现学生名称
		
		@ApiModelProperty(value="课堂正确度",name="correctRate")
		private Double correctRate;//课堂正确度
		
		@ApiModelProperty(value="课堂难易度",name="difficultyRate")
		private Double difficultyRate;//课堂难易度
		
		@ApiModelProperty(value="学生对课堂的评价分",name="estimateScore")
		private Double estimateScore;//学生对课堂的评价分
		
		@ApiModelProperty(value="课堂专注度",name="focusRate")
		private Double focusRate;//课堂专注度
		
		@ApiModelProperty(value="课堂完整度",name="integrityRate")
		private Double integrityRate;//课堂完整度
		
		@ApiModelProperty(value="调查互动次数",name="investigatedNum")
		private Integer investigatedNum;//调查互动次数
		
		@ApiModelProperty(value="习题互动次数",name="practiseNum")
		private Integer practiseNum;//习题互动次数
		
		@ApiModelProperty(value="课堂预习率",name="prepareRate")
		private Integer prepareRate;//课堂预习率

		public Integer getActiveRate() {
			return activeRate;
		}

		public void setActiveRate(Integer activeRate) {
			this.activeRate = activeRate;
		}

		public Integer getAskedNum() {
			return askedNum;
		}

		public void setAskedNum(Integer askedNum) {
			this.askedNum = askedNum;
		}

		public String getBestStudentNames() {
			return bestStudentNames;
		}

		public void setBestStudentNames(String bestStudentNames) {
			this.bestStudentNames = bestStudentNames;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public Double getDifficultyRate() {
			return difficultyRate;
		}

		public void setDifficultyRate(Double difficultyRate) {
			this.difficultyRate = difficultyRate;
		}

		public Double getEstimateScore() {
			return estimateScore;
		}

		public void setEstimateScore(Double estimateScore) {
			this.estimateScore = estimateScore;
		}

		public Double getFocusRate() {
			return focusRate;
		}

		public void setFocusRate(Double focusRate) {
			this.focusRate = focusRate;
		}

		public Double getIntegrityRate() {
			return integrityRate;
		}

		public void setIntegrityRate(Double integrityRate) {
			this.integrityRate = integrityRate;
		}

		public Integer getInvestigatedNum() {
			return investigatedNum;
		}

		public void setInvestigatedNum(Integer investigatedNum) {
			this.investigatedNum = investigatedNum;
		}

		public Integer getPractiseNum() {
			return practiseNum;
		}

		public void setPractiseNum(Integer practiseNum) {
			this.practiseNum = practiseNum;
		}

		public Integer getPrepareRate() {
			return prepareRate;
		}

		public void setPrepareRate(Integer prepareRate) {
			this.prepareRate = prepareRate;
		}
	}
}
