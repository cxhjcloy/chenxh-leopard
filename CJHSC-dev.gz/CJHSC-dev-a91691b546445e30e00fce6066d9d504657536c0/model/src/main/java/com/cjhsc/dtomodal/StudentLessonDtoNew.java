package com.cjhsc.dtomodal;


import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "学生课堂报告列表")
public class StudentLessonDtoNew {
	@ApiModelProperty(value = "学生课堂报告列表", name = "items")
	private StudentLesson_New items;
	@ApiModelProperty(value = "记录数", name = "total", required = true, example = "0")
	private Integer total;

	public StudentLesson_New getItems() {
		return items;
	}

	public void setItems(StudentLesson_New items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description = "学生课堂报告数据")
	class StudentLesson_New {
		/*@ApiModelProperty(value = "学生所在班级",name="className")
		private String className;//学生所在班级
		
		@ApiModelProperty(value = "学生Id",name="studentId")
		private Integer studentId;//学生Id
		
		@ApiModelProperty(value = "学生姓名",name="studentName")
		private String studentName;//学生姓名
		
		@ApiModelProperty(value = "被评最佳次数",name="bestNum")
		private Integer bestNum;//被评最佳次数		
		@ApiModelProperty(value = "被批评次数",name="criticismNum")
		private Integer criticismNum;//被批评次数
		
		@ApiModelProperty(value = "被表扬次数",name="praiseNum")
		private Integer praiseNum;//被表扬次数
*/		
		@ApiModelProperty(value = "科目参与/正确度列表", name = "lessonsStatis")
		private List<LessonStatis> lessonsStatis;//科目参与/正确度列表
		
		@ApiModelProperty(value = "课堂简介", name = "lessonOverview")
		private String lessonOverview;// 课堂简介

		@ApiModelProperty(value = "学生活跃度", name = "activeRate")
		private Double activeRate;// 学生活跃度

		@ApiModelProperty(value = "回答次数", name = "answerNum")
		private Integer answerNum;// 回答次数

		@ApiModelProperty(value = "提问次数", name = "askedNum")
		private Integer askedNum;// 提问次数

		@ApiModelProperty(value = "最佳课堂科目名称", name = "bestLessonSubjectName")
		private String bestLessonSubjectName;// 最佳课堂科目名称

		@ApiModelProperty(value = "班级活跃度", name = "classActiveRate")
		private Double classActiveRate;// 班级活跃度

		@ApiModelProperty(value = "班级正确率", name = "classCorrectRate")
		private Double classCorrectRate;// 班级正确率

		@ApiModelProperty(value = "班级专注度", name = "classFocusRate")
		private Double classFocusRate;// 班级专注度

		@ApiModelProperty(value = "完成习题次数", name = "completePractiseNum ")
		private Integer completePractiseNum;// 完成习题次数

		@ApiModelProperty(value = "正确次数", name = "correctPractiseNum ")
		private Integer correctPractiseNum;// 正确次数

		@ApiModelProperty(value = "学生正确率", name = "correctRate")
		private Double correctRate;// 学生正确率

		@ApiModelProperty(value = "错误次数", name = "errorPractiseNum")
		private Integer errorPractiseNum;// 错误次数

		@ApiModelProperty(value = "评价分数", name = "evaluationScore")
		private Double evaluationScore;// 评价分数

		@ApiModelProperty(value = "主动反馈次数", name = "feedbackNum")
		private Integer feedbackNum;// 主动反馈次数

		@ApiModelProperty(value = "学生专注度", name = "focusRate")
		private Double focusRate;// 学生专注度

		@ApiModelProperty(value = "举手次数", name = "handsupNum")
		private Integer handsupNum;// 举手次数

		@ApiModelProperty(value = "总课堂数", name = "lessonNum")
		private Integer lessonNum;// 总课堂数

		@ApiModelProperty(value = "总习题次数", name = "practiseNum")
		private Integer practiseNum;// 总习题次数

		public Double getActiveRate() {
			return activeRate;
		}

		public void setActiveRate(Double activeRate) {
			this.activeRate = activeRate;
		}

		public Integer getAnswerNum() {
			return answerNum;
		}

		public void setAnswerNum(Integer answerNum) {
			this.answerNum = answerNum;
		}

		public Integer getAskedNum() {
			return askedNum;
		}

		public void setAskedNum(Integer askedNum) {
			this.askedNum = askedNum;
		}

		public String getBestLessonSubjectName() {
			return bestLessonSubjectName;
		}

		public void setBestLessonSubjectName(String bestLessonSubjectName) {
			this.bestLessonSubjectName = bestLessonSubjectName;
		}

		public Double getClassActiveRate() {
			return classActiveRate;
		}

		/*public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public Integer getStudentId() {
			return studentId;
		}

		public void setStudentId(Integer studentId) {
			this.studentId = studentId;
		}

		public String getStudentName() {
			return studentName;
		}

		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}*/

		public void setClassActiveRate(Double classActiveRate) {
			this.classActiveRate = classActiveRate;
		}

		public Double getClassCorrectRate() {
			return classCorrectRate;
		}

		public void setClassCorrectRate(Double classCorrectRate) {
			this.classCorrectRate = classCorrectRate;
		}

		public Double getClassFocusRate() {
			return classFocusRate;
		}

		public void setClassFocusRate(Double classFocusRate) {
			this.classFocusRate = classFocusRate;
		}

		public Integer getCompletePractiseNum() {
			return completePractiseNum;
		}

		public void setCompletePractiseNum(Integer completePractiseNum) {
			this.completePractiseNum = completePractiseNum;
		}

		public Integer getCorrectPractiseNum() {
			return correctPractiseNum;
		}

		public void setCorrectPractiseNum(Integer correctPractiseNum) {
			this.correctPractiseNum = correctPractiseNum;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public Integer getErrorPractiseNum() {
			return errorPractiseNum;
		}

		public void setErrorPractiseNum(Integer errorPractiseNum) {
			this.errorPractiseNum = errorPractiseNum;
		}

		public Double getEvaluationScore() {
			return evaluationScore;
		}

		public void setEvaluationScore(Double evaluationScore) {
			this.evaluationScore = evaluationScore;
		}

		public Integer getFeedbackNum() {
			return feedbackNum;
		}

		public void setFeedbackNum(Integer feedbackNum) {
			this.feedbackNum = feedbackNum;
		}

		public Double getFocusRate() {
			return focusRate;
		}

		public void setFocusRate(Double focusRate) {
			this.focusRate = focusRate;
		}

		public Integer getHandsupNum() {
			return handsupNum;
		}

		public void setHandsupNum(Integer handsupNum) {
			this.handsupNum = handsupNum;
		}

		public Integer getLessonNum() {
			return lessonNum;
		}

		public void setLessonNum(Integer lessonNum) {
			this.lessonNum = lessonNum;
		}

		public Integer getPractiseNum() {
			return practiseNum;
		}

		public void setPractiseNum(Integer practiseNum) {
			this.practiseNum = practiseNum;
		}

		/*public Integer getBestNum() {
			return bestNum;
		}

		public void setBestNum(Integer bestNum) {
			this.bestNum = bestNum;
		}

		public Integer getCriticismNum() {
			return criticismNum;
		}

		public void setCriticismNum(Integer criticismNum) {
			this.criticismNum = criticismNum;
		}

		public Integer getPraiseNum() {
			return praiseNum;
		}

		public void setPraiseNum(Integer praiseNum) {
			this.praiseNum = praiseNum;
		}*/

		public String getLessonOverview() {
			/*StringBuffer briefComment = new StringBuffer("{studentName}同学今天参与了{lessonNum}堂智慧课堂。课堂中");
			if (focusRate > 0.6) {
				briefComment.append("听课很专注，");
			} else if (focusRate == 0.6) {
				briefComment.append("听课比较专注，");
			} else if (focusRate < 0.6) {
				briefComment.append("听课不够专注哦，");
			}

			if (correctRate > 0.6) {
				briefComment.append("习题正确率很高，");
			} else if (correctRate == 0.6) {
				briefComment.append("习题正确率还不错，");
			} else if (correctRate < 0.6) {
				briefComment.append("习题正确率不是很高哦，");
				if (focusRate < 0.6) {
					briefComment.append("有待加强，");
				}
			}
			briefComment.append("其中表现最好的一堂课是：{bestLessonSubjectName}。");*/
			
			
			StringBuffer briefComment = new StringBuffer("{studentName}同学今天参与了{lessonNum}堂智慧课堂。");
			StringBuffer focusAndCorrectInfo = new StringBuffer("课堂中");
            if (correctRate > 60) {
                focusAndCorrectInfo.append("习题正确率很高，");
            } else if (correctRate == 60) {
            	focusAndCorrectInfo.append("习题正确率还不错，");
            } else if (correctRate < 60) {
            	focusAndCorrectInfo.append("习题正确率不是很高哦，");
            }
			
			if (focusRate > 60) {
	            focusAndCorrectInfo.append("听课很专注，");
	        } else if (focusRate == 60) {
	            focusAndCorrectInfo .append("听课比较专注，");
	        } else if (focusRate < 60) {
	            focusAndCorrectInfo.append("听课不够专注哦，");
                if (correctRate < 60) {
                    focusAndCorrectInfo.append("有待加强，");
                }
	        }
			briefComment.append(focusAndCorrectInfo);
	        if (lessonNum !=null && lessonNum > 1) {
	        	briefComment.append("其中表现最好的一堂课是：{bestLessonSubjectName}。");
	        } else {
	        	return briefComment.substring(0, briefComment.length())+"。";
	        }
			
			return briefComment.toString();
		}

		public List<LessonStatis> getLessonsStatis() {
			return lessonsStatis;
		}

		public void setLessonsStatis(List<LessonStatis> lessonsStatis) {
			this.lessonsStatis = lessonsStatis;
		}

		public void setLessonOverview(String lessonOverview) {
			this.lessonOverview = lessonOverview;
		}
		@ApiModel(description = "科目参与/正确度列表")
		class LessonStatis{
			@ApiModelProperty(value = "班级名称", name = "className")
			private String className;// 班级名称
			
			@ApiModelProperty(value = "正确率", name = "correctRate")
			private Double correctRate;//正确率
			
			@ApiModelProperty(value = "活跃度", name = "activeRate")
			private Double activeRate;//参与度
			
			@ApiModelProperty(value = "科目名称", name = "subjectName")
			private String subjectName;//科目名称

			public String getClassName() {
				return className;
			}

			public void setClassName(String className) {
				this.className = className;
			}

			public Double getCorrectRate() {
				return correctRate;
			}

			public void setCorrectRate(Double correctRate) {
				this.correctRate = correctRate;
			}

			public Double getActiveRate() {
				return activeRate;
			}

			public void setActiveRate(Double activeRate) {
				this.activeRate = activeRate;
			}

			public String getSubjectName() {
				return subjectName;
			}

			public void setSubjectName(String subjectName) {
				this.subjectName = subjectName;
			}
		}
	}
}
