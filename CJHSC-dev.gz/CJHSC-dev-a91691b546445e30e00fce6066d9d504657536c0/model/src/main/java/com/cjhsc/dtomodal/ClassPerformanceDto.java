package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.ClassPerformanceDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:23:54
* 描述：
*
 */
@ApiModel(description = "班级整体表现对象")
public class ClassPerformanceDto {
	@ApiModelProperty(value = "班级整体表现数据", name = "items")
	private PerformanceDto items;

	public PerformanceDto getItems() {
		return items;
	}

	public void setItems(PerformanceDto items) {
		this.items = items;
	}

	@ApiModel(description = "班级整体表现数据")
	class PerformanceDto {

		@ApiModelProperty(value = "活跃度", name = "activeRate")
		private Double activeRate;

		@ApiModelProperty(value = "凝聚力", name = "cohesion")
		private Double cohesion;

		@ApiModelProperty(value = "自我评价", name = "selfEvaluationScore")
		private Double selfEvaluationScore;

		@ApiModelProperty(value = "自信度", name = "confidentRate")
		private Double confidentRate;

		@ApiModelProperty(value = "学习正确率", name = "correctRate")
		private Double correctRate;

		@ApiModelProperty(value = "作业完成率", name = "completeRate")
		private Double completeRate;

		@ApiModelProperty(value = "课堂纪律", name = "disciplineScore")
		private Double disciplineScore;

		public Double getActiveRate() {
			return activeRate;
		}

		public void setActiveRate(Double activeRate) {
			this.activeRate = activeRate;
		}

		public Double getCohesion() {
			return cohesion;
		}

		public void setCohesion(Double cohesion) {
			this.cohesion = cohesion;
		}

		public Double getSelfEvaluationScore() {
			return selfEvaluationScore;
		}

		public void setSelfEvaluationScore(Double selfEvaluationScore) {
			this.selfEvaluationScore = selfEvaluationScore;
		}

		public Double getConfidentRate() {
			return confidentRate;
		}

		public void setConfidentRate(Double confidentRate) {
			this.confidentRate = confidentRate;
		}

		public Double getCorrectRate() {
			return correctRate;
		}

		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}

		public Double getCompleteRate() {
			return completeRate;
		}

		public void setCompleteRate(Double completeRate) {
			this.completeRate = completeRate;
		}

		public Double getDisciplineScore() {
			return disciplineScore;
		}

		public void setDisciplineScore(Double disciplineScore) {
			this.disciplineScore = disciplineScore;
		}
	}
}
