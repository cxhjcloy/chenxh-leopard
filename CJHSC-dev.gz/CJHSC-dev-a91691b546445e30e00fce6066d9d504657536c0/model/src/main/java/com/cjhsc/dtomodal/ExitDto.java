package com.cjhsc.dtomodal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.ExitDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:25:03
* 描述：
*
 */
@ApiModel(description="用户退出返回值")
public class ExitDto {
	@ApiModelProperty(value = "用户类型(1:教师  2：家长)",name="userRoleTyp", required = true,example="1")
	private String userRoleTyp;

	public String getUserRoleTyp() {
		return userRoleTyp;
	}

	public void setUserRoleTyp(String userRoleTyp) {
		this.userRoleTyp = userRoleTyp;
	}
}
