package com.cjhsc.dtomodal;



import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.StudentDayStatisDto_New  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:26:29
* 描述：
*
 */
@ApiModel(description="学生学情日报列表")
public class StudentDayStatisDtoNew {
	@ApiModelProperty(value = "学生学情日报数据列表",name="items")
	private List<StudentDayStatisDataNew> items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;

	public List<StudentDayStatisDataNew> getItems() {
		return items;
	}
	public void setItems(List<StudentDayStatisDataNew> items) {
		this.items = items;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="学生学情日报数据")
	class StudentDayStatisDataNew{
		//@ApiModelProperty(value = "班级名称",name="className")
		//private String className;//班级名称
		
		@ApiModelProperty(value = "数据标识(仅有课堂数据:1,仅有作业数据数据:2,有课堂数据和作业数据:3)",name="dataFlag")
		private Integer dataFlag;
		
		@ApiModelProperty(value = "学生Id",name="studentId")
		private Integer studentId;
		
		@ApiModelProperty(value = "学生姓名",name="studentName")
		private String studentName;
		
		@ApiModelProperty(value = "教学日期 格式 yyyy-mm-dd",name="teachingDate")
		private String teachingDate;

		@ApiModelProperty(value = "用户是否阅读 0:未阅读 1：已阅读",name="readStatus")
		private Integer readStatus=0;
		
		/*public Integer getBestNum() {
			return bestNum;
		}

		public void setBestNum(Integer bestNum) {
			this.bestNum = bestNum;
		}*/

		public Integer getReadStatus() {
			return readStatus;
		}

		public void setReadStatus(Integer readStatus) {
			this.readStatus = readStatus;
		}

		/*public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}*/

		/*public Integer getCriticismNum() {
			return criticismNum;
		}

		public void setCriticismNum(Integer criticismNum) {
			this.criticismNum = criticismNum;
		}*/

		public Integer getDataFlag() {
			return dataFlag;
		}

		public void setDataFlag(Integer dataFlag) {
			this.dataFlag = dataFlag;
		}

		/*public Integer getPraiseNum() {
			return praiseNum;
		}

		public void setPraiseNum(Integer praiseNum) {
			this.praiseNum = praiseNum;
		}
*/
		public Integer getStudentId() {
			return studentId;
		}

		public void setStudentId(Integer studentId) {
			this.studentId = studentId;
		}

		public String getStudentName() {
			return studentName;
		}

		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}

		public String getTeachingDate() {
			return teachingDate;
		}

		public void setTeachingDate(String teachingDate) {
			this.teachingDate = teachingDate;
		}		
	}
}
