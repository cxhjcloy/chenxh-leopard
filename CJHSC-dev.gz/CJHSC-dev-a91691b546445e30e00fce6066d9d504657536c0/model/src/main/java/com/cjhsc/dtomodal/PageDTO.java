package com.cjhsc.dtomodal;

/**
 * 分页类
 *
 * @author 杨英杰
 * @create 2017-03-31 下午 19:24
 **/
public class PageDTO<T> {
    /**
     * 数据总数
     */
    private int total = 0;
    /**
     * 查询数据
     */
    private T items;

    public T getItems() {
        return items;
    }

    public void setItems(T items) {
        this.items = items;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
