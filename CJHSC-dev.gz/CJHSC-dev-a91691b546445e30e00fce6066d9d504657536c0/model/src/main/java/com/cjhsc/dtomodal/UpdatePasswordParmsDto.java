package com.cjhsc.dtomodal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.UpdatePasswordParmsDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:36:15
* 描述：
*
 */
@ApiModel(description="新旧密码变更对象")
public class UpdatePasswordParmsDto {
	@ApiModelProperty(value = "旧密码",name="oldPassword", required = true,example="123456")
	private String oldPassword;
	@ApiModelProperty(value = "手机号",name="newPassword", required = true,example="654321")
	private String newPassword;
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}	
}
