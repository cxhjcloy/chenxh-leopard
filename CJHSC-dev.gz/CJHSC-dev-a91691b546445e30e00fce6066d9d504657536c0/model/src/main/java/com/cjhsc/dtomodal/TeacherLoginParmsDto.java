package com.cjhsc.dtomodal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.TeacherLoginParmsDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:35:39
* 描述：
*
 */
@ApiModel(description="教师登录对象")
public class TeacherLoginParmsDto {
	@ApiModelProperty(value = "用户名",name="userName", required = true,example="Tom张")
	private String userName;
	
	@ApiModelProperty(value = "密码",name="passWord", required = true,example="abc123")
	private String passWord;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
}
