package com.cjhsc.dtomodal;

import java.util.Date;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.FamilyRelationDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:25:21
* 描述：
*
 */
@ApiModel(description="家长关系列表")
public class FamilyRelationDto {
	@ApiModelProperty(value = "关系数组",name="items")
	private List<Relations> items;
	
	public List<Relations> getItems() {
		return items;
	}

	public void setItems(List<Relations> items) {
		this.items = items;
	}

	@ApiModel(description="家长关系")
	class Relations{
		@ApiModelProperty(value = "家庭关系id",name="relationId", required = true,example="1")
		private String relationId;
		@ApiModelProperty(value = "关系code",name="code", required = true,example="FATHER")
		private String code;
		@ApiModelProperty(value = "关系名称",name="name", required = true,example="父亲")
		private String name;
		@ApiModelProperty(value = "创建时间",name="created")
		private Date created;
		@ApiModelProperty(value = "变更时间",name="updated")
		private Date updated;
		public String getRelationId() {
			return relationId;
		}
		public void setRelationId(String relationId) {
			this.relationId = relationId;
		}
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Date getCreated() {
			return created;
		}
		public void setCreated(Date created) {
			this.created = created;
		}
		public Date getUpdated() {
			return updated;
		}
		public void setUpdated(Date updated) {
			this.updated = updated;
		}
	}
}
