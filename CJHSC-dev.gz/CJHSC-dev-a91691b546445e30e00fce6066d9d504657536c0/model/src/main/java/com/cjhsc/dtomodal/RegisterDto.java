package com.cjhsc.dtomodal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.RegisterDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:25:50
* 描述：
*
 */
@ApiModel(description="家长用户注册对象")
public class RegisterDto {
	@ApiModelProperty(value = "手机号",name="phone", required = true,example="13700000000")
	private String phone;
	
	@ApiModelProperty(value = "用户姓名",name="realName", required = true,example="边伯贤")
	private String realName;
	
	@ApiModelProperty(value = "手机验证码",name="phoneCode", required = true,example="876543")
	private String phoneCode;
	
	@ApiModelProperty(value = "用户密码",name="password", required = true,example="3a@9^uAf*a~Back")
	private String password;
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getPhoneCode() {
		return phoneCode;
	}
	public void setPhoneCode(String phoneCode) {
		this.phoneCode = phoneCode;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
