package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.StudentStudyPortraitDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:30:03
* 描述：
*
 */
@ApiModel(description = "学生学习画像对象")
public class StudentStudyPortraitDto {
	@ApiModelProperty(value = "学生学习画像数据", name = "items")
	private StudyPortraitDto items;

	public StudyPortraitDto getItems() {
		return items;
	}

	public void setItems(StudyPortraitDto items) {
		this.items = items;
	}

	@ApiModel(description = "学生学习画像数据")
	class StudyPortraitDto {
		@ApiModelProperty(value = "计划习惯", name = "planHabit")
		private Double planHabit;
		@ApiModelProperty(value = "班级计划习惯", name = "classPlanHabit")
		private Double classPlanHabit;
		@ApiModelProperty(value = "作业习惯", name = "homeworkHabit")
		private Double homeworkHabit;
		@ApiModelProperty(value = "班级作业习惯", name = "classHomeworkHabit")
		private Double classHomeworkHabit;

		@ApiModelProperty(value = "听课习惯", name = "lessonHabit")
		private Double lessonHabit;
		@ApiModelProperty(value = "班级听课习惯", name = "classLessonHabit")
		private Double classLessonHabit;

		@ApiModelProperty(value = "复习习惯", name = "reviewHabit")
		private Double reviewHabit;

		@ApiModelProperty(value = "班级复习习惯", name = "classReviewHabit")
		private Double classReviewHabit;

		@ApiModelProperty(value = "预习习惯", name = "previewHabit")
		private Double previewHabit;
		@ApiModelProperty(value = "班级预习习惯", name = "classPreviewHabit")
		private Double classPreviewHabit;

		@ApiModelProperty(value = "学习效果", name = "learningEffect")
		private Double learningEffect;

		@ApiModelProperty(value = "班级学习效果", name = "classLearningEffect")
		private Double classLearningEffect;
		public Double getPlanHabit() {
			return planHabit;
		}

		public void setPlanHabit(Double planHabit) {
			this.planHabit = planHabit;
		}

		public Double getClassPlanHabit() {
			return classPlanHabit;
		}

		public void setClassPlanHabit(Double classPlanHabit) {
			this.classPlanHabit = classPlanHabit;
		}

		public Double getHomeworkHabit() {
			return homeworkHabit;
		}

		public void setHomeworkHabit(Double homeworkHabit) {
			this.homeworkHabit = homeworkHabit;
		}

		public Double getClassHomeworkHabit() {
			return classHomeworkHabit;
		}

		public void setClassHomeworkHabit(Double classHomeworkHabit) {
			this.classHomeworkHabit = classHomeworkHabit;
		}

		public Double getLessonHabit() {
			return lessonHabit;
		}

		public void setLessonHabit(Double lessonHabit) {
			this.lessonHabit = lessonHabit;
		}

		public Double getClassLessonHabit() {
			return classLessonHabit;
		}

		public void setClassLessonHabit(Double classLessonHabit) {
			this.classLessonHabit = classLessonHabit;
		}

		public Double getReviewHabit() {
			return reviewHabit;
		}

		public void setReviewHabit(Double reviewHabit) {
			this.reviewHabit = reviewHabit;
		}

		public Double getClassReviewHabit() {
			return classReviewHabit;
		}

		public void setClassReviewHabit(Double classReviewHabit) {
			this.classReviewHabit = classReviewHabit;
		}

		public Double getPreviewHabit() {
			return previewHabit;
		}

		public void setPreviewHabit(Double previewHabit) {
			this.previewHabit = previewHabit;
		}

		public Double getClassPreviewHabit() {
			return classPreviewHabit;
		}

		public void setClassPreviewHabit(Double classPreviewHabit) {
			this.classPreviewHabit = classPreviewHabit;
		}

		public Double getLearningEffect() {
			return learningEffect;
		}

		public void setLearningEffect(Double learningEffect) {
			this.learningEffect = learningEffect;
		}

		public Double getClassLearningEffect() {
			return classLearningEffect;
		}

		public void setClassLearningEffect(Double classLearningEffect) {
			this.classLearningEffect = classLearningEffect;
		}		
	}
}
