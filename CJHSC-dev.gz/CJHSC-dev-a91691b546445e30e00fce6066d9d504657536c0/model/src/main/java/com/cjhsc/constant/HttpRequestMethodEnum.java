package com.cjhsc.constant;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.constant.HttpRequestMethodEnum  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:21:11
* 描述：
*
 */
public enum HttpRequestMethodEnum {
	/**
	 * 
	 */
    GET(1, "get"),
    POST(2, "post"),
    PUT(3, "put"),
    DELETE(3, "delete");
    public int value;
    public String des;

    private HttpRequestMethodEnum(int value, String des) {
        this.value = value;
        this.des = des;
    }
}
