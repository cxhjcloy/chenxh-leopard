package com.cjhsc.domodal;

import java.io.Serializable;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.domodal.SendWeixinUserMqDO  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:21:58
* 描述：
*
 */
public class SendWeixinUserMqDO implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 8871727923525338137L;

    /**
     * 学生姓名
     */
    private String studentName;

    /**
     * 学生ID
     */
    private String studentId;

    /**
     * 家长openId
     */
    private String parentOpenId;

    /**
     * 日报日期
     */
    private String reportDate;

    /**
     * 跳转链接
     */
    private String link;


    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }


    public SendWeixinUserMqDO() {

    }


    public SendWeixinUserMqDO(String parentOpenId, String studentId) {
        this.studentId = studentId;
        this.parentOpenId = parentOpenId;
    }

    public String getStudentName() {
        return studentName;
    }

    /***
     *
     * @param studentName String
     * @param studentId String
     * @param studengtOpenId String
     * @param reportDate String
     */
    public SendWeixinUserMqDO(String studentName, String studentId, String studengtOpenId, String reportDate) {
        this.studentName = studentName;
        this.studentId = studentId;
        this.parentOpenId = studengtOpenId;
        this.reportDate = reportDate;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudengtOpenId() {
        return parentOpenId;
    }




    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getParentOpenId() {
        return parentOpenId;
    }

    public void setParentOpenId(String parentOpenId) {
        this.parentOpenId = parentOpenId;
    }

    public String getReportDate() {
        return reportDate;
    }

    public void setReportDate(String reportDate) {
        this.reportDate = reportDate;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((studentId == null) ? 0 : studentId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SendWeixinUserMqDO other = (SendWeixinUserMqDO) obj;
        if (studentId == null) {
            if (other.studentId != null) {
                return false;
            }
        } else if (!studentId.equals(other.studentId)) {
            return false;
        }
        return true;
    }


    @Override
    public String toString() {
        return "SendWeixinUserMqDO{" +
                "studentName='" + studentName + '\'' +
                ", studentId='" + studentId + '\'' +
                ", parentOpenId='" + parentOpenId + '\'' +
                ", reportDate='" + reportDate + '\'' +
                ", link='" + link + '\'' +
                '}';
    }
}
