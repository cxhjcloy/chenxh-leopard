package com.cjhsc.dtomodal;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
*   
* 项目名称：cjhsc-model  
* 类名称：com.cjhsc.dtomodal.StudentStatisDto  
* @author：chenxh  
* 创建时间：2017年12月15日 上午11:29:45
* 描述：
*
 */
@ApiModel(description="学情报告主页汇总对象")
public class StudentStatisDto {
	@ApiModelProperty(value = "学情报告主页汇总数据",name="items")
	private StudentStatisData items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public StudentStatisData getItems() {
		return items;
	}

	public void setItems(StudentStatisData items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="学情报告主页汇总数据对象")
	class StudentStatisData{
		@ApiModelProperty(value = "孩子总作业次数",name="homeWorkNum")
		private Integer homeWorkNum;
		
		@ApiModelProperty(value = "总上课次数",name="lessonNum")
		private Integer lessonNum;

		public Integer getHomeWorkNum() {
			return homeWorkNum;
		}

		public void setHomeWorkNum(Integer homeWorkNum) {
			this.homeWorkNum = homeWorkNum;
		}

		public Integer getLessonNum() {
			return lessonNum;
		}

		public void setLessonNum(Integer lessonNum) {
			this.lessonNum = lessonNum;
		}
	}
}
