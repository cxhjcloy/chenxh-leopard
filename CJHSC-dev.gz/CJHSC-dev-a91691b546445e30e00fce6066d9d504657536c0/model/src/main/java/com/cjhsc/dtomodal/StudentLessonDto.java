package com.cjhsc.dtomodal;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="学生课程列表")
public class StudentLessonDto {
	@ApiModelProperty(value = "学生课程列表",name="items")
	private List<StudentLesson> items;
	@ApiModelProperty(value = "记录数",name="total", required = true,example="0")
	private Integer total;
	
	public List<StudentLesson> getItems() {
		return items;
	}

	public void setItems(List<StudentLesson> items) {
		this.items = items;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@ApiModel(description="学生课程")
	class StudentLesson{
		@ApiModelProperty(value = "学生正确率",name="correctRate")
		private Double correctRate;//学生正确率
		@ApiModelProperty(value = "学生专注度",name="focusRate")
		private Double focusRate;//学生专注度
		@ApiModelProperty(value = "课堂结束时间",name="lessonEndTime")
		private String lessonEndTime;//课堂结束时间
		@ApiModelProperty(value = "课堂开始时间",name="lessonStartTime")
		private String lessonStartTime;//课堂开始时间
		@ApiModelProperty(value = "课堂科目",name="subjectName")
		private String subjectName;//课堂科目
		public Double getCorrectRate() {
			return correctRate;
		}
		public void setCorrectRate(Double correctRate) {
			this.correctRate = correctRate;
		}
		public Double getFocusRate() {
			return focusRate;
		}
		public void setFocusRate(Double focusRate) {
			this.focusRate = focusRate;
		}
		public String getLessonEndTime() {
			return lessonEndTime;
		}
		public void setLessonEndTime(String lessonEndTime) {
			this.lessonEndTime = lessonEndTime;
		}
		public String getLessonStartTime() {
			return lessonStartTime;
		}
		public void setLessonStartTime(String lessonStartTime) {
			this.lessonStartTime = lessonStartTime;
		}
		public String getSubjectName() {
			return subjectName;
		}
		public void setSubjectName(String subjectName) {
			this.subjectName = subjectName;
		}	
	}
}
